# Hosting and backups

## Cost, with current prices

Railway's headline $5 is a *minimum spend*, not a cap — <cite index="7-1">the plan fee is a floor and usage bills on top at roughly $10/GB-month for RAM and $20/vCPU-month</cite>. For an app plus a database that lands at <cite index="1-1">$6–12/month on the Hobby plan once database memory and storage are counted</cite>, and <cite index="8-1">a Postgres instance alone can reach around $18/month</cite>. It also moves every month, which is the part that irritates people more than the number.

| Option | Monthly | What you get | What you own |
|---|---|---|---|
| **Hetzner CX22 + Cloudflare R2** | **≈ €8.50 ≈ QR 33** | 2 vCPU, 4 GB RAM, 40 GB NVMe, 20 TB traffic. Runs Postgres, API, frontend, backups | OS patching, monitoring, restores |
| Railway | $18–40, variable | Managed, zero ops | Nothing |
| Render | ~$7 web + Postgres on top | Managed | Nothing |

Hetzner raised prices on 1 April 2026 — <cite index="14-1">a CX22 is now roughly €8.39/month</cite>, still the best price-per-spec available. It's one machine for everything, so there's no separate database bill.

**Storage for backups is effectively free.** <cite index="21-1">R2 charges $0.015/GB-month with no egress fee ever, and has a permanent free tier of 10 GB</cite> — your dumps will be tens of megabytes for years, so you'll sit inside the free tier. <cite index="20-1">Backblaze B2 is cheaper on raw storage at $0.006/GB with free egress up to three times your stored data</cite>, which matters for archives but not at your size. R2's zero egress is worth more: on the day you need a restore you don't want a bandwidth bill deciding how much you download.

**Savings: roughly QR 1,600–2,700 a year.** Whether that's worth owning the ops is a real question, not a rhetorical one — see the trade-off below.

## The honest trade-off

On Railway, if the database host dies at 3am, that is Railway's problem. On your own VPS it's yours. For an accounting system holding statutory books, that matters.

Three things make it acceptable:

1. **The restore is tested automatically, every night.** Not "we take backups" — a script that restores the newest backup into a scratch database and then asks whether the trial balance still nets to zero.
2. **A dead-man's switch.** Two healthchecks.io pings — one that the backup ran, one that it was proven restorable. Silence emails you. Backups fail silently far more often than loudly.
3. **The whole stack is one `docker compose up`.** Rebuilding on a fresh VPS is minutes, not an afternoon.

If you'd rather not own any of that, stay on Railway and use the same backup scripts pointed at their Postgres — they work identically.

## Backup strategy

**3-2-1**: three copies, two kinds of media, one offsite.

| Layer | What | Recovers |
|---|---|---|
| WAL archiving | Continuous, to a volume | Any point in time since the last base backup |
| Nightly `pg_dump -Fc` | Encrypted, local + R2 | The whole database, or a single table |
| GFS ladder | 14 daily, 8 weekly, 24 monthly, yearly kept forever | 10-year statutory retention |

Yearly archives are **never** pruned by the script. Qatar's Commercial Companies Law requires books to be retained for ten years; deleting one should take a deliberate act with your auditor's agreement.

Dumps are encrypted with `age` before they leave the machine, so a stolen backup is useless without a key that lives elsewhere.

### The part that matters: `restore-test.sh`

Most backup setups verify that a file exists. That is not the same as having a backup. This script:

1. Refuses if the newest backup is more than 36 hours old — catches a cron job that died quietly
2. Verifies the SHA-256
3. Decrypts it
4. Restores into a throwaway database, failing on the *first* error
5. Asks the restored copy: does the trial balance net to zero? Any unbalanced entries? Any single-line entries? Are all core tables populated? Does it have *more* entries than live, meaning we restored the wrong database?
6. Drops the scratch database

It was tested against real PostgreSQL 16 by deliberately breaking things:

```
### a truncated backup file          → FAILED: checksum mismatch — the file is corrupt
### a single corrupted byte          → FAILED: checksum mismatch — the file is corrupt
### the nightly job silently stopped → FAILED: newest backup is 96h old
### an empty backup directory        → FAILED: no backup files found
### books that restore but don't balance
                                     → FAILED: restored trial balance does not net to zero: 12345.00
### healthy again                    → PASS
```

That fifth case is the one generic backup tooling cannot catch, and the one that would ruin an audit.

**A bug this testing found:** the script derived the scratch connection string with `${ADMIN_URL%/*}`, which silently drops a `?host=...&port=...` query string and connects to the wrong server. It failed with a message that said only "pg_restore could not rebuild the database". Both are fixed — proper URL handling, and pg_restore's own error is now printed. Had this only been reasoned about rather than run, it would have been discovered during a real disaster.

> The step-by-step version of everything below, with the commands in order, is in
> **RUNBOOK.md**. This file is the reasoning; that one is the procedure.

## Setup

> These accounts should be opened **in the client's name**, not yours. See Part 0
> of RUNBOOK.md — the server, the domain and the backup storage all hold the
> client's statutory records, and moving them later means migrating a live
> accounting system.



```bash
# 1. Create a Hetzner CX22 (Falkenstein or Nuremberg), Ubuntu 24.04
#    Add your SSH key. Enable the firewall: allow 22, 80, 443 only.

# 2. On the server
curl -fsSL https://get.docker.com | sh
git clone <your repo> /opt/rwfaa && cd /opt/rwfaa

# 3. Secrets
cp ops/.env.example .env && nano .env
openssl rand -base64 32   # POSTGRES_PASSWORD
openssl rand -base64 48   # SESSION_SECRET
age-keygen -o ops/age-key.txt && chmod 600 ops/age-key.txt
# copy the public key into AGE_RECIPIENTS, and keep age-key.txt
# somewhere OFF this server as well — encrypted backups are
# worthless if the only key burns with the machine

# 4. Offsite
rclone config          # Cloudflare R2 or Backblaze B2, S3-compatible

# 5. Up
docker compose up -d
docker compose exec api npm run migrate

# 6. Prove it before you trust it
docker compose exec backup /usr/local/bin/backup.sh
docker compose exec backup /usr/local/bin/restore-test.sh
```

## Before go-live

- [ ] `restore-test.sh` passes, and you have watched it pass
- [ ] Restore into a **different machine** by hand at least once — the drill you never do is the one you need
- [ ] `age-key.txt` exists somewhere that is not this server
- [ ] Both healthchecks configured and confirmed to email you when silenced
- [ ] Firewall allows only 22, 80, 443; Postgres is not published to the host
- [ ] `unattended-upgrades` enabled for security patches
- [ ] Confirm with your auditor where the books may be hosted, and keep an encrypted copy in Qatar
