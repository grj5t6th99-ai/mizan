# Running MIZAN — step by step

This is the whole path: from the files on your machine to a working system your
staff sign into. Roughly 90 minutes, most of it waiting for DNS and a certificate.

Do it in this order. Part 2 exists so that when something goes wrong later, you
already know it isn't the code. It runs entirely online — nothing is installed on
your machine and nothing lands on your disk.

---

## Part 0 — Decide who owns what, before you create anything

You are hosting this on the client's account, which is the right call: these are
their statutory books, and Qatar's Commercial Companies Law requires them to be
retained for ten years. That obligation is the company's, not yours.

Carry the same logic through the rest of the stack. Every account below should be
**opened by the client, in the client's name, with the client's billing**, and you
added as an administrator or collaborator:

| Account | Whose name | Why |
|---|---|---|
| GitHub `alwfaatrad2026` | Client | Already done |
| Hetzner Cloud | Client | If the card expires or a relationship ends, the server does not vanish |
| Domain registrar | Client | Whoever controls DNS controls the system |
| Cloudflare (R2 backups) | Client | Ten years of books should not sit in a contractor's storage account |
| healthchecks.io | Client, alerting you both | Somebody must still be told when backups stop |

This costs nothing extra and takes ten minutes at the start. Reversing it later
means migrating a live accounting system, which is a genuinely bad afternoon.

**Two things to agree in writing now:**

1. **Who holds the backup encryption key.** Part 5.2 generates a private key. If
   only you hold it, the client cannot restore their own books without you. Both
   of you should have a copy, each in a password manager. Say so out loud.
2. **A domain the client controls.** Part 4 needs one — `alrwfaa.qa` or similar.
   TLS certificates require a real domain name; an IP address alone will not do.
   If the client has no domain yet, buy one in their name before Part 4. It is
   the cheapest item on this list and the one that blocks everything else.

---

## Part 1 — Get the code into a private repository

**Everything here is different from the demo: this repository must be PRIVATE.**
It holds your books, your chart of accounts and your deployment configuration.

**1.1** Download `mizan-server.zip` from this conversation and unzip it. Rename
the folder to `rwfaa-server` if you like; the folder name on your machine does
not matter, only the repository name does.

**1.2** Signed in as `alwfaatrad2026`, create a **private** repository called
`rwfaa-server`. Do not tick "Add a README" — the push in 1.3 expects it empty.

**1.3** In a terminal, from inside the unzipped folder:

```bash
cd path/to/rwfaa-server
git init
git add -A
git commit -m "Al-Rwfaa ERP — schema, API, frontend, backups"
git branch -M main
git remote add origin https://github.com/alwfaatrad2026/rwfaa-server.git
git push -u origin main
```

> **On authentication:** GitHub will ask for a password when you push. Use a
> personal access token, not the account password — github.com/settings/tokens →
> Generate new token (classic) → tick `repo`. If you are pushing to the client's
> account from your own machine, a token scoped to this one repository is tidier
> than logging in as them.

**1.4** Confirm on GitHub that there is **no `.env` file and no `ops/age-key.txt`**
in the repository, and that the **`.devcontainer` folder is present** — Codespaces
needs it, and some unzip tools silently drop folders beginning with a dot.

`.gitignore` excludes the secrets, but check with your own eyes: a database
password in Git history is very hard to remove afterwards.

---

## Part 2 — Try it before you deploy it

The point of this part is to isolate variables: prove the software works before
DNS, TLS and a firewall join the list of things that might be wrong. It does not
have to happen on your laptop, and it does not have to cost you disk space.

Pick **one** of the two routes below.

---

### Route A — GitHub Codespaces (nothing installed, nothing on your disk)

A throwaway machine in the browser, on the free tier, completely separate from
the server that will eventually hold your books. Free accounts get 120 core-hours a month — 60 hours on the 2-core machine — plus
15 GB of storage, and it works on private repositories. The quota belongs to
`alwfaatrad2026`, which is brand new, so all of it is available. This takes well under an hour, so you will not come close
to the limit.

**A.1** Signed in as `alwfaatrad2026`, open the private `rwfaa-server`
repository →
**Code ▾ → Codespaces → Create codespace on main**.

Leave the machine type at **2-core**. Larger machines burn the free quota twice
as fast for no benefit here.

**A.2** Wait for it to finish building. It installs dependencies and builds the
frontend by itself — you will see it working in the terminal at the bottom. Two
to three minutes the first time.

**A.3** In the Codespace terminal:

```bash
npm run try
```

That runs the migrations, creates the company and your login, and starts the
server. **Copy the password it prints** — it is shown once.

**A.4** A notification offers to open the forwarded port; take it. Or go to the
**Ports** tab and click the globe icon next to port 3000.

You get a private URL like `https://something-3000.app.github.dev`, visible only
to you. Sign in with the email and password from A.3.

**A.5** Have a proper look around. Raise a trading invoice and watch the posting
slip fill in as you type. Try to save it with the amount at zero — the button
stays disabled and the slip tells you why. Open **Reports → Trial Balance** and
confirm it balances. Switch to **عربي** and check the Arabic reads correctly to
you; that is the one thing I cannot verify.

**A.6** When you are done, **delete the codespace**, do not just close the tab.
A stopped codespace keeps consuming your storage quota for as long as it exists.

GitHub → **Code ▾ → Codespaces → … → Delete**.

> Nothing you type here reaches production. This machine is thrown away.

---

### Route B — Test on the server, before pointing the domain at it

If you would rather not add another account to your life: you are buying the
server anyway, so use it. Deploy, try everything over a private SSH tunnel, then
wipe it clean and deploy again for real.

Do **Part 3** and **Part 5** first, but **skip Part 4 (DNS)**. Then, from your own
machine:

```bash
ssh -L 3000:localhost:3000 root@YOUR_SERVER_IP
```

Leave that terminal open. It forwards the server's port 3000 to your laptop
through the SSH connection — nothing is exposed to the internet, and the firewall
stays shut.

Open <http://localhost:3000> in your browser and work through A.5 above.

**When you are finished, wipe it. This matters.**

```bash
docker compose down -v
```

The `-v` deletes the database volume, so every invoice and customer you invented
while exploring is gone. Then carry on with **Part 4 (DNS)** and re-run the deploy
and bootstrap steps in **5.5–5.7** on a clean database.

> The risk here is human, not technical: it is forgetting to wipe. If you take
> this route, do not skip `docker compose down -v`, and do not post opening
> balances until you have.

---

**Which one?** Route A if you want the test environment to be genuinely
incapable of contaminating production. Route B if you would rather learn one
system instead of two, and you trust yourself to run the wipe.

## Part 3 — The server

**3.1** Create a Hetzner Cloud account and a new project.

**3.2** Add your SSH public key under **Security → SSH keys**. If you do not have
one:

```bash
ssh-keygen -t ed25519 -C "you@alrwfaa.qa"
cat ~/.ssh/id_ed25519.pub        # paste this into Hetzner
```

**3.3** Create a server:

| Setting | Choice |
|---|---|
| Location | Falkenstein or Nuremberg |
| Image | Ubuntu 24.04 |
| Type | Shared vCPU → **CX22** (2 vCPU, 4 GB) |
| SSH key | the one you just added |
| Firewall | create one allowing inbound **22, 80, 443** only |
| Name | `mizan` |

Note the IPv4 address it gives you.

**3.4** Connect and prepare it:

```bash
ssh root@YOUR_SERVER_IP

apt update && apt upgrade -y
apt install -y unattended-upgrades      # security patches apply themselves
curl -fsSL https://get.docker.com | sh
```

---

## Part 4 — DNS

**4.1** In the DNS control panel for the client's domain, add **one** record:

| Type | Host | Value |
|---|---|---|
| A | `erp` | `YOUR_SERVER_IP` |

An A record, not a CNAME: this points at a server you control, not at a hosting
platform. If the client's domain already serves a website, this does not disturb
it — you are adding a subdomain, not changing the apex.

If `alrwfaa.qa` is not the client's actual domain, substitute theirs and use the
same name consistently in `.env` (`DOMAIN=`) and in step 4.2.

**4.2** Wait, then check from your laptop:

```bash
dig +short erp.alrwfaa.qa
```

When it returns your server's IP, carry on. Usually a few minutes.

---

## Part 5 — Deploy

All of this is on the server, over SSH.

**5.1** Clone the private repository. Use a
[personal access token](https://github.com/settings/tokens) with `repo` scope as
the password when Git asks:

```bash
git clone https://github.com/alwfaatrad2026/rwfaa-server.git /opt/rwfaa
cd /opt/rwfaa
```

**5.2** Generate the backup encryption key:

```bash
apt install -y age
age-keygen -o ops/age-key.txt
chmod 600 ops/age-key.txt
cat ops/age-key.txt
```

It prints a public key beginning `age1…` and a private key beginning
`AGE-SECRET-KEY-1…`.

> **Copy the private key into your password manager now.**
> Encrypted backups are useless without it. If the only copy is on this server,
> then the fire that destroys the server destroys the backups too. This is the
> single most common way a backup strategy turns out to be worthless.

**5.3** Create the real `.env`:

```bash
cp ops/.env.example .env
openssl rand -base64 32     # -> POSTGRES_PASSWORD
openssl rand -base64 48     # -> SESSION_SECRET
nano .env
```

Fill in:

```
DOMAIN=erp.alrwfaa.qa
POSTGRES_PASSWORD=<the 32-byte value>
SESSION_SECRET=<the 48-byte value>
AGE_RECIPIENTS=<the age1... PUBLIC key from 5.2>
RCLONE_REMOTE=r2:rwfaa-backups
```

Then lock it down: `chmod 600 .env`

**5.4** Set up offsite backup storage.

In the Cloudflare dashboard: **R2 → Create bucket → `rwfaa-backups`**, then
**Manage R2 API Tokens → Create token** with Object Read & Write. Note the Access
Key ID, Secret Access Key and your Account ID.

```bash
apt install -y rclone
rclone config
```

Answer: `n` (new remote) → name `r2` → storage `s3` → provider `Cloudflare` →
enter your access key and secret → region `auto` → endpoint
`https://<ACCOUNT_ID>.r2.cloudflarestorage.com` → accept the rest → `q` to quit.

```bash
cp ~/.config/rclone/rclone.conf ops/rclone.conf
chmod 600 ops/rclone.conf
rclone lsd r2:                    # should list rwfaa-backups
```

**5.5** Start everything:

```bash
docker compose up -d --build
```

The first build takes a few minutes: it compiles the frontend, then packages it
with the API.

**5.6** Create the tables and your company:

```bash
docker compose exec api npm run migrate
docker compose exec api npm run bootstrap -- --year 2026 --email you@alrwfaa.qa
```

**Copy the password it prints.** It is shown once.

**5.7** Wait for the certificate, then check:

```bash
docker compose logs web | grep -i certificate
curl -I https://erp.alrwfaa.qa
```

Let's Encrypt usually issues within a minute or two. Once you see `HTTP/2 200`,
open <https://erp.alrwfaa.qa> and sign in.

**Change the password immediately** — the system asks you to.

---

## Part 6 — Prove the backups work

Do not skip this. A backup you have never restored is a hope, not a backup.

```bash
docker compose exec backup /usr/local/bin/backup.sh
docker compose exec backup /usr/local/bin/restore-test.sh
```

The second command restores the backup you just took into a scratch database and
checks that the restored books still balance. You want to see:

```
PASS — mizan-....dump.age is a restorable, self-consistent copy of the books
```

Confirm it reached Cloudflare:

```bash
rclone ls r2:rwfaa-backups/daily
```

From here both run by themselves: the backup at 02:00 Doha time, the restore test
at 03:00.

**Set up the dead man's switch.** Backups fail silently far more often than
loudly. At [healthchecks.io](https://healthchecks.io) (free) create two checks —
"Al-Rwfaa backup" and "Al-Rwfaa restore test" — and put their ping URLs into `.env` as
`HEALTHCHECK_URL` and `RESTORE_TEST_HEALTHCHECK_URL`, then
`docker compose up -d backup`. If a job stops running, you get an email. Without
this you find out during a crisis.

---

## Part 7 — Set up your books

Working through the app, in this order:

1. **Company Setup** — send me the registered **Arabic company name**; it is
   deliberately blank because it prints on statements that go to your auditor.
   Set the payment approval limit above which a second person must approve.
2. **Users** — create at least two people with different roles. With one user,
   maker/checker is theatre: the system will refuse to let anyone approve their
   own payment, so a single user can never release a large payment.
3. **Customers & Suppliers**, **Chart of Accounts** (add anything your auditor
   asks for — cheap now, expensive once there are postings against it).
4. **Projects** with their real contract values, start dates and end dates.
5. **Items**, **Employees**, **Fixed Assets**.
6. **Opening balances** — one manual journal dated the first day of the financial
   year, agreeing to last year's audited accounts. Have your accountant check it
   before anyone posts anything else.

---

## Day-to-day

**Deploy an update**

```bash
cd /opt/rwfaa && git pull && docker compose up -d --build
```

Migrations are safe to re-run; already-applied ones are skipped.

**Watch it**

```bash
docker compose ps
docker compose logs -f api
docker compose exec backup tail -50 /var/log/restore-test.log
```

**Take a backup before anything risky** (a period close, a bulk import)

```bash
docker compose exec backup /usr/local/bin/backup.sh --tag before-close
```

**Restore for real** — only when you mean it. This replaces the live database:

```bash
docker compose exec backup sh -c 'age -d -i /run/secrets/age_key \
  -o /tmp/r.dump /var/backups/mizan/daily/<file>.age'
docker compose exec backup sh -c 'pg_restore --dbname="$DATABASE_URL" \
  --clean --if-exists --no-owner --exit-on-error /tmp/r.dump'
```

---

## When something goes wrong

| Symptom | Cause | Fix |
|---|---|---|
| Certificate never issues | DNS not pointing here yet, or port 80 closed | `dig +short erp.alrwfaa.qa`; check the Hetzner firewall allows 80 and 443 |
| `api` restarts in a loop | Database not ready, or a bad `DATABASE_URL` | `docker compose logs api`; check `POSTGRES_PASSWORD` matches in both places |
| Sign-in says "do not match" | Wrong password, or the account is locked | Eight failures locks it for 15 minutes; wait, or re-run `bootstrap` on an empty user table |
| "Period is LOCKED" | Correct behaviour | Reopen the period in Company Setup, or post to an open one |
| "does not balance" | Correct behaviour | The posting slip shows exactly how much it is out by |
| Frontend looks stale after a deploy | Browser cache | Hard-refresh. The shell is sent with `no-cache`, so this should be rare |
| Codespace stops on its own | Idle timeout, 30 minutes by default | Restart it; your files are still there. Run `npm run try` again |
| Codespace quota running low | Stopped codespaces still use storage | Delete old ones under **Code ▾ → Codespaces** |
| `restore-test.sh` fails | Take it seriously | The message says why. Until it passes, treat the backups as unreliable |

---

## Before real money goes through it

- [ ] Auditor has reviewed the chart of accounts and the close process
- [ ] `restore-test.sh` has passed, and you have watched it pass
- [ ] The age private key is stored somewhere that is **not** this server
- [ ] Both healthchecks are configured and confirmed to alert you
- [ ] At least two users with different roles exist
- [ ] Opening balances posted and agreed to last year's audited accounts
- [ ] One month posted in parallel with your existing books and reconciled
- [ ] You have restored a backup onto a second machine by hand, once
