#!/usr/bin/env node
'use strict';
/* ============================================================
   First-run setup: company, roles, fiscal calendar, admin user.
   Safe to re-run — it skips anything already present.

     DATABASE_URL=... node scripts/bootstrap.js --year 2026
   ============================================================ */
const crypto = require('node:crypto');
const db = require('../src/db');
const auth = require('../src/auth');

const arg = (name, fallback) => {
  const i = process.argv.indexOf('--' + name);
  return i > -1 ? process.argv[i + 1] : fallback;
};
const year = Number(arg('year', new Date().getFullYear()));
const adminEmail = arg('email', 'admin@alrwfaa.qa');

(async () => {
  await db.tx(async c => {
    await c.query(`INSERT INTO role (code,name,name_ar,can_post,can_approve,can_close_period,can_admin,approval_limit) VALUES
      ('OWNER','Owner','المالك',TRUE,TRUE,TRUE,TRUE,NULL),
      ('FINMGR','Finance Manager','المدير المالي',TRUE,TRUE,TRUE,TRUE,NULL),
      ('ACCT','Accountant','محاسب',TRUE,FALSE,FALSE,FALSE,50000),
      ('ENGR','Project Engineer','مهندس مشاريع',FALSE,FALSE,FALSE,FALSE,0),
      ('STORE','Store Keeper','أمين المخزن',FALSE,FALSE,FALSE,FALSE,0)
      ON CONFLICT (code) DO NOTHING`);

    // name_ar is left NULL on purpose: it prints on statements that go
    // to the auditor, so it should be typed by someone who knows the
    // registered Arabic name, not transliterated by software.
    await c.query(`INSERT INTO company (id,name,name_ar,cr_no,tax_no,address,phone,
                     retention_pct,gratuity_days_year,income_tax_pct,payment_approval_limit)
      VALUES (1,'Al-Rwfaa Trading and Contracting W.L.L.',NULL,NULL,NULL,NULL,NULL,10,21,10,50000)
      ON CONFLICT (id) DO NOTHING`);

    const { rows: fy } = await c.query(
      `INSERT INTO fiscal_year (code, starts_on, ends_on)
       VALUES ($1, make_date($2,1,1), make_date($2,12,31))
       ON CONFLICT (code) DO NOTHING RETURNING id`, [`FY${year}`, year]);
    if (fy[0]) {
      await c.query(
        `INSERT INTO fiscal_period (fiscal_year_id, period_no, starts_on, ends_on)
         SELECT $1, m, make_date($2,m,1), (make_date($2,m,1) + interval '1 month -1 day')::date
           FROM generate_series(1,12) m`, [fy[0].id, year]);
      console.log(`Created FY${year} with 12 open periods.`);
    } else {
      console.log(`FY${year} already exists.`);
    }

    const { rows: existing } = await c.query('SELECT id FROM app_user LIMIT 1');
    if (!existing.length) {
      const password = crypto.randomBytes(12).toString('base64url');
      await c.query(
        `INSERT INTO app_user (email,name,role_code,password_hash,must_change_password)
         VALUES ($1,'Administrator','OWNER',$2,TRUE)`,
        [adminEmail, await auth.hashPassword(password)]);
      console.log('\n  Sign in with:');
      console.log(`    email    ${adminEmail}`);
      console.log(`    password ${password}`);
      console.log('  You will be asked to change it. This is the only time it is shown.\n');
    } else {
      console.log('Users already exist; no admin created.');
    }
  });
  await db.pool.end();
})().catch(e => { console.error(e.message); process.exit(1); });
