/* Applies migrations and seeds in order, once each, inside a
   transaction. Records what ran so it is safe to re-run on deploy. */
const { Client } = require('pg');
const fs = require('fs'), path = require('path');

(async () => {
  const db = new Client({ connectionString: process.env.DATABASE_URL });
  await db.connect();
  await db.query(`CREATE TABLE IF NOT EXISTS schema_migration (
    filename TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now())`);

  const dirs = ['migrations', 'seeds'];
  const done = new Set((await db.query('SELECT filename FROM schema_migration')).rows.map(r => r.filename));

  for (const dir of dirs) {
    if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort()) {
      const key = `${dir}/${f}`;
      if (done.has(key)) { console.log(`  · ${key} (already applied)`); continue; }
      try {
        await db.query('BEGIN');
        await db.query(fs.readFileSync(path.join(dir, f), 'utf8'));
        await db.query('INSERT INTO schema_migration (filename) VALUES ($1)', [key]);
        await db.query('COMMIT');
        console.log(`  ✓ ${key}`);
      } catch (e) {
        await db.query('ROLLBACK');
        console.error(`  ✗ ${key}\n    ${e.message}`);
        process.exit(1);
      }
    }
  }
  await db.end();
  console.log('Migrations up to date.');
})();
