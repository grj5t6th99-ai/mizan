/** Design tokens carried over from the prototype: ledger paper,
 *  oxide maroon, ink. Not a default palette. */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink:      { DEFAULT: '#191C1B', soft: '#5A6362', faint: '#8B9694' },
        paper:    '#F1F4F3',
        field:    '#F7F9F8',
        rule:     { DEFAULT: '#D6DBD9', strong: '#AEB7B5' },
        maroon:   { DEFAULT: '#7A1226', soft: '#F6E7EA', deep: '#5E0D1D' },
        ledger:   { green: '#14624A', soft: '#E4F0EB' },
        amber:    { DEFAULT: '#8A5A08', soft: '#FBF0DC' }
      },
      fontFamily: {
        display: ['Georgia', '"Times New Roman"', 'serif'],
        ui: ['system-ui', '-apple-system', '"Segoe UI"', 'Roboto', 'sans-serif'],
        ar: ['"Noto Sans Arabic"', '"Segoe UI"', 'Tahoma', '"Geeza Pro"', 'sans-serif'],
        arDisplay: ['"Noto Naskh Arabic"', '"Traditional Arabic"', 'Georgia', 'serif'],
        data: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace']
      }
    }
  },
  plugins: []
};
