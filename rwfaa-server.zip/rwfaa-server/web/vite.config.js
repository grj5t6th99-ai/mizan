import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    // one origin in development too, so cookies behave the same as in production
    proxy: { '/api': { target: 'http://localhost:3000', changeOrigin: true } }
  },
  build: { outDir: 'dist', sourcemap: false }
});
