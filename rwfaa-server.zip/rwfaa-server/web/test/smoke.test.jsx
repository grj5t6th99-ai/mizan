/* Renders the real components in jsdom against a stubbed API and
   drives the flows that matter: signing in, switching to Arabic,
   the overdue flag, and the posting slip enabling the save button
   only when the server says the entry balances. */
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import App from '../src/App';

let pass = 0, fail = 0;
const ok = (m, d) => { pass++; console.log('  \u2713 ' + m + (d ? '  \u2014 ' + d : '')); };
const bad = (m, d) => { fail++; console.log('  \u2717 ' + m + (d ? '  \u2014 ' + d : '')); };
const check = (c, m, d) => (c ? ok : bad)(m, d);

/* ---------- a stub of the server ---------- */
let signedIn = false;
let previewCalls = 0;
let lastPreviewBody = null;

const ACCOUNTS = [
  { code: '1130', name: 'Accounts Receivable — Trade', name_ar: 'الذمم المدينة — التجارية', type: 'ASSET', is_group: false },
  { code: '1131', name: 'Retention Receivable', name_ar: 'المحتجزات المدينة', type: 'ASSET', is_group: false },
  { code: '4200', name: 'Contracting Revenue', name_ar: 'إيرادات المقاولات', type: 'REVENUE', is_group: false },
  { code: '1120', name: 'Bank — QNB', name_ar: 'بنك — QNB', type: 'ASSET', is_group: false, class_tag: 'bank' }
];

const ROUTES = {
  'GET /auth/me': () => signedIn ? { user: { id: 1, name: 'Suresh Menon', role: 'FINMGR',
      can_post: true, can_approve: true, can_close_period: true, can_admin: true } }
    : { __status: 401, error: 'Sign in to continue.' },
  'POST /auth/login': body => {
    if (body.password !== 'right') return { __status: 401, error: 'That email address and password do not match.' };
    signedIn = true;
    return { user: { id: 1, name: 'Suresh Menon', role: 'FINMGR', can_post: true, can_admin: true } };
  },
  'GET /reports/health': () => ({ ok: true, trialBalanceNet: '0.00' }),
  'GET /reports/schedule': () => ([
    { id: 1, code: 'PRJ-2601', name: 'Lusail Marina Tower', end_on: '2026-11-30',
      baseline_end_on: '2026-11-30', days_over: -90, is_overdue: false, status: 'IN_PROGRESS',
      slip_days: 0, revision_count: 0, contract_value: '4200000', starts_on: '2026-01-15' },
    { id: 2, code: 'PRJ-2602', name: 'Msheireb Retail Block C', end_on: '2026-08-03',
      baseline_end_on: '2026-06-12', days_over: 23, is_overdue: true, status: 'IN_PROGRESS',
      slip_days: 52, revision_count: 2, contract_value: '1650000', starts_on: '2026-02-01' }
  ]),
  'GET /reports/projects': () => ([
    { id: 2, code: 'PRJ-2602', name: 'Msheireb Retail Block C', certified: '993000.00',
      cost: '401500.00', margin: '591500.00', margin_pct: 59.56, is_overdue: true,
      contract_value: '1650000', status: 'IN_PROGRESS', client_name: 'Msheireb Properties' }
  ]),
  'GET /cash/pending': () => ([
    { id: 9, doc_date: '2026-05-15', reference: 'CHQ-1042', narration: 'Subcontract payment',
      purpose: 'SETTLEMENT', raised_by: 'Priya Varghese', amount: '256500.00' }
  ]),
  'GET /reports/trial-balance': () => ({ rows: ACCOUNTS.map(a => ({ ...a, balance: '1000.00' })),
    totals: { debit: '4000.00', credit: '4000.00', difference: '0.00' }, balanced: true }),
  'GET /journal': () => ([{ id: 1, entry_no: 'IPC-2026-00001', entry_date: '2026-03-25',
    source: 'Sales Invoice', memo: 'IPC 1 — PRJ-2601', amount: '620000.00', posted_by_name: 'Suresh Menon' }]),
  'GET /sales-invoices': () => ([{ id: 1, doc_no: 'IPC-2026-00001', invoice_date: '2026-03-25',
    party_name: 'Qatari Diar', party_id: 1, doc_type: 'CERTIFICATE', gross_amount: '620000.00',
    retention_amount: '62000.00', outstanding: '415200.00', due_date: '2026-05-24', days_overdue: 0 }]),
  'GET /parties': () => ([{ id: 1, code: 'C001', kind: 'CUSTOMER', name: 'Qatari Diar',
    name_ar: 'قطري الديار', terms_days: 60, is_active: true }]),
  'GET /projects': () => ([{ id: 1, code: 'PRJ-2601', name: 'Lusail Marina Tower', retention_pct: '10' }]),
  'GET /items': () => ([{ id: 1, code: 'CBL-4C16', name: 'Armoured Cable', sell_price: '38.50' }]),
  'GET /advances': () => ([]),
  'GET /accounts': () => ACCOUNTS,
  'POST /sales-invoices/preview': body => {
    previewCalls++; lastPreviewBody = body;
    const gross = Number(body.grossAmount || 0);
    if (!gross) return { __status: 400, error: 'Enter the value of work certified.' };
    if (Number(body.advanceRecovered || 0) > 300000) {
      return { __status: 400, error: 'You are recovering more advance than is held.' };
    }
    const ret = gross * 0.1;
    return {
      date: body.invoiceDate, memo: 'Payment certificate',
      lines: [
        { line_no: 1, account_code: '1130', account_name: 'Accounts Receivable — Trade',
          account_name_ar: 'الذمم المدينة — التجارية', debit: (gross - ret).toFixed(2), credit: '0.00' },
        { line_no: 2, account_code: '1131', account_name: 'Retention Receivable',
          account_name_ar: 'المحتجزات المدينة', debit: ret.toFixed(2), credit: '0.00' },
        { line_no: 3, account_code: '4200', account_name: 'Contracting Revenue',
          account_name_ar: 'إيرادات المقاولات', debit: '0.00', credit: gross.toFixed(2) }
      ],
      totals: { debit: gross.toFixed(2), credit: gross.toFixed(2) }, balanced: true
    };
  }
};

globalThis.fetch = async (url, opts = {}) => {
  const path = String(url).replace(/^.*\/api/, '').split('?')[0];
  const key = `${opts.method || 'GET'} ${path}`;
  const handler = ROUTES[key];
  if (!handler) return new Response(JSON.stringify({ error: `No stub for ${key}` }), { status: 404 });
  const body = opts.body ? JSON.parse(opts.body) : null;
  const out = handler(body);
  const status = out?.__status || 200;
  return new Response(JSON.stringify(out), { status, headers: { 'content-type': 'application/json' } });
};

/* ---------- helpers ---------- */
const $ = s => document.querySelector(s);
const all = s => [...document.querySelectorAll(s)];
const byText = (sel, text) => all(sel).find(n => n.textContent.trim().includes(text));
const settle = async (ms = 60) => { await act(async () => { await new Promise(r => setTimeout(r, ms)); }); };
const type = async (el, value) => {
  const setter = Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value').set;
  await act(async () => {
    setter.call(el, value);
    el.dispatchEvent(new window.Event('input', { bubbles: true }));
    el.dispatchEvent(new window.Event('change', { bubbles: true }));
  });
};
const click = async el => { await act(async () => {
  el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); }); };

(async () => {
  const root = document.createElement('div');
  root.id = 'root';
  document.body.appendChild(root);
  const { initLang } = await import('../src/api.js');
  initLang();

  await act(async () => { createRoot(root).render(React.createElement(App)); });
  await settle(120);

  console.log('\n=== signing in ===');
  check(!!$('input[type=password]'), 'the login screen is shown to a signed-out visitor');
  check(document.body.textContent.includes('Al-Rwfaa Trading and Contracting W.L.L.'),
    'the company name appears', 'Al-Rwfaa Trading and Contracting W.L.L.');

  await type($('input[type=email]'), 'fin@x.qa');
  await type($('input[type=password]'), 'wrong');
  await click($('button[type=submit]'));
  await settle(120);
  check(!!$('input[type=password]'), 'a wrong password keeps you on the login screen');
  check(document.body.textContent.includes('do not match'), 'and shows the server message');

  await type($('input[type=password]'), 'right');
  await click($('button[type=submit]'));
  await settle(200);
  check(!$('input[type=password]'), 'the right password signs you in');

  console.log('\n=== the shell ===');
  // Regression guard. The sidebar used to slide in and out with rtl:/ltr:
  // transform variants, which out-specify the lg: rule meant to pin it open,
  // so it was invisible on every desktop. jsdom applies no CSS, so the only
  // way to catch this in a headless test is to forbid the pattern.
  const navEl = document.querySelector('nav');
  check(!!navEl, 'a sidebar is rendered');
  const navClasses = [...document.querySelectorAll('nav')].map(n => n.className).join(' ');
  check(!/translate-x/.test(navClasses),
    'the sidebar is not positioned with transform variants', navClasses.slice(0, 80));
  check(/hidden lg:block/.test(navClasses),
    'it is shown by display, which media queries can control reliably');
  const nav = all('nav button span').map(n => n.textContent);
  check(nav.includes('Sales & Receivables') && nav.includes('Projects & Contracts'),
    'navigation rendered', `${nav.length} items`);
  check(all('nav em').map(e => e.textContent).includes('1130'),
    'modules are marked with their control account', all('nav em').map(e => e.textContent).join(' '));

  console.log('\n=== the overdue flag ===');
  check(document.body.textContent.includes('past the end date by more than one day'),
    'the dashboard raises the red banner');
  check(document.body.textContent.includes('PRJ-2602'), 'and names the overdue contract');
  check(!document.body.textContent.includes('PRJ-2601 — 23d'), 'the on-schedule contract is not flagged');
  check(document.body.textContent.includes('Awaiting approval'), 'payments awaiting approval are surfaced');

  console.log('\n=== Arabic ===');
  await click(byText('button', 'عربي'));
  await settle(150);
  check(document.documentElement.dir === 'rtl', 'the page flips to right-to-left', document.documentElement.dir);
  check(document.documentElement.lang === 'ar', 'the language attribute is set');
  const navAr = all('nav button span').map(n => n.textContent);
  check(navAr.includes('المبيعات والذمم المدينة'), 'navigation is translated', navAr.slice(0, 3).join(' · '));
  check(navAr.every(x => !/^Sales|^Purchasing|^Projects/.test(x)), 'nothing is left in English');
  await click(byText('button', 'EN'));
  await settle(150);
  check(document.documentElement.dir === 'ltr', 'and back to English');

  console.log('\n=== the posting slip ===');
  await click(all('nav button').find(b => b.textContent.includes('Sales & Receivables')));
  await settle(200);
  check(document.body.textContent.includes('IPC-2026-00001'), 'the invoice register loads');

  const newBtn = all('button').find(b => /New/.test(b.textContent) && !b.closest('nav'));
  await click(newBtn);
  await settle(120);
  check(!!byText('h3', 'New sales document'), 'the invoice form opens');

  const typeSel = $('.fixed select');
  await act(async () => {
    typeSel.value = 'CERTIFICATE';
    typeSel.dispatchEvent(new window.Event('change', { bubbles: true }));
  });
  await settle(600);

  const saveBtn = all('.fixed footer button').pop();
  check(saveBtn.disabled, 'the save button starts disabled while the amount is zero',
    document.body.textContent.includes('Enter the value of work certified')
      ? 'server: Enter the value of work certified.' : '');

  const grossInput = all('.fixed input[type=number]')[0];
  await type(grossInput, '620000');
  await settle(700);

  const slip = byText('div', 'Posting slip');
  const slipRows = all('.fixed table tbody tr').map(r =>
    [...r.children].map(c => c.textContent.trim()).join(' | '));
  check(previewCalls > 0, 'the form asked the server what it would post', `${previewCalls} preview calls`);
  // assert on what the user actually reads, thousands separators included
  check(document.body.textContent.includes('558,000.00') &&
        document.body.textContent.includes('62,000.00') &&
        document.body.textContent.includes('620,000.00'),
    'the slip shows the real split: 620,000 less 10% retention',
    slipRows.filter(r => /1130|1131|4200/.test(r)).join('   '));
  check(!saveBtn.disabled, 'and the save button is now enabled');
  void slip;

  await type(all('.fixed input[type=number]')[2], '999999');
  await settle(700);
  check(document.body.textContent.includes('recovering more advance than is held'),
    'an over-recovery shows the server refusal in the slip');
  check(all('.fixed footer button').pop().disabled,
    'and the save button goes back to disabled');

  check(lastPreviewBody?.docType === 'CERTIFICATE',
    'the preview body is the document itself, not a re-implementation',
    JSON.stringify({ docType: lastPreviewBody?.docType, grossAmount: lastPreviewBody?.grossAmount }));

  console.log('\n=== projects ===');
  await click($('.fixed header button'));
  await settle(80);
  await click(all('nav button').find(b => b.textContent.includes('Projects & Contracts')));
  await settle(250);
  const tabs = all('button').filter(b => /^(All|Running|Overdue|Completed)/.test(b.textContent.trim()));
  check(tabs.length === 4, 'the register has All / Running / Overdue / Completed',
    tabs.map(x => x.textContent.trim()).join(' · '));
  check(document.body.textContent.includes('Original end date') &&
        document.body.textContent.includes('Current end date'),
    'baseline and current end dates are both shown');

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
