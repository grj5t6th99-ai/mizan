/* Bundles the smoke test and runs it inside jsdom. */
const { build } = require('esbuild');
const { JSDOM } = require('jsdom');
const path = require('path');

(async () => {
  const out = path.join(__dirname, '.bundle.cjs');
  await build({
    entryPoints: [path.join(__dirname, 'smoke.test.jsx')],
    bundle: true, platform: 'node', format: 'cjs', outfile: out,
    jsx: 'automatic', loader: { '.css': 'empty' }, logLevel: 'error',
    define: { 'process.env.NODE_ENV': '"development"' }
  });

  const dom = new JSDOM('<!DOCTYPE html><html><head></head><body></body></html>',
    { url: 'http://localhost/', pretendToBeVisual: true });
  const w = dom.window;
  for (const k of ['window', 'document', 'navigator', 'HTMLElement', 'Event', 'MouseEvent',
                   'Node', 'CustomEvent', 'getComputedStyle', 'localStorage', 'location', 'requestAnimationFrame']) {
    if (globalThis[k] === undefined) globalThis[k] = w[k];
  }
  globalThis.IS_REACT_ACT_ENVIRONMENT = true;
  require(out);
})();
