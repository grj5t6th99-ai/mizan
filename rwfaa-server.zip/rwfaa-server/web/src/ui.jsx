import React, { useState, useEffect, useRef, useCallback } from 'react';
import { api, t, money, qr, fmtDate, isAR, ApiError } from './api';

/* ---------- primitives ---------- */
export const cx = (...a) => a.filter(Boolean).join(' ');

export function Btn({ variant = 'default', size, className, ...p }) {
  return <button {...p} className={cx(
    'rounded-[3px] font-medium whitespace-nowrap transition-colors disabled:opacity-45 disabled:cursor-not-allowed',
    size === 'sm' ? 'px-2.5 py-1 text-xs' : 'px-3.5 py-2 text-sm',
    variant === 'primary'
      ? 'bg-maroon text-white border border-maroon hover:bg-maroon-deep'
      : variant === 'ghost'
        ? 'border border-transparent hover:bg-field text-ink-soft hover:text-ink'
        : 'bg-white border border-rule-strong hover:border-ink hover:bg-field',
    className)} />;
}

export function Field({ label, hint, children, wide }) {
  return (
    <label className={cx('block', wide && 'sm:col-span-2')}>
      <span className={cx('block mb-1 text-ink-soft',
        isAR() ? 'font-ar text-[11px]' : 'font-data text-[9.5px] tracking-[0.13em] uppercase')}>
        {t(label)}
      </span>
      {children}
      {hint && <span className="block mt-1 text-[11.5px] text-ink-faint">{t(hint)}</span>}
    </label>
  );
}

const inputCx = 'w-full bg-field border border-rule rounded-[3px] px-2.5 py-2 text-sm ' +
  'focus:bg-white focus:border-ink-soft focus:outline-none focus:ring-2 focus:ring-maroon/30';

export const Input = ({ numeric, className, ...p }) =>
  <input {...p} className={cx(inputCx, (numeric || p.type === 'date') && 'font-data', className)} />;

export const Select = ({ options = [], className, ...p }) => (
  <select {...p} className={cx(inputCx, className)}>
    {options.map(o => {
      const v = typeof o === 'object' ? o.value : o;
      const l = typeof o === 'object' ? o.label : o;
      return <option key={String(v)} value={v}>{l}</option>;
    })}
  </select>
);

export const Textarea = p => <textarea {...p} className={cx(inputCx, 'min-h-[58px] resize-y')} />;

export function Tag({ tone = 'plain', children }) {
  const tones = {
    plain: 'bg-field text-ink-soft border-rule',
    red: 'bg-maroon-soft text-maroon border-[#E8C8CF]',
    green: 'bg-ledger-soft text-ledger-green border-[#C4DED4]',
    amber: 'bg-amber-soft text-amber border-[#EBD9B4]'
  };
  return <span className={cx('inline-block px-1.5 py-0.5 rounded-sm border text-[10px] align-middle',
    isAR() ? 'font-ar' : 'font-data uppercase tracking-[0.06em]', tones[tone])}>{children}</span>;
}

export const Dot = () =>
  <span className="inline-block w-[7px] h-[7px] rounded-full bg-maroon me-1.5 align-middle" />;

export function Card({ title, actions, children, className }) {
  return (
    <section className={cx('bg-white border border-rule rounded overflow-hidden', className)}>
      {(title || actions) && (
        <header className="flex items-center gap-2.5 px-3.5 py-2.5 border-b border-rule">
          <h3 className={cx('text-[15px]', isAR() ? 'font-arDisplay' : 'font-display')}>{t(title)}</h3>
          <div className="ms-auto flex gap-1.5 items-center">{actions}</div>
        </header>
      )}
      {children}
    </section>
  );
}

export function Stat({ label, value, sub, tone }) {
  return (
    <div className="bg-white border border-rule rounded px-3.5 py-3">
      <span className={cx('block text-ink-soft',
        isAR() ? 'font-ar text-[11px]' : 'font-data text-[9.5px] tracking-[0.13em] uppercase')}>{t(label)}</span>
      <b className={cx('block font-data text-[22px] font-medium mt-1 tracking-tight',
        tone === 'neg' && 'text-maroon', tone === 'pos' && 'text-ledger-green')}>{value}</b>
      {sub && <small className="text-ink-faint text-[11.5px]">{sub}</small>}
    </div>
  );
}

/* ---------- table ---------- */
export function Table({ columns, rows, onRow, empty, footer }) {
  if (!rows?.length) {
    return <div className="py-8 px-3.5 text-center text-ink-soft">
      <b className={cx('block mb-1 text-base text-ink', isAR() ? 'font-arDisplay' : 'font-display')}>
        {t(empty?.title || 'Nothing here yet')}</b>
      {empty?.body && <span className="text-sm">{t(empty.body)}</span>}
    </div>;
  }
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr>{columns.map((c, i) => (
            <th key={i} className={cx(
              'px-2.5 py-2 text-start border-b border-rule-strong text-ink-soft font-medium whitespace-nowrap bg-white',
              isAR() ? 'font-ar text-[11px]' : 'font-data text-[9.5px] tracking-[0.12em] uppercase',
              c.num && 'text-end')} style={c.width ? { width: c.width } : undefined}>{t(c.header)}</th>
          ))}</tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={r.id ?? ri}
                onClick={onRow ? () => onRow(r) : undefined}
                className={cx('border-b border-rule hover:bg-field', onRow && 'cursor-pointer')}>
              {columns.map((c, ci) => (
                <td key={ci} className={cx('px-2.5 py-2 align-top text-sm',
                  c.num && 'text-end font-data tabular-nums whitespace-nowrap',
                  c.tone?.(r) === 'neg' && 'text-maroon', c.tone?.(r) === 'pos' && 'text-ledger-green')}>
                  {c.cell(r, ri)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
        {footer && <tfoot>{footer}</tfoot>}
      </table>
    </div>
  );
}

export const Code = ({ children }) =>
  <span className="font-data text-[12.5px] text-ink-soft" dir="ltr">{children}</span>;
export const Num = ({ children }) =>
  <span className="font-data tabular-nums" dir="ltr">{children}</span>;

/* ---------- modal ---------- */
export function Modal({ title, wide, onClose, footer, children }) {
  useEffect(() => {
    const esc = e => e.key === 'Escape' && onClose?.();
    document.addEventListener('keydown', esc);
    return () => document.removeEventListener('keydown', esc);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 bg-ink/40 flex items-start justify-center p-4 sm:p-8 overflow-y-auto"
         onClick={e => e.target === e.currentTarget && onClose?.()}>
      <div className={cx('bg-white rounded-md w-full shadow-2xl', wide ? 'max-w-4xl' : 'max-w-2xl')}>
        <header className="flex items-center px-4 py-3 border-b border-rule">
          <h3 className={cx('text-[17px]', isAR() ? 'font-arDisplay' : 'font-display')}>{t(title)}</h3>
          <button onClick={onClose} aria-label={t('Close')}
                  className="ms-auto text-2xl leading-none text-ink-soft hover:text-ink">&times;</button>
        </header>
        <div className="p-4">{children}</div>
        {footer && <footer className="flex gap-2 items-center px-4 py-3 border-t border-rule">{footer}</footer>}
      </div>
    </div>
  );
}

/* ============================================================
   The posting slip.

   It does NOT compute anything. It asks the server what the
   document would post, by running the real posting code inside a
   transaction that is rolled back. What you see here is exactly
   what will hit the ledger, or exactly the error that will stop it.
   ============================================================ */
export function PostingSlip({ endpoint, body, onValidity }) {
  const [state, setState] = useState({ status: 'idle' });
  const seq = useRef(0);
  const key = JSON.stringify(body);

  useEffect(() => {
    const mine = ++seq.current;
    setState(s => ({ ...s, status: 'loading' }));
    const timer = setTimeout(async () => {
      try {
        const preview = await api.post(`${endpoint}/preview`, body);
        if (mine !== seq.current) return;
        setState({ status: 'ok', preview });
        onValidity?.(true);
      } catch (err) {
        if (mine !== seq.current) return;
        setState({ status: 'error', message: err instanceof ApiError ? err.message : String(err.message) });
        onValidity?.(false);
      }
    }, 350);                                  // debounce while typing
    return () => clearTimeout(timer);
  }, [key, endpoint]);                        // eslint-disable-line react-hooks/exhaustive-deps

  const { status, preview, message } = state;
  return (
    <div className="sm:col-span-2 border border-rule-strong rounded bg-field overflow-hidden">
      <b className={cx('flex items-center gap-2 px-3 py-2 border-b border-rule text-ink-soft font-medium',
        isAR() ? 'font-ar text-[11px]' : 'font-data text-[9.5px] tracking-[0.15em] uppercase')}>
        {t('Posting slip')}
        <span className="ms-auto normal-case tracking-normal">
          {status === 'loading' && <Tag>…</Tag>}
          {status === 'ok' && <Tag tone="green">{t('Balanced')}</Tag>}
          {status === 'error' && <Tag tone="red">{t('Nothing to post')}</Tag>}
        </span>
      </b>

      {status === 'error' && (
        <p className="px-3 py-2.5 text-sm text-maroon">{message}</p>
      )}

      {preview && status !== 'error' && (
        <>
          <table className="w-full bg-white border-collapse">
            <thead>
              <tr>{[t('Account'), t('Debit'), t('Credit')].map((h, i) => (
                <th key={i} className={cx('px-3 py-1.5 border-b border-rule text-ink-soft font-medium',
                  isAR() ? 'font-ar text-[10px]' : 'font-data text-[9px] tracking-[0.12em] uppercase',
                  i ? 'text-end' : 'text-start')}>{h}</th>))}</tr>
            </thead>
            <tbody>
              {preview.lines.map(l => (
                <tr key={l.line_no} className="border-b border-rule/70">
                  <td className="px-3 py-1.5 text-[12.5px]">
                    <Code>{l.account_code}</Code>{' '}
                    {isAR() ? (l.account_name_ar || l.account_name) : l.account_name}
                  </td>
                  <td className="px-3 py-1.5 text-end font-data text-[12.5px] tabular-nums">
                    {l.debit !== '0.00' ? money(l.debit) : ''}</td>
                  <td className="px-3 py-1.5 text-end font-data text-[12.5px] tabular-nums">
                    {l.credit !== '0.00' ? money(l.credit) : ''}</td>
                </tr>
              ))}
              <tr className="font-bold border-t border-ink">
                <td className="px-3 py-1.5 text-[12.5px]">{t('Total')}</td>
                <td className="px-3 py-1.5 text-end font-data text-[12.5px] tabular-nums">{money(preview.totals.debit)}</td>
                <td className="px-3 py-1.5 text-end font-data text-[12.5px] tabular-nums">{money(preview.totals.credit)}</td>
              </tr>
            </tbody>
          </table>
          <p className="px-3 py-2 text-[12px] text-ink-soft border-t border-rule">
            {isAR()
              ? 'هذا ما سيُرحّل بالضبط. لا يمكن الحفظ حتى يتوازن القيد.'
              : 'This is exactly what will post. It cannot be saved until it balances.'}
          </p>
        </>
      )}
    </div>
  );
}

/* ---------- data loading ---------- */
export function useAsync(fn, deps = []) {
  const [state, setState] = useState({ loading: true });
  const run = useCallback(() => {
    let live = true;
    setState({ loading: true });
    Promise.resolve(fn())
      .then(data => live && setState({ loading: false, data }))
      .catch(error => live && setState({ loading: false, error }));
    return () => { live = false; };
  }, deps);                                   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(run, [run]);
  return { ...state, reload: run };
}

export function Async({ state, children }) {
  if (state.loading) return <div className="py-10 text-center text-ink-soft text-sm">{t('Loading')}…</div>;
  if (state.error) return (
    <div className="py-8 px-4 text-center">
      <p className="text-maroon mb-3">{state.error.message}</p>
      <Btn onClick={state.reload}>{t('Try again')}</Btn>
    </div>
  );
  return children(state.data);
}

/* ---------- toast ---------- */
let pushToast = () => {};
export const toast = m => pushToast(m);
export function Toaster() {
  const [msg, setMsg] = useState(null);
  useEffect(() => {
    pushToast = m => { setMsg(m); setTimeout(() => setMsg(null), 3200); };
  }, []);
  if (!msg) return null;
  return (
    <div role="status" className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[80]
                                  bg-ink text-white px-4 py-2.5 rounded text-sm shadow-lg">{msg}</div>
  );
}

export { money, qr, fmtDate, t, isAR };
