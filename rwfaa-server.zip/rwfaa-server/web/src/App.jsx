import React, { useState, useEffect } from 'react';
import { api, t, isAR, setLang, getLang } from './api';
import { Btn, Field, Input, Toaster, toast, cx, useAsync } from './ui';
import { Dashboard, Sales, Purchases, Cash, Projects } from './pages';
import { Journal, Reports, Parties, Inventory, Payroll, Assets, Accounts, Settings } from './registers';

/* One flat navigation, grouped the way an accountant thinks about
   the work rather than the way the tables are laid out. */
const NAV = [
  ['Overview', [['dash', 'Dashboard', '—', Dashboard]]],
  ['Receivables & Payables', [
    ['parties', 'Customers & Suppliers', 'A/C', Parties],
    ['sales', 'Sales & Receivables', '1130', Sales],
    ['purchases', 'Purchasing & Payables', '2110', Purchases]]],
  ['Treasury & Stock', [
    ['cash', 'Cash & Bank', '1120', Cash],
    ['inventory', 'Inventory & Stock', '1140', Inventory]]],
  ['Assets & People', [
    ['assets', 'Fixed Assets', '1200', Assets],
    ['payroll', 'Staff & Liabilities', '2125', Payroll]]],
  ['Contracts', [['projects', 'Projects & Contracts', '4200', Projects]]],
  ['Accounting', [
    ['journal', 'General Journal', 'JV', Journal],
    ['accounts', 'Chart of Accounts', '000', Accounts],
    ['reports', 'Reports', 'RPT', Reports]]],
  ['Administration', [['settings', 'Company Setup', 'SET', Settings]]]
];
const PAGES = Object.fromEntries(NAV.flatMap(([, items]) => items.map(i => [i[0], i])));

export default function App() {
  const [user, setUser] = useState(undefined);   // undefined = still checking
  const [view, setView] = useState('dash');
  const [focusId, setFocusId] = useState(null);
  const [navOpen, setNavOpen] = useState(false);
  const [lang, setLangState] = useState(getLang());

  useEffect(() => {
    api.get('/auth/me').then(r => setUser(r.user)).catch(() => setUser(null));
  }, []);

  const go = (v, id = null) => { setView(v); setFocusId(id); setNavOpen(false); };
  const switchLang = l => { setLang(l); setLangState(l); };

  if (user === undefined) {
    return <div className="min-h-screen grid place-items-center text-ink-soft">{t('Loading')}…</div>;
  }
  if (!user) return <Login onIn={setUser} lang={lang} onLang={switchLang} />;

  const Current = PAGES[view]?.[3] || Dashboard;

  return (
    <div className="min-h-screen flex flex-col">
      <header className="appbar bg-ink text-[#E9EDEC] flex items-center gap-4 px-4 py-2.5 sticky top-0 z-40">
        <button className="lg:hidden text-xl" onClick={() => setNavOpen(o => !o)} aria-label="Menu">☰</button>
        <div className="flex items-baseline gap-2">
          <b className={cx('text-lg tracking-[0.14em] font-normal',
            isAR() ? 'font-arDisplay tracking-normal' : 'font-display')}>MIZAN</b>
          <span className="font-data text-[9px] tracking-[0.18em] text-ink-faint uppercase">ERP</span>
        </div>
        <span className="hidden sm:block text-[13px] text-[#B9C1BF] truncate">
          {isAR() ? 'شركة الرؤفاء للتجارة والمقاولات' : 'Al-Rwfaa Trading and Contracting W.L.L.'}
        </span>
        <span className="flex-1" />
        <div className="flex rounded-[3px] overflow-hidden border border-[#3C4241]">
          {[['en', 'EN'], ['ar', 'عربي']].map(([code, label]) => (
            <button key={code} onClick={() => switchLang(code)}
              className={cx('px-2.5 py-1 text-xs',
                lang === code ? 'bg-maroon text-white font-semibold' : 'bg-[#2A2E2D] text-[#9AA4A2] hover:text-white')}>
              {label}</button>
          ))}
        </div>
        <button onClick={async () => { await api.post('/auth/logout'); setUser(null); }}
          className="text-xs text-[#9AA4A2] hover:text-white whitespace-nowrap">{t('Sign out')}</button>
      </header>

      <div className="flex flex-1 min-h-0">
        {/* Desktop sidebar: always visible, no transforms.
            An earlier version slid it in and out with rtl:/ltr: variants and
            relied on lg:translate-x-0 to pin it open on wide screens. That
            never worked: [dir="ltr"] .ltr\:-translate-x-full has higher
            specificity than the lg: rule, and specificity beats media
            queries, so the sidebar sat off-screen on every desktop. Two
            plain elements are duller and correct. */}
        <nav className="hidden lg:block bg-white border-e border-rule w-[232px] shrink-0 overflow-y-auto">
          <NavList view={view} go={go} />
        </nav>

        {/* Mobile drawer: only in the DOM when it is open */}
        {navOpen && (
          <div className="lg:hidden fixed inset-0 z-40 flex" role="dialog" aria-modal="true">
            <div className="absolute inset-0 bg-ink/40" onClick={() => setNavOpen(false)} />
            <nav className="relative bg-white border-e border-rule w-[232px] overflow-y-auto">
              <NavList view={view} go={go} />
            </nav>
          </div>
        )}

        <main className="flex-1 min-w-0 overflow-y-auto p-4 sm:p-6 pb-16">
          <Current go={go} focusId={focusId} user={user} />
        </main>
      </div>
      <Toaster />
    </div>
  );
}

function NavList({ view, go }) {
  return (
    <>
      {NAV.map(([group, items]) => (
        <div key={group}>
          <h6 className={cx('px-4 pt-4 pb-1.5 text-ink-faint font-medium',
            isAR() ? 'font-ar text-[11px]' : 'font-data text-[9px] tracking-[0.16em] uppercase')}>
            {t(group)}</h6>
          {items.map(([key, label, code]) => (
            <button key={key} onClick={() => go(key)}
              className={cx('w-full flex items-center gap-2 px-4 py-1.5 text-start border-s-2',
                view === key
                  ? 'text-maroon border-maroon bg-maroon-soft font-semibold'
                  : 'text-ink-soft border-transparent hover:bg-field hover:text-ink')}>
              <em className="font-data text-[10px] not-italic w-6 text-ink-faint" dir="ltr">{code}</em>
              <span className="text-[13px]">{t(label)}</span>
            </button>
          ))}
        </div>
      ))}
      <div className="h-8" />
    </>
  );
}

function Login({ onIn, lang, onLang }) {
  const [v, setV] = useState({ email: '', password: '' });
  const [busy, setBusy] = useState(false);
  const submit = async e => {
    e.preventDefault();
    setBusy(true);
    try { const r = await api.post('/auth/login', v); onIn(r.user); }
    catch (err) { toast(err.message); } finally { setBusy(false); }
  };
  return (
    <div className="min-h-screen grid place-items-center bg-paper p-4">
      <form onSubmit={submit} className="bg-white border border-rule rounded-md p-7 w-full max-w-sm shadow-sm">
        <div className="flex items-baseline gap-2 mb-1">
          <b className={cx('text-2xl tracking-[0.14em] font-normal',
            isAR() ? 'font-arDisplay tracking-normal' : 'font-display')}>MIZAN</b>
          <span className="font-data text-[9px] tracking-[0.18em] text-ink-faint uppercase">ERP</span>
        </div>
        <p className="text-ink-soft text-[13px] mb-5">
          {isAR() ? 'شركة الرؤفاء للتجارة والمقاولات' : 'Al-Rwfaa Trading and Contracting W.L.L.'}
        </p>
        <div className="grid gap-3">
          <Field label="Email">
            <Input type="email" autoComplete="username" required value={v.email}
              onChange={e => setV(s => ({ ...s, email: e.target.value }))} /></Field>
          <Field label="Password">
            <Input type="password" autoComplete="current-password" required value={v.password}
              onChange={e => setV(s => ({ ...s, password: e.target.value }))} /></Field>
          <Btn variant="primary" type="submit" disabled={busy} className="w-full">
            {busy ? `${t('Loading')}…` : t('Sign in')}</Btn>
        </div>
        <div className="flex justify-center gap-3 mt-5 text-xs text-ink-faint">
          {[['en', 'English'], ['ar', 'العربية']].map(([c, l]) => (
            <button key={c} type="button" onClick={() => onLang(c)}
              className={cx(lang === c && 'text-maroon font-semibold')}>{l}</button>
          ))}
        </div>
      </form>
      <Toaster />
    </div>
  );
}
