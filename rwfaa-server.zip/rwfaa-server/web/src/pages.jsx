import React, { useState } from 'react';
import { api, t, money, qr, fmtDate, isAR, today, addDays } from './api';
import {
  Btn, Field, Input, Select, Textarea, Tag, Dot, Card, Stat, Table, Modal,
  PostingSlip, useAsync, Async, toast, Code, Num, cx
} from './ui';

const grid = 'grid gap-3.5 sm:grid-cols-2';

/* A form whose save button is enabled only when the server says the
   entry balances. The slip and the button agree by construction. */
function DocForm({ title, endpoint, initial, fields, onDone, onClose, saveLabel = 'Post entry' }) {
  const [v, setV] = useState(initial);
  const [valid, setValid] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k, val) => setV(s => ({ ...s, [k]: val }));

  const save = async () => {
    setBusy(true);
    try {
      const out = await api.post(endpoint, v);
      toast(`${out.docNo || out.entry_no || t('Save')} ${isAR() ? 'تم الترحيل' : 'posted'}`);
      onDone?.(out);
      onClose();
    } catch (e) { toast(e.message); } finally { setBusy(false); }
  };

  return (
    <Modal title={title} wide onClose={onClose} footer={
      <>
        <span className="flex-1" />
        <Btn onClick={onClose}>{t('Cancel')}</Btn>
        <Btn variant="primary" disabled={!valid || busy} onClick={save}>{t(saveLabel)}</Btn>
      </>
    }>
      <div className={grid}>
        {fields(v, set)}
        <PostingSlip endpoint={endpoint} body={v} onValidity={setValid} />
      </div>
    </Modal>
  );
}

/* ==================== DASHBOARD ==================== */
export function Dashboard({ go }) {
  const s = useAsync(async () => ({
    health: await api.get('/reports/health'),
    schedule: await api.get('/reports/schedule'),
    pending: await api.get('/cash/pending'),
    tb: await api.get('/reports/trial-balance'),
    journal: await api.get('/journal')
  }));
  return (
    <Async state={s}>{d => {
      const late = d.schedule.filter(p => p.is_overdue);
      const bal = code => d.tb.rows.find(r => r.code === code)?.balance || '0';
      const cash = d.tb.rows.filter(r => ['1110', '1111', '1112', '1120', '1121'].includes(r.code))
        .reduce((a, r) => a + Number(r.balance), 0).toFixed(2);
      return (
        <>
          <PageHead title="Dashboard" sub={`${isAR() ? 'المركز كما في' : 'Position as at'} ${fmtDate(today())}`} />
          <div className="grid gap-3.5 grid-cols-[repeat(auto-fit,minmax(170px,1fr))] mb-3.5">
            <Stat label="Cash & bank" value={money(cash)} />
            <Stat label="Receivable" value={money(bal('1130'))} />
            <Stat label="Payable" value={money(String(-Number(bal('2110'))))} />
            <Stat label="Retention" value={money(bal('1131'))} sub={isAR() ? 'لدى العملاء' : 'held by clients'} />
            <Stat label="Overdue projects" value={late.length} tone={late.length ? 'neg' : undefined} />
            <Stat label="Awaiting approval" value={d.pending.length} tone={d.pending.length ? 'neg' : undefined} />
          </div>

          {!d.health.ok && (
            <div className="border border-maroon bg-maroon-soft rounded p-3.5 mb-3.5 text-sm">
              <b className="text-maroon">{t('Ledger health')}</b>
              <pre className="font-data text-[11px] mt-1 whitespace-pre-wrap">{JSON.stringify(d.health, null, 1)}</pre>
            </div>
          )}

          {late.length > 0 && (
            <div className="border border-maroon bg-maroon-soft rounded p-3.5 mb-3.5">
              <b className="text-maroon"><Dot />{late.length} {isAR()
                ? 'عقد تجاوز تاريخ الانتهاء بأكثر من يوم واحد'
                : `contract${late.length > 1 ? 's are' : ' is'} past the end date by more than one day`}</b>
              <div className="text-ink-soft text-sm mt-1">
                {late.map(p => `${p.code} — ${p.days_over}d`).join('  ·  ')}
              </div>
              <Btn size="sm" className="mt-2" onClick={() => go('projects')}>{t('Schedule Watch')} →</Btn>
            </div>
          )}

          {d.pending.length > 0 && (
            <Card title="Awaiting approval" className="mb-3.5">
              <Table columns={[
                { header: 'Date', cell: r => fmtDate(r.doc_date) },
                { header: 'Reference', cell: r => r.reference || '—' },
                { header: 'Narration', cell: r => r.narration || r.purpose },
                { header: 'Raised by', cell: r => r.raised_by },
                { header: 'Amount', num: true, cell: r => money(r.amount) },
                { header: '', cell: r => <ApproveButton id={r.id} onDone={s.reload} /> }
              ]} rows={d.pending} />
            </Card>
          )}

          <Card title="Project schedule watch">
            <Table onRow={p => go('projects', p.id)} columns={[
              { header: '', width: '18px', cell: p => p.is_overdue ? <Dot /> : null },
              { header: 'Code', cell: p => <Code>{p.code}</Code> },
              { header: 'Name', cell: p => p.name },
              { header: 'End', cell: p => fmtDate(p.end_on) },
              { header: 'Status', cell: p => p.is_overdue
                  ? <Tag tone="red">{p.days_over} {isAR() ? 'يوم تأخير' : 'days overdue'}</Tag>
                  : <Tag tone="green">{t('On schedule')}</Tag> }
            ]} rows={d.schedule} empty={{ title: 'No projects registered' }} />
          </Card>

          <div className="h-3.5" />
          <Card title="Latest postings">
            <Table columns={[
              { header: 'Date', cell: j => fmtDate(j.entry_date) },
              { header: 'Voucher', cell: j => <Code>{j.entry_no}</Code> },
              { header: 'Source', cell: j => <Tag>{t(j.source)}</Tag> },
              { header: 'Narration', cell: j => j.memo },
              { header: 'Amount', num: true, cell: j => money(j.amount) }
            ]} rows={d.journal.slice(0, 10)} onRow={j => go('journal', j.id)} />
          </Card>
        </>
      );
    }}</Async>
  );
}

function ApproveButton({ id, onDone }) {
  const [busy, setBusy] = useState(false);
  return <Btn size="sm" variant="primary" disabled={busy} onClick={async e => {
    e.stopPropagation(); setBusy(true);
    try { await api.post(`/cash/${id}/approve`); toast(t('Approve')); onDone?.(); }
    catch (err) { toast(err.message); } finally { setBusy(false); }
  }}>{t('Approve')}</Btn>;
}

export function PageHead({ title, sub, actions }) {
  return (
    <div className="flex items-end gap-4 flex-wrap mb-4">
      <div>
        <h1 className={cx('text-[25px] tracking-tight', isAR() ? 'font-arDisplay' : 'font-display')}>{t(title)}</h1>
        {sub && <p className="text-ink-soft text-[13px] max-w-[56ch]">{sub}</p>}
      </div>
      <div className="ms-auto flex gap-2 flex-wrap">{actions}</div>
    </div>
  );
}

export function Tabs({ value, onChange, items }) {
  return (
    <div className="flex gap-0.5 border-b border-rule mb-4 flex-wrap">
      {items.map(([k, label, badge]) => (
        <button key={k} onClick={() => onChange(k)}
          className={cx('px-3.5 py-2 text-[13px] border-b-2 -mb-px flex gap-1.5 items-center',
            value === k ? 'text-maroon border-maroon font-semibold' : 'text-ink-soft border-transparent hover:text-ink')}>
          {t(label)}{badge != null && <Code>{badge}</Code>}
        </button>
      ))}
    </div>
  );
}

/* ==================== SALES ==================== */
export function Sales() {
  const [tab, setTab] = useState('inv');
  const [form, setForm] = useState(null);
  const s = useAsync(async () => ({
    invoices: await api.get('/sales-invoices'),
    parties: await api.get('/parties'),
    projects: await api.get('/projects'),
    items: await api.get('/items'),
    advances: await api.get('/advances')
  }), [tab]);

  return (
    <Async state={s}>{d => {
      const customers = d.parties.filter(p => p.kind !== 'SUPPLIER');
      return (
        <>
          <PageHead title="Sales & Receivables"
            sub={isAR() ? 'الفواتير التجارية ومستخلصات العقود والتحصيلات' :
              'Trading invoices, contract payment certificates and collections.'}
            actions={<>
              <Btn onClick={() => setForm({ kind: 'receipt' })}>{t('Receipt')}</Btn>
              <Btn onClick={() => setForm({ kind: 'advance' })}>{t('Advance')}</Btn>
              <Btn variant="primary" onClick={() => setForm({ kind: 'invoice' })}>{t('New')} {t('Trading invoice')}</Btn>
            </>} />
          <Tabs value={tab} onChange={setTab} items={[
            ['inv', 'Sales & Receivables', d.invoices.length],
            ['adv', 'Advances', d.advances.filter(a => a.side === 'CUSTOMER').length]]} />

          {tab === 'inv' ? (
            <Card title="Sales & Receivables">
              <Table columns={[
                { header: 'Voucher', cell: i => <Code>{i.doc_no}</Code> },
                { header: 'Date', cell: i => fmtDate(i.invoice_date) },
                { header: 'Customer', cell: i => isAR() ? (i.party_name_ar || i.party_name) : i.party_name },
                { header: 'Type', cell: i => <Tag>{t(labelOf(i.doc_type))}</Tag> },
                { header: 'Gross', num: true, cell: i => money(i.gross_amount) },
                { header: 'Retention', num: true, cell: i => Number(i.retention_amount) ? money(i.retention_amount) : '—' },
                { header: 'Outstanding', num: true, tone: i => Number(i.outstanding) > 0 ? 'neg' : 'pos',
                  cell: i => money(i.outstanding) },
                { header: 'Due', cell: i => Number(i.days_overdue) > 0 && Number(i.outstanding) > 0
                    ? <Tag tone="red">{i.days_overdue}d</Tag> : fmtDate(i.due_date) }
              ]} rows={d.invoices} empty={{ title: 'No invoices raised' }} />
            </Card>
          ) : <AdvanceTable rows={d.advances.filter(a => a.side === 'CUSTOMER')} />}

          {form?.kind === 'invoice' && (
            <SalesInvoiceForm customers={customers} projects={d.projects} items={d.items}
              onClose={() => setForm(null)} onDone={s.reload} />
          )}
          {form?.kind === 'receipt' && (
            <CashForm direction="IN" purpose="SETTLEMENT" title="Receipt"
              parties={customers} projects={d.projects} invoices={d.invoices}
              onClose={() => setForm(null)} onDone={s.reload} />
          )}
          {form?.kind === 'advance' && (
            <CashForm direction="IN" purpose="ADVANCE" title="Advance"
              parties={customers} projects={d.projects}
              onClose={() => setForm(null)} onDone={s.reload} />
          )}
        </>
      );
    }}</Async>
  );
}

const labelOf = t2 => ({ TRADING: 'Trading invoice', CERTIFICATE: 'Payment certificate',
  SERVICE: 'Service invoice', STOCK: 'Goods for stock', PROJECT_COST: 'Direct project cost',
  SUBCONTRACT: 'Subcontract certificate', OVERHEAD: 'Overhead expense' }[t2] || t2);

function AdvanceTable({ rows }) {
  return (
    <Card title="Advances">
      <Table columns={[
        { header: 'Name', cell: r => r.party_name },
        { header: 'Project', cell: r => r.project_code ? <Code>{r.project_code}</Code> : '—' },
        { header: 'Advanced', num: true, cell: r => money(r.advanced) },
        { header: 'Recovered', num: true, cell: r => money(r.recovered) },
        { header: 'Outstanding', num: true, cell: r => <b>{money(r.outstanding)}</b> }
      ]} rows={rows} empty={{ title: 'Nothing here yet' }} />
    </Card>
  );
}

function SalesInvoiceForm({ customers, projects, items, onClose, onDone }) {
  return (
    <DocForm title="New sales document" endpoint="/sales-invoices" onClose={onClose} onDone={onDone}
      initial={{ docType: 'TRADING', partyId: customers[0]?.id, invoiceDate: today(),
                 lines: [{ itemId: items[0]?.id, quantity: '1', unitPrice: items[0]?.sell_price || '0' }] }}
      fields={(v, set) => {
        const cert = v.docType === 'CERTIFICATE';
        return <>
          <Field label="Type">
            <Select value={v.docType} onChange={e => {
              const dt = e.target.value;
              set('docType', dt);
              if (dt === 'CERTIFICATE') { set('lines', undefined); set('grossAmount', '0'); set('retentionPct', '10'); set('advanceRecovered', '0'); set('projectId', v.projectId || projects[0]?.id); }
              else { set('grossAmount', undefined); set('lines', [{ itemId: items[0]?.id, quantity: '1', unitPrice: items[0]?.sell_price || '0' }]); }
            }} options={[
              { value: 'TRADING', label: t('Trading invoice') },
              { value: 'CERTIFICATE', label: t('Payment certificate') },
              { value: 'SERVICE', label: t('Service invoice') }]} />
          </Field>
          <Field label="Customer">
            <Select value={v.partyId} onChange={e => set('partyId', Number(e.target.value))}
              options={customers.map(c => ({ value: c.id, label: c.name }))} />
          </Field>
          <Field label="Date">
            <Input type="date" value={v.invoiceDate} onChange={e => set('invoiceDate', e.target.value)} />
          </Field>
          <Field label="Project">
            <Select value={v.projectId || ''} onChange={e => set('projectId', e.target.value ? Number(e.target.value) : undefined)}
              options={[{ value: '', label: isAR() ? '— بدون مشروع —' : '— No project —' },
                ...projects.map(p => ({ value: p.id, label: `${p.code} — ${p.name}` }))]} />
          </Field>
          {cert ? <>
            <Field label="Work certified (QR)">
              <Input numeric type="number" step="0.01" value={v.grossAmount || ''}
                onChange={e => set('grossAmount', e.target.value)} />
            </Field>
            <Field label="Retention %">
              <Input numeric type="number" step="0.5" value={v.retentionPct || ''}
                onChange={e => set('retentionPct', e.target.value)} />
            </Field>
            <Field label="Advance recovered (QR)" hint="Set against the advance held from this client">
              <Input numeric type="number" step="0.01" value={v.advanceRecovered || ''}
                onChange={e => set('advanceRecovered', e.target.value)} />
            </Field>
          </> : (
            <LineEditor wide label="Lines" rows={v.lines || []} onChange={rows => set('lines', rows)}
              newRow={() => ({ itemId: items[0]?.id, quantity: '1', unitPrice: items[0]?.sell_price || '0' })}
              columns={[
                { key: 'itemId', header: 'Item', type: 'select',
                  options: items.map(i => ({ value: i.id, label: `${i.code} · ${i.name}` })),
                  onSet: (row, val) => { const it = items.find(x => String(x.id) === String(val));
                    return { ...row, itemId: Number(val), unitPrice: it?.sell_price ?? row.unitPrice }; } },
                { key: 'quantity', header: 'Quantity', num: true, width: '110px' },
                { key: 'unitPrice', header: 'Rate', num: true, width: '120px' }
              ]} />
          )}
          <Field label="Narration" wide>
            <Input value={v.narration || ''} onChange={e => set('narration', e.target.value)} />
          </Field>
        </>;
      }} />
  );
}

/* ==================== PURCHASES ==================== */
export function Purchases() {
  const [tab, setTab] = useState('inv');
  const [form, setForm] = useState(null);
  const s = useAsync(async () => ({
    invoices: await api.get('/purchase-invoices'),
    parties: await api.get('/parties'),
    projects: await api.get('/projects'),
    items: await api.get('/items'),
    accounts: await api.get('/accounts'),
    advances: await api.get('/advances')
  }), [tab]);

  return (
    <Async state={s}>{d => {
      const suppliers = d.parties.filter(p => p.kind !== 'CUSTOMER');
      return <>
        <PageHead title="Purchasing & Payables"
          sub={isAR() ? 'فواتير الموردين ومستخلصات مقاولي الباطن والمدفوعات' :
            'Supplier bills, subcontractor certificates and settlements.'}
          actions={<>
            <Btn onClick={() => setForm({ kind: 'payment' })}>{t('Payment')}</Btn>
            <Btn onClick={() => setForm({ kind: 'advance' })}>{t('Advance')}</Btn>
            <Btn variant="primary" onClick={() => setForm({ kind: 'invoice' })}>{t('New')}</Btn>
          </>} />
        <Tabs value={tab} onChange={setTab} items={[
          ['inv', 'Purchasing & Payables', d.invoices.length],
          ['adv', 'Advances', d.advances.filter(a => a.side === 'SUPPLIER').length]]} />
        {tab === 'inv' ? (
          <Card title="Purchasing & Payables">
            <Table columns={[
              { header: 'Voucher', cell: i => <Code>{i.doc_no}</Code> },
              { header: 'Date', cell: i => fmtDate(i.invoice_date) },
              { header: 'Supplier', cell: i => i.party_name },
              { header: 'Type', cell: i => <Tag>{t(labelOf(i.doc_type))}</Tag> },
              { header: 'Reference', cell: i => i.supplier_ref || '—' },
              { header: 'Gross', num: true, cell: i => money(i.gross_amount) },
              { header: 'Retention', num: true, cell: i => Number(i.retention_amount) ? money(i.retention_amount) : '—' },
              { header: 'Outstanding', num: true, tone: i => Number(i.outstanding) > 0 ? 'neg' : 'pos',
                cell: i => money(i.outstanding) }
            ]} rows={d.invoices} empty={{ title: 'No purchase invoices' }} />
          </Card>
        ) : <AdvanceTable rows={d.advances.filter(a => a.side === 'SUPPLIER')} />}

        {form?.kind === 'invoice' && (
          <PurchaseInvoiceForm suppliers={suppliers} projects={d.projects} items={d.items}
            accounts={d.accounts.filter(a => !a.is_group && ['COS', 'EXPENSE'].includes(a.type))}
            onClose={() => setForm(null)} onDone={s.reload} />
        )}
        {form?.kind === 'payment' && (
          <CashForm direction="OUT" purpose="SETTLEMENT" title="Payment"
            parties={suppliers} projects={d.projects} invoices={d.invoices}
            onClose={() => setForm(null)} onDone={s.reload} />
        )}
        {form?.kind === 'advance' && (
          <CashForm direction="OUT" purpose="ADVANCE" title="Advance"
            parties={suppliers} projects={d.projects}
            onClose={() => setForm(null)} onDone={s.reload} />
        )}
      </>;
    }}</Async>
  );
}

function PurchaseInvoiceForm({ suppliers, projects, items, accounts, onClose, onDone }) {
  return (
    <DocForm title="New purchase invoice" endpoint="/purchase-invoices" onClose={onClose} onDone={onDone}
      initial={{ docType: 'STOCK', partyId: suppliers[0]?.id, invoiceDate: today(),
                 lines: [{ itemId: items[0]?.id, quantity: '1', unitCost: '0' }] }}
      fields={(v, set) => {
        const type = v.docType;
        return <>
          <Field label="Type">
            <Select value={type} onChange={e => {
              const dt = e.target.value; set('docType', dt);
              if (dt === 'STOCK') { set('lines', [{ itemId: items[0]?.id, quantity: '1', unitCost: '0' }]); set('grossAmount', undefined); }
              else if (dt === 'SUBCONTRACT') { set('lines', undefined); set('grossAmount', '0'); set('retentionPct', '10'); }
              else { set('lines', [{ expenseAccount: accounts[0]?.code, description: '', amount: '0' }]); set('grossAmount', undefined); }
            }} options={[
              { value: 'STOCK', label: t('Goods for stock') },
              { value: 'PROJECT_COST', label: t('Direct project cost') },
              { value: 'SUBCONTRACT', label: t('Subcontract certificate') },
              { value: 'OVERHEAD', label: t('Overhead expense') }]} />
          </Field>
          <Field label="Supplier">
            <Select value={v.partyId} onChange={e => set('partyId', Number(e.target.value))}
              options={suppliers.map(c => ({ value: c.id, label: c.name }))} />
          </Field>
          <Field label="Date">
            <Input type="date" value={v.invoiceDate} onChange={e => set('invoiceDate', e.target.value)} />
          </Field>
          <Field label="Reference">
            <Input value={v.supplierRef || ''} onChange={e => set('supplierRef', e.target.value)} />
          </Field>
          {type !== 'STOCK' && type !== 'OVERHEAD' && (
            <Field label="Project">
              <Select value={v.projectId || ''} onChange={e => set('projectId', e.target.value ? Number(e.target.value) : undefined)}
                options={[{ value: '', label: '—' }, ...projects.map(p => ({ value: p.id, label: `${p.code} — ${p.name}` }))]} />
            </Field>
          )}
          {type === 'SUBCONTRACT' && <>
            <Field label="Value certified (QR)">
              <Input numeric type="number" step="0.01" value={v.grossAmount || ''}
                onChange={e => set('grossAmount', e.target.value)} />
            </Field>
            <Field label="Retention %">
              <Input numeric type="number" step="0.5" value={v.retentionPct || ''}
                onChange={e => set('retentionPct', e.target.value)} />
            </Field>
          </>}
          {type !== 'SUBCONTRACT' && (
            <Field label="Advance recovered (QR)">
              <Input numeric type="number" step="0.01" value={v.advanceRecovered || ''}
                onChange={e => set('advanceRecovered', e.target.value)} />
            </Field>
          )}
          {type === 'STOCK' && (
            <LineEditor wide label="Lines" rows={v.lines || []} onChange={r => set('lines', r)}
              newRow={() => ({ itemId: items[0]?.id, quantity: '1', unitCost: '0' })}
              columns={[
                { key: 'itemId', header: 'Item', type: 'select',
                  options: items.map(i => ({ value: i.id, label: `${i.code} · ${i.name}` })),
                  onSet: (row, val) => ({ ...row, itemId: Number(val) }) },
                { key: 'quantity', header: 'Quantity', num: true, width: '110px' },
                { key: 'unitCost', header: 'Unit cost', num: true, width: '120px' }
              ]} />
          )}
          {(type === 'PROJECT_COST' || type === 'OVERHEAD') && (
            <LineEditor wide label="Lines" rows={v.lines || []} onChange={r => set('lines', r)}
              newRow={() => ({ expenseAccount: accounts[0]?.code, description: '', amount: '0' })}
              columns={[
                { key: 'expenseAccount', header: 'Account', type: 'select',
                  options: accounts.map(a => ({ value: a.code, label: `${a.code} · ${isAR() ? (a.name_ar || a.name) : a.name}` })) },
                { key: 'description', header: 'Description' },
                { key: 'amount', header: 'Amount', num: true, width: '120px' }
              ]} />
          )}
        </>;
      }} />
  );
}

/* shared multi-line editor */
function LineEditor({ label, rows, onChange, columns, newRow, wide }) {
  const setCell = (i, col, val) => {
    const next = rows.slice();
    next[i] = col.onSet ? col.onSet(next[i], val) : { ...next[i], [col.key]: val };
    onChange(next);
  };
  return (
    <div className={cx('border border-rule-strong rounded bg-field overflow-hidden', wide && 'sm:col-span-2')}>
      <b className={cx('block px-3 py-2 border-b border-rule text-ink-soft font-medium',
        isAR() ? 'font-ar text-[11px]' : 'font-data text-[9.5px] tracking-[0.15em] uppercase')}>{t(label)}</b>
      <div className="overflow-x-auto">
        <table className="w-full bg-white border-collapse">
          <thead><tr>
            {columns.map(c => <th key={c.key} style={c.width ? { width: c.width } : undefined}
              className={cx('px-2 py-1.5 border-b border-rule text-ink-soft font-medium text-start',
                isAR() ? 'font-ar text-[10px]' : 'font-data text-[9px] uppercase tracking-[0.1em]',
                c.num && 'text-end')}>{t(c.header)}</th>)}
            <th className="w-9 border-b border-rule" />
          </tr></thead>
          <tbody>
            {rows.map((row, i) => (
              <tr key={i} className="border-b border-rule/60">
                {columns.map(c => (
                  <td key={c.key} className="px-1.5 py-1">
                    {c.type === 'select'
                      ? <Select className="py-1 text-[13px]" value={row[c.key] ?? ''} options={c.options}
                          onChange={e => setCell(i, c, e.target.value)} />
                      : <Input className={cx('py-1 text-[13px]', c.num && 'text-end')} numeric={c.num}
                          type={c.num ? 'number' : 'text'} step="0.001" value={row[c.key] ?? ''}
                          onChange={e => setCell(i, c, e.target.value)} />}
                  </td>
                ))}
                <td className="px-1.5 py-1">
                  <Btn size="sm" onClick={() => onChange(rows.length > 1 ? rows.filter((_, x) => x !== i) : [newRow()])}>−</Btn>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="px-3 py-2 border-t border-rule">
        <Btn size="sm" onClick={() => onChange([...rows, newRow()])}>+ {t('New')}</Btn>
      </div>
    </div>
  );
}

/* ==================== CASH ==================== */
function CashForm({ direction, purpose, title, parties, projects, invoices = [], onClose, onDone }) {
  const cashAccounts = ['1110', '1111', '1112', '1120', '1121'];
  return (
    <DocForm title={title} endpoint="/cash" onClose={onClose} onDone={onDone} saveLabel="Post"
      initial={{ direction, purpose, docDate: today(), partyId: parties[0]?.id,
                 cashAccount: '1120', amount: '0', method: 'Bank transfer' }}
      fields={(v, set) => {
        const open = invoices.filter(i => String(i.party_id) === String(v.partyId) && Number(i.outstanding) > 0);
        return <>
          <Field label={direction === 'IN' ? 'Customer' : 'Supplier'}>
            <Select value={v.partyId} onChange={e => set('partyId', Number(e.target.value))}
              options={parties.map(p => ({ value: p.id, label: p.name }))} />
          </Field>
          <Field label="Date">
            <Input type="date" value={v.docDate} onChange={e => set('docDate', e.target.value)} />
          </Field>
          <Field label={direction === 'IN' ? 'Received into' : 'Paid from'}>
            <Select value={v.cashAccount} onChange={e => set('cashAccount', e.target.value)}
              options={cashAccounts.map(c => ({ value: c, label: c }))} />
          </Field>
          <Field label="Reference">
            <Input value={v.reference || ''} onChange={e => set('reference', e.target.value)} />
          </Field>
          {purpose === 'ADVANCE' && (
            <Field label="Project">
              <Select value={v.projectId || ''} onChange={e => set('projectId', e.target.value ? Number(e.target.value) : undefined)}
                options={[{ value: '', label: '—' }, ...projects.map(p => ({ value: p.id, label: `${p.code} — ${p.name}` }))]} />
            </Field>
          )}
          {purpose === 'SETTLEMENT' && (
            <Field label="Apply to">
              <Select value={v.allocations?.[0]?.salesInvoiceId || v.allocations?.[0]?.purchaseInvoiceId || ''}
                onChange={e => {
                  const id = e.target.value;
                  if (!id) return set('allocations', undefined);
                  const inv = open.find(i => String(i.id) === String(id));
                  set('amount', inv.outstanding);
                  set('allocations', [direction === 'IN'
                    ? { salesInvoiceId: Number(id), amount: inv.outstanding }
                    : { purchaseInvoiceId: Number(id), amount: inv.outstanding }]);
                }}
                options={[{ value: '', label: isAR() ? '— على الحساب —' : '— On account —' },
                  ...open.map(i => ({ value: i.id, label: `${i.doc_no} · ${money(i.outstanding)}` }))]} />
            </Field>
          )}
          <Field label="Amount (QR)">
            <Input numeric type="number" step="0.01" value={v.amount}
              onChange={e => {
                set('amount', e.target.value);
                if (v.allocations?.length) {
                  set('allocations', [{ ...v.allocations[0], amount: e.target.value }]);
                }
              }} />
          </Field>
          <Field label="Narration" wide>
            <Input value={v.narration || ''} onChange={e => set('narration', e.target.value)} />
          </Field>
        </>;
      }} />
  );
}

export function Cash() {
  const [acct, setAcct] = useState('1120');
  const s = useAsync(async () => ({
    tb: await api.get('/reports/trial-balance'),
    ledger: await api.get(`/accounts/${acct}/ledger`),
    accounts: await api.get('/accounts')
  }), [acct]);
  return (
    <Async state={s}>{d => {
      const cashAccounts = d.accounts.filter(a => ['cash', 'bank'].includes(a.class_tag));
      const bal = c => d.tb.rows.find(r => r.code === c)?.balance || '0';
      return <>
        <PageHead title="Cash & Bank" sub={isAR() ? 'الصناديق والعهد النثرية والحسابات البنكية'
          : 'Cash boxes, petty cash floats and bank accounts.'} />
        <div className="grid gap-3.5 grid-cols-[repeat(auto-fit,minmax(190px,1fr))] mb-3.5">
          {cashAccounts.map(a => (
            <button key={a.code} onClick={() => setAcct(a.code)} className="text-start">
              <Stat label={isAR() ? (a.name_ar || a.name) : a.name} value={money(bal(a.code))}
                sub={a.code} tone={Number(bal(a.code)) < 0 ? 'neg' : undefined} />
            </button>
          ))}
        </div>
        <Card title={`${acct} — ${isAR() ? 'دفتر النقدية' : 'cash book'}`}>
          <Table columns={[
            { header: 'Date', cell: r => fmtDate(r.entry_date) },
            { header: 'Voucher', cell: r => <Code>{r.entry_no}</Code> },
            { header: 'Source', cell: r => <Tag>{t(r.source)}</Tag> },
            { header: 'Narration', cell: r => r.line_memo },
            { header: 'Debit', num: true, cell: r => Number(r.debit) ? money(r.debit) : '' },
            { header: 'Credit', num: true, cell: r => Number(r.credit) ? money(r.credit) : '' },
            { header: 'Balance', num: true, cell: r => money(r.running_balance) }
          ]} rows={d.ledger.slice().reverse()} empty={{ title: 'Nothing here yet' }} />
        </Card>
      </>;
    }}</Async>
  );
}

/* ==================== PROJECTS ==================== */
export function Projects({ focusId, go }) {
  const [filter, setFilter] = useState('all');
  const s = useAsync(async () => ({
    schedule: await api.get('/reports/schedule'),
    profit: await api.get('/reports/projects')
  }), [focusId]);

  return (
    <Async state={s}>{d => {
      if (focusId) {
        const p = d.schedule.find(x => String(x.id) === String(focusId));
        return p ? <ProjectDetail project={p}
          figures={d.profit.find(x => String(x.id) === String(focusId))}
          onBack={() => go('projects')} onChanged={s.reload} /> : null;
      }
      const counts = {
        all: d.schedule.length,
        run: d.schedule.filter(p => !p.is_overdue && !['COMPLETED', 'CLOSED'].includes(p.status)).length,
        late: d.schedule.filter(p => p.is_overdue).length,
        done: d.schedule.filter(p => ['COMPLETED', 'CLOSED'].includes(p.status)).length
      };
      const rows = d.profit.filter(p => filter === 'all'
        || (filter === 'late' && p.is_overdue)
        || (filter === 'done' && ['COMPLETED', 'CLOSED'].includes(p.status))
        || (filter === 'run' && !p.is_overdue && !['COMPLETED', 'CLOSED'].includes(p.status)));

      return <>
        <PageHead title="Projects & Contracts"
          sub={isAR() ? 'تظهر إشارة حمراء على العقد فور تجاوز تاريخ انتهائه بأكثر من يوم واحد'
            : 'A contract is flagged red once its end date is more than one day past.'} />
        <Tabs value={filter} onChange={setFilter} items={[
          ['all', 'All', counts.all], ['run', 'Running', counts.run],
          ['late', 'Overdue', counts.late], ['done', 'Completed', counts.done]]} />
        <Card title="Projects & Contracts">
          <Table onRow={p => go('projects', p.id)} columns={[
            { header: '', width: '18px', cell: p => p.is_overdue ? <Dot /> : null },
            { header: 'Code', cell: p => <Code>{p.code}</Code> },
            { header: 'Name', cell: p => <b>{p.name}</b> },
            { header: 'Client', cell: p => p.client_name },
            { header: 'Original end date', cell: p => fmtDate(p.baseline_end_on) },
            { header: 'Current end date', cell: p => fmtDate(p.end_on) },
            { header: 'Days over', num: true, tone: p => p.is_overdue ? 'neg' : null,
              cell: p => p.is_overdue ? <b>{p.days_over}</b> : '—' },
            { header: 'Contract value', num: true, cell: p => money(p.contract_value) },
            { header: 'Certified', num: true, cell: p => money(p.certified) },
            { header: 'Cost', num: true, cell: p => money(p.cost) },
            { header: 'Margin', num: true, tone: p => Number(p.margin) < 0 ? 'neg' : 'pos',
              cell: p => <b>{money(p.margin)}</b> }
          ]} rows={rows} empty={{ title: filter === 'late' ? 'No overdue projects' : 'No projects registered' }} />
        </Card>
      </>;
    }}</Async>
  );
}

function ProjectDetail({ project: p, figures, onBack, onChanged }) {
  const [revising, setRevising] = useState(false);
  const revs = useAsync(() => api.get(`/projects/${p.id}/revisions`), [p.id, revising]);
  const pct = Number(p.contract_value) > 0
    ? Math.min(Math.round((Number(figures?.certified || 0) / Number(p.contract_value)) * 100), 999) : 0;

  return <>
    <PageHead title={`${p.code} — ${p.name}`} sub={p.scope}
      actions={<>
        <Btn onClick={onBack}>{t('Back')}</Btn>
        <Btn variant="primary" onClick={() => setRevising(true)}>{t('Revise end date')}</Btn>
      </>} />
    {p.is_overdue && (
      <div className="border border-maroon bg-maroon-soft rounded p-3.5 mb-3.5 text-sm">
        <b className="text-maroon"><Dot />{isAR() ? `متأخر بمقدار ${p.days_over} يوماً`
          : `Overdue by ${p.days_over} days`}</b>{' — '}{fmtDate(p.end_on)}
      </div>
    )}
    <div className="grid gap-3.5 grid-cols-[repeat(auto-fit,minmax(170px,1fr))] mb-3.5">
      <Stat label="Contract value" value={money(p.contract_value)} sub={figures?.client_name} />
      <Stat label="Certified" value={money(figures?.certified)} sub={`${pct}%`} />
      <Stat label="Cost" value={money(figures?.cost)} />
      <Stat label="Margin" value={money(figures?.margin)}
        tone={Number(figures?.margin) < 0 ? 'neg' : 'pos'}
        sub={figures?.margin_pct != null ? `${figures.margin_pct}%` : ''} />
      <Stat label="Slip" value={`${p.slip_days > 0 ? '+' : ''}${p.slip_days}`}
        tone={p.slip_days > 0 ? 'neg' : undefined} sub={isAR() ? 'يوم' : 'days'} />
      <Stat label="Revisions" value={p.revision_count} />
    </div>

    <Card title="Schedule & delivery" className="mb-3.5">
      <div className="p-3.5">
        <table className="w-full text-sm">
          <tbody>
            {[['Start', fmtDate(p.starts_on)],
              ['Original end date', fmtDate(p.baseline_end_on)],
              ['Current end date', <b key="e">{fmtDate(p.end_on)}</b>],
              ['Status', p.is_overdue
                ? <Tag key="s" tone="red">{p.days_over} {isAR() ? 'يوم' : 'days'}</Tag>
                : <Tag key="s" tone="green">{t('On schedule')}</Tag>]
            ].map(([k, v2], i) => (
              <tr key={i} className="border-b border-rule/60">
                <td className="py-1.5">{t(k)}</td>
                <td className="py-1.5 text-end font-data">{v2}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="h-1.5 bg-rule rounded mt-3 overflow-hidden">
          <i className={cx('block h-full', p.is_overdue ? 'bg-maroon' : 'bg-ledger-green')}
             style={{ width: `${Math.min(pct, 100)}%` }} />
        </div>
      </div>
    </Card>

    <Card title="Revision history">
      <Async state={revs}>{rows => (
        <Table columns={[
          { header: 'Date', cell: r => fmtDate(r.logged_on) },
          { header: 'From', cell: r => fmtDate(r.from_end_on) },
          { header: 'To', cell: r => fmtDate(r.to_end_on) },
          { header: 'Days over', num: true, tone: r => r.days_moved > 0 ? 'neg' : 'pos',
            cell: r => (r.days_moved > 0 ? '+' : '') + r.days_moved },
          { header: 'Reason', cell: r => r.reason },
          { header: 'Approved by', cell: r => r.approved_by }
        ]} rows={rows} empty={{
          title: 'Nothing here yet',
          body: isAR() ? 'لم يتغير تاريخ الانتهاء عن التاريخ الأصلي'
            : 'The end date has never been moved from the original contract date.' }} />
      )}</Async>
    </Card>

    {revising && <ReviseForm project={p} onClose={() => setRevising(false)}
      onDone={() => { setRevising(false); onChanged?.(); }} />}
  </>;
}

function ReviseForm({ project, onClose, onDone }) {
  const [v, setV] = useState({ toEndOn: project.end_on?.slice(0, 10) || today(),
    reason: 'Client-approved extension of time', approvedBy: '', loggedOn: today() });
  const [busy, setBusy] = useState(false);
  const set = (k, val) => setV(s => ({ ...s, [k]: val }));
  const slip = Math.round((new Date(v.toEndOn) - new Date(project.baseline_end_on)) / 86400000);

  return (
    <Modal title="Revise end date" wide onClose={onClose} footer={<>
      <span className="flex-1" />
      <Btn onClick={onClose}>{t('Cancel')}</Btn>
      <Btn variant="primary" disabled={busy || !v.approvedBy.trim()} onClick={async () => {
        setBusy(true);
        try { await api.post(`/projects/${project.id}/revise-end-date`, v); toast(t('Save')); onDone(); }
        catch (e) { toast(e.message); } finally { setBusy(false); }
      }}>{t('Save')}</Btn>
    </>}>
      <div className={grid}>
        <Field label="Current end date"><Input disabled value={fmtDate(project.end_on)} /></Field>
        <Field label="New end date">
          <Input type="date" value={v.toEndOn} onChange={e => set('toEndOn', e.target.value)} /></Field>
        <Field label="Reason">
          <Select value={v.reason} onChange={e => set('reason', e.target.value)} options={[
            'Client-approved extension of time', 'Variation order issued', 'Access to site delayed',
            'Material delivery delay', 'Weather / force majeure', 'Internal re-plan',
            'Correcting a data entry error']} /></Field>
        <Field label="Approved by">
          <Input value={v.approvedBy} onChange={e => set('approvedBy', e.target.value)} /></Field>
        <div className="sm:col-span-2 border border-rule-strong rounded bg-field p-3 text-sm">
          {t('Original end date')}: <b>{fmtDate(project.baseline_end_on)}</b>{' · '}
          {t('Slip')}: <b className={slip > 0 ? 'text-maroon' : ''}>{slip > 0 ? '+' : ''}{slip}</b>
          <p className="text-ink-soft text-[12px] mt-1">
            {isAR() ? 'يُسجَّل هذا التغيير في سجل التعديلات ولا يمكن حذفه. التاريخ الأصلي لا يتغير أبداً.'
              : 'This is written to the revision log and cannot be deleted. The original date never changes.'}
          </p>
        </div>
      </div>
    </Modal>
  );
}
