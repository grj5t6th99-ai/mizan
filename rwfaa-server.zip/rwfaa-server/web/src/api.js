/* ---------- talking to the server ---------- */
const base = '/api';

export class ApiError extends Error {
  constructor(message, status, code) { super(message); this.status = status; this.code = code; }
}

async function call(method, path, body) {
  const res = await fetch(base + path, {
    method,
    credentials: 'same-origin',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined
  });
  const text = await res.text();
  let json = null;
  try { json = text ? JSON.parse(text) : null; } catch { /* not json */ }
  if (!res.ok) {
    throw new ApiError(json?.error || `Request failed (${res.status})`, res.status, json?.code);
  }
  return json;
}

export const api = {
  get: (p, q) => call('GET', p + (q ? '?' + new URLSearchParams(
    Object.fromEntries(Object.entries(q).filter(([, v]) => v != null && v !== ''))) : '')),
  post: (p, b) => call('POST', p, b),
  patch: (p, b) => call('PATCH', p, b)
};

/* ---------- money and dates ---------- */
/** Amounts arrive as decimal strings and stay strings. Formatting is
 *  presentation only; nothing here does arithmetic on them. */
export function money(v) {
  if (v == null || v === '') return '—';
  const n = String(v);
  const neg = n.startsWith('-');
  const [int, frac = '00'] = n.replace('-', '').split('.');
  return (neg ? '-' : '') + Number(int).toLocaleString('en-US') + '.' + frac.padEnd(2, '0').slice(0, 2);
}
export const qr = v => (isAR() ? money(v) + ' ر.ق' : 'QR ' + money(v));
export const today = () => new Date().toISOString().slice(0, 10);
export const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

const MONTHS_AR = ['يناير','فبراير','مارس','أبريل','مايو','يونيو',
                   'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
export function fmtDate(v) {
  if (!v) return '—';
  const iso = String(v).slice(0, 10);
  const d = new Date(iso + 'T00:00:00Z');
  if (isNaN(d)) return iso;
  return isAR()
    ? `${d.getUTCDate()} ${MONTHS_AR[d.getUTCMonth()]} ${d.getUTCFullYear()}`
    : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' });
}

/* ---------- language ---------- */
let LANG = 'en';
export const isAR = () => LANG === 'ar';
export const getLang = () => LANG;

const AR = {
  Dashboard: 'لوحة المعلومات', 'Customers & Suppliers': 'العملاء والموردون',
  'Sales & Receivables': 'المبيعات والذمم المدينة', 'Purchasing & Payables': 'المشتريات والذمم الدائنة',
  'Cash & Bank': 'النقد والبنوك', 'Inventory & Stock': 'المخزون والأصناف',
  'Fixed Assets': 'الأصول الثابتة', 'Staff & Liabilities': 'الموظفون والالتزامات',
  'Projects & Contracts': 'المشاريع والعقود', 'General Journal': 'دفتر اليومية',
  'Chart of Accounts': 'دليل الحسابات', Reports: 'التقارير', 'Users & Access': 'المستخدمون والصلاحيات',
  'Company Setup': 'إعدادات الشركة', Overview: 'نظرة عامة',
  'Receivables & Payables': 'الذمم المدينة والدائنة', 'Treasury & Stock': 'الخزينة والمخزون',
  'Assets & People': 'الأصول والموظفون', Contracts: 'العقود', Accounting: 'المحاسبة',
  Administration: 'الإدارة',

  'Sign in': 'تسجيل الدخول', 'Sign out': 'تسجيل الخروج', Email: 'البريد الإلكتروني',
  Password: 'كلمة المرور', 'Signed in as': 'المستخدم الحالي',
  'Change password': 'تغيير كلمة المرور', 'Current password': 'كلمة المرور الحالية',
  'New password': 'كلمة المرور الجديدة',

  Save: 'حفظ', Cancel: 'إلغاء', Close: 'إغلاق', Post: 'ترحيل', 'Post entry': 'ترحيل القيد',
  New: 'جديد', Edit: 'تعديل', Approve: 'اعتماد', Search: 'بحث', Print: 'طباعة',
  Refresh: 'تحديث', Back: 'رجوع', Loading: 'جارٍ التحميل', 'Try again': 'حاول مرة أخرى',

  'Posting slip': 'مسودة القيد', Balanced: 'متوازن', 'Nothing to post': 'لا يوجد ما يُرحّل',
  Account: 'الحساب', Debit: 'مدين', Credit: 'دائن', Total: 'الإجمالي',
  Date: 'التاريخ', Code: 'الرمز', Name: 'الاسم', Description: 'البيان', Type: 'النوع',
  Status: 'الحالة', Amount: 'المبلغ', Balance: 'الرصيد', Narration: 'البيان',
  Reference: 'المرجع', Project: 'المشروع', Client: 'العميل', Customer: 'العميل',
  Supplier: 'المورد', Outstanding: 'المتبقي', Due: 'الاستحقاق', Gross: 'الإجمالي',
  Retention: 'المحتجزات', Receivable: 'مدينون', Payable: 'دائنون', Voucher: 'السند',
  Source: 'المصدر', 'Posted by': 'رحّله', Quantity: 'الكمية', Rate: 'السعر',
  'Unit cost': 'تكلفة الوحدة', Item: 'الصنف', 'On hand': 'المتوفر', 'Avg cost': 'متوسط التكلفة',
  'Stock value': 'قيمة المخزون', Employee: 'الموظف', Basic: 'الراتب الأساسي',
  Allowances: 'البدلات', 'Contract value': 'قيمة العقد', Certified: 'معتمد', Cost: 'التكلفة',
  Margin: 'هامش الربح', Start: 'البداية', End: 'النهاية', 'Original end date': 'تاريخ الانتهاء الأصلي',
  'Current end date': 'تاريخ الانتهاء الحالي', Slip: 'الانزلاق', Revisions: 'التعديلات',
  Overdue: 'متأخر', 'On schedule': 'ضمن الجدول', Running: 'جارٍ', Completed: 'منجز', All: 'الكل',
  'Days over': 'أيام التأخير', Reason: 'السبب', 'Approved by': 'اعتمده',
  'Revise end date': 'تعديل تاريخ الانتهاء', 'Revision history': 'سجل التعديلات',

  'Trial Balance': 'ميزان المراجعة', 'Profit & Loss': 'الأرباح والخسائر',
  'Balance Sheet': 'قائمة المركز المالي', 'Receivables Ageing': 'أعمار الذمم المدينة',
  'Payables Ageing': 'أعمار الذمم الدائنة', 'Project Profitability': 'ربحية المشاريع',
  'Schedule Watch': 'متابعة الجداول الزمنية', Revenue: 'الإيرادات',
  'Cost of sales': 'تكلفة المبيعات', 'Gross profit': 'مجمل الربح', Expenses: 'المصروفات',
  'Net profit': 'صافي الربح', Assets: 'الأصول', Liabilities: 'الالتزامات', Equity: 'حقوق الملكية',
  'Cash & bank': 'النقد والبنوك', 'Overdue projects': 'مشاريع متأخرة',
  'Awaiting approval': 'بانتظار الاعتماد', 'Nothing here yet': 'لا يوجد شيء بعد',
  'Trading invoice': 'فاتورة تجارية', 'Payment certificate': 'مستخلص عقد',
  'Service invoice': 'فاتورة خدمات', 'Goods for stock': 'بضاعة للمخزون',
  'Direct project cost': 'تكلفة مشروع مباشرة', 'Subcontract certificate': 'مستخلص مقاول باطن',
  'Overhead expense': 'مصروف عام', Receipt: 'سند قبض', Payment: 'سند صرف',
  Advance: 'دفعة مقدمة', Settlement: 'تسوية', Advances: 'الدفعات المقدمة',
  'Run payroll': 'تشغيل الرواتب', 'Accrue gratuity': 'استحقاق مكافأة نهاية الخدمة',
  'Run depreciation': 'احتساب الإهلاك', 'Ledger health': 'سلامة الدفاتر'
};

export const t = s => (isAR() && AR[s] != null ? AR[s] : s);

export function setLang(l) {
  LANG = l === 'ar' ? 'ar' : 'en';
  const r = document.documentElement;
  r.lang = LANG;
  r.dir = isAR() ? 'rtl' : 'ltr';
  try { localStorage.setItem('mizan.lang', LANG); } catch { /* private mode */ }
}
export function initLang() {
  let saved = null;
  try { saved = localStorage.getItem('mizan.lang'); } catch { /* private mode */ }
  const fromUrl = new URLSearchParams(location.search).get('lang');
  setLang(fromUrl || saved || 'en');
}
