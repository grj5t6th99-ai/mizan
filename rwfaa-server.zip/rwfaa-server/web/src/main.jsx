import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { initLang } from './api';
import './index.css';

initLang();
createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
