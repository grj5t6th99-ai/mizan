import React, { useState } from 'react';
import { api, t, money, fmtDate, isAR, today } from './api';
import {
  Btn, Field, Input, Select, Tag, Card, Stat, Table, Modal, PostingSlip,
  useAsync, Async, toast, Code, cx
} from './ui';
import { PageHead, Tabs } from './pages';

const grid = 'grid gap-3.5 sm:grid-cols-2';

/* ==================== JOURNAL ==================== */
export function Journal({ focusId, go }) {
  const [range, setRange] = useState({ from: '', to: '', source: '' });
  const [open, setOpen] = useState(focusId || null);
  const [manual, setManual] = useState(false);
  const s = useAsync(() => api.get('/journal', range), [range.from, range.to, range.source, manual]);

  return <>
    <PageHead title="General Journal"
      sub={isAR() ? 'كل قيد في النظام بترتيب التاريخ مع مستند المصدر'
        : 'Every posting in the system, in date order, with its source document.'}
      actions={<Btn variant="primary" onClick={() => setManual(true)}>{t('New')}</Btn>} />
    <div className="flex gap-2 flex-wrap items-end mb-3.5">
      <Field label="From"><Input type="date" value={range.from}
        onChange={e => setRange(r => ({ ...r, from: e.target.value }))} /></Field>
      <Field label="To"><Input type="date" value={range.to}
        onChange={e => setRange(r => ({ ...r, to: e.target.value }))} /></Field>
    </div>
    <Card title="General Journal">
      <Async state={s}>{rows => (
        <Table onRow={j => setOpen(j.id)} columns={[
          { header: 'Date', cell: j => fmtDate(j.entry_date) },
          { header: 'Voucher', cell: j => <Code>{j.entry_no}</Code> },
          { header: 'Source', cell: j => <Tag>{t(j.source)}</Tag> },
          { header: 'Narration', cell: j => j.memo },
          { header: 'Posted by', cell: j => j.posted_by_name },
          { header: 'Status', cell: j => j.is_reversed ? <Tag tone="red">{isAR() ? 'معكوس' : 'Reversed'}</Tag> : null },
          { header: 'Amount', num: true, cell: j => money(j.amount) }
        ]} rows={rows} empty={{ title: 'Nothing here yet' }} />
      )}</Async>
    </Card>
    {open && <EntryModal id={open} onClose={() => { setOpen(null); go?.('journal'); }} onChanged={s.reload} />}
    {manual && <ManualJournal onClose={() => setManual(false)} onDone={() => setManual(false)} />}
  </>;
}

function EntryModal({ id, onClose, onChanged }) {
  const s = useAsync(() => api.get(`/journal/${id}`), [id]);
  return (
    <Modal title="Voucher" wide onClose={onClose} footer={<>
      <span className="flex-1" />
      <Btn onClick={async () => {
        try { await api.post(`/journal/${id}/reverse`, { date: today() }); toast(t('Save')); onChanged?.(); onClose(); }
        catch (e) { toast(e.message); }
      }}>{isAR() ? 'عكس القيد' : 'Reverse'}</Btn>
      <Btn variant="primary" onClick={onClose}>{t('Close')}</Btn>
    </>}>
      <Async state={s}>{e => <>
        <p className="mb-3 text-sm"><Code>{e.entry_no}</Code> · {fmtDate(e.entry_date)} · {e.posted_by_name}
          <br /><b>{e.memo}</b></p>
        <Table columns={[
          { header: 'Account', cell: l => <><Code>{l.account_code}</Code>{' '}
            {isAR() ? (l.account_name_ar || l.account_name) : l.account_name}</> },
          { header: 'Narration', cell: l => l.line_memo },
          { header: 'Debit', num: true, cell: l => Number(l.debit) ? money(l.debit) : '' },
          { header: 'Credit', num: true, cell: l => Number(l.credit) ? money(l.credit) : '' }
        ]} rows={e.lines} />
      </>}</Async>
    </Modal>
  );
}

function ManualJournal({ onClose, onDone }) {
  const accounts = useAsync(() => api.get('/accounts'));
  const [v, setV] = useState({ date: today(), memo: '', source: 'Journal',
    lines: [{ account: '', debit: '0', credit: '0' }, { account: '', debit: '0', credit: '0' }] });
  const [valid, setValid] = useState(false);
  const setLine = (i, k, val) => setV(s => {
    const lines = s.lines.slice(); lines[i] = { ...lines[i], [k]: val }; return { ...s, lines };
  });
  return (
    <Modal title="Manual journal voucher" wide onClose={onClose} footer={<>
      <span className="flex-1" />
      <Btn onClick={onClose}>{t('Cancel')}</Btn>
      <Btn variant="primary" disabled={!valid} onClick={async () => {
        try { const r = await api.post('/journal', v); toast(r.entry_no); onDone(); }
        catch (e) { toast(e.message); }
      }}>{t('Post entry')}</Btn>
    </>}>
      <Async state={accounts}>{list => {
        const postable = list.filter(a => !a.is_group);
        return (
          <div className={grid}>
            <Field label="Date"><Input type="date" value={v.date}
              onChange={e => setV(s => ({ ...s, date: e.target.value }))} /></Field>
            <Field label="Narration"><Input value={v.memo}
              onChange={e => setV(s => ({ ...s, memo: e.target.value }))} /></Field>
            <div className="sm:col-span-2 border border-rule-strong rounded overflow-hidden">
              <table className="w-full bg-white">
                <thead><tr>{['Account', 'Debit', 'Credit'].map(h =>
                  <th key={h} className="px-2 py-1.5 text-start font-data text-[9px] uppercase
                    tracking-[0.1em] text-ink-soft border-b border-rule">{t(h)}</th>)}
                  <th className="w-9 border-b border-rule" /></tr></thead>
                <tbody>{v.lines.map((l, i) => (
                  <tr key={i}>
                    <td className="px-1.5 py-1"><Select className="py-1 text-[13px]" value={l.account}
                      onChange={e => setLine(i, 'account', e.target.value)}
                      options={[{ value: '', label: '—' }, ...postable.map(a =>
                        ({ value: a.code, label: `${a.code} · ${isAR() ? (a.name_ar || a.name) : a.name}` }))]} /></td>
                    <td className="px-1.5 py-1"><Input numeric type="number" step="0.01" className="py-1 text-end text-[13px]"
                      value={l.debit} onChange={e => setLine(i, 'debit', e.target.value)} /></td>
                    <td className="px-1.5 py-1"><Input numeric type="number" step="0.01" className="py-1 text-end text-[13px]"
                      value={l.credit} onChange={e => setLine(i, 'credit', e.target.value)} /></td>
                    <td className="px-1.5 py-1"><Btn size="sm" onClick={() => setV(s => ({
                      ...s, lines: s.lines.length > 2 ? s.lines.filter((_, x) => x !== i) : s.lines }))}>−</Btn></td>
                  </tr>))}</tbody>
              </table>
              <div className="px-3 py-2 border-t border-rule bg-field">
                <Btn size="sm" onClick={() => setV(s => ({ ...s,
                  lines: [...s.lines, { account: '', debit: '0', credit: '0' }] }))}>+ {t('New')}</Btn>
              </div>
            </div>
            <PostingSlip endpoint="/journal" body={v} onValidity={setValid} />
          </div>
        );
      }}</Async>
    </Modal>
  );
}

/* ==================== REPORTS ==================== */
const REPORTS = [
  ['tb', 'Trial Balance'], ['pl', 'Profit & Loss'], ['bs', 'Balance Sheet'],
  ['ar', 'Receivables Ageing'], ['ap', 'Payables Ageing'],
  ['proj', 'Project Profitability'], ['sched', 'Schedule Watch']
];

export function Reports() {
  const [tab, setTab] = useState('tb');
  const [range, setRange] = useState({ from: `${new Date().getFullYear()}-01-01`, to: today() });
  const company = useAsync(() => api.get('/company'));
  const s = useAsync(async () => {
    if (tab === 'tb') return api.get('/reports/trial-balance', range);
    if (tab === 'pl') return api.get('/reports/profit-and-loss', range);
    if (tab === 'bs') return api.get('/reports/balance-sheet', { asAt: range.to });
    if (tab === 'ar') return api.get('/reports/ageing/AR');
    if (tab === 'ap') return api.get('/reports/ageing/AP');
    if (tab === 'proj') return api.get('/reports/projects');
    return api.get('/reports/schedule');
  }, [tab, range.from, range.to]);

  const name = a => isAR() ? (a.name_ar || a.name) : a.name;

  return <>
    <PageHead title="Reports"
      sub={isAR() ? 'قوائم تُشتق مباشرة من دفتر اليومية، فلا يمكن أن تختلف عن الدفاتر'
        : 'Derived live from the journal, so a report cannot disagree with the ledger.'}
      actions={<Btn onClick={() => window.print()}>{t('Print')}</Btn>} />
    <Tabs value={tab} onChange={setTab} items={REPORTS} />
    <div className="flex gap-2 items-end mb-3.5 no-print">
      <Field label="From"><Input type="date" value={range.from}
        onChange={e => setRange(r => ({ ...r, from: e.target.value }))} /></Field>
      <Field label="To"><Input type="date" value={range.to}
        onChange={e => setRange(r => ({ ...r, to: e.target.value }))} /></Field>
    </div>

    <Async state={company}>{co => (
      <Async state={s}>{d => (
        <Sheet company={co} title={REPORTS.find(r => r[0] === tab)[1]}
          period={tab === 'bs' ? `${isAR() ? 'كما في' : 'As at'} ${fmtDate(range.to)}`
            : `${fmtDate(range.from)} — ${fmtDate(range.to)}`}>
          {tab === 'tb' && <>
            <Table columns={[
              { header: 'Code', cell: r => <Code>{r.code}</Code> },
              { header: 'Account', cell: name },
              { header: 'Debit', num: true, cell: r => Number(r.balance) > 0 ? money(r.balance) : '' },
              { header: 'Credit', num: true, cell: r => Number(r.balance) < 0 ? money(String(-r.balance)) : '' }
            ]} rows={d.rows} footer={
              <tr className="font-bold border-t-2 border-ink">
                <td colSpan={2} className="px-2.5 py-2">{t('Total')}</td>
                <td className="px-2.5 py-2 text-end font-data">{money(d.totals.debit)}</td>
                <td className="px-2.5 py-2 text-end font-data">{money(d.totals.credit)}</td>
              </tr>} />
            <p className={cx('mt-3 text-sm', d.balanced ? 'text-ledger-green' : 'text-maroon')}>
              {d.balanced ? (isAR() ? 'ميزان المراجعة متوازن.' : 'The trial balance balances.')
                : `${isAR() ? 'فرق' : 'Out by'} ${money(d.totals.difference)}`}</p>
          </>}

          {tab === 'pl' && <StatementRows groups={[
            ['Revenue', d.revenue, d.totals.revenue],
            ['Cost of sales', d.costOfSales, d.totals.costOfSales],
            [null, null, null, 'Gross profit', d.totals.grossProfit],
            ['Expenses', d.expenses, d.totals.expenses],
            [null, null, null, 'Net profit', d.totals.netProfit]
          ]} name={name} />}

          {tab === 'bs' && <>
            <StatementRows groups={[
              ['Current assets', d.currentAssets],
              ['Non-current assets', d.nonCurrentAssets],
              [null, null, null, 'Assets', d.totals.assets],
              ['Current liabilities', d.currentLiabilities],
              ['Non-current liabilities', d.nonCurrentLiabilities],
              ['Equity', d.equity],
              [null, null, null, 'Net profit', d.profitForPeriod],
              [null, null, null, 'Liabilities', d.totals.liabilitiesAndEquity]
            ]} name={name} />
            <p className={cx('mt-3 text-sm', d.balanced ? 'text-ledger-green' : 'text-maroon')}>
              {d.balanced ? (isAR() ? 'الميزانية متوازنة.' : 'The balance sheet balances.')
                : `${isAR() ? 'فرق' : 'Out by'} ${money(d.totals.difference)}`}</p>
          </>}

          {(tab === 'ar' || tab === 'ap') && (
            <Table columns={[
              { header: tab === 'ar' ? 'Customer' : 'Supplier', cell: r => r.party_name },
              { header: 'Not due', num: true, cell: r => money(r.not_due) },
              { header: '1–30', num: true, cell: r => money(r.d1_30) },
              { header: '31–60', num: true, cell: r => money(r.d31_60) },
              { header: '61–90', num: true, tone: () => 'neg', cell: r => money(r.d61_90) },
              { header: '90+', num: true, tone: () => 'neg', cell: r => money(r.d90_plus) },
              { header: 'Total', num: true, cell: r => <b>{money(r.total)}</b> }
            ]} rows={d.rows} empty={{ title: 'Nothing here yet' }} />
          )}

          {tab === 'proj' && (
            <Table columns={[
              { header: 'Code', cell: p => <Code>{p.code}</Code> },
              { header: 'Name', cell: p => p.name },
              { header: 'Contract value', num: true, cell: p => money(p.contract_value) },
              { header: 'Certified', num: true, cell: p => money(p.certified) },
              { header: 'Cost', num: true, cell: p => money(p.cost) },
              { header: 'Margin', num: true, tone: p => Number(p.margin) < 0 ? 'neg' : 'pos',
                cell: p => money(p.margin) },
              { header: '%', num: true, cell: p => p.margin_pct != null ? `${p.margin_pct}%` : '—' }
            ]} rows={d} />
          )}

          {tab === 'sched' && (
            <Table columns={[
              { header: 'Code', cell: p => <Code>{p.code}</Code> },
              { header: 'Name', cell: p => p.name },
              { header: 'Start', cell: p => fmtDate(p.starts_on) },
              { header: 'Original end date', cell: p => fmtDate(p.baseline_end_on) },
              { header: 'Current end date', cell: p => <b>{fmtDate(p.end_on)}</b> },
              { header: 'Slip', num: true, tone: p => p.slip_days > 0 ? 'neg' : null,
                cell: p => p.slip_days > 0 ? `+${p.slip_days}` : (p.slip_days || '—') },
              { header: 'Revisions', num: true, cell: p => p.revision_count || '—' },
              { header: 'Days over', num: true, tone: p => p.is_overdue ? 'neg' : null,
                cell: p => p.is_overdue ? <b>{p.days_over}</b> : '—' },
              { header: 'Status', cell: p => p.is_overdue
                  ? <Tag tone="red">{t('Overdue')}</Tag> : <Tag tone="green">{t('On schedule')}</Tag> }
            ]} rows={d} />
          )}
        </Sheet>
      )}</Async>
    )}</Async>
  </>;
}

function Sheet({ company, title, period, children }) {
  return (
    <div className="bg-white border border-rule rounded shadow-sm max-w-5xl p-6 sm:p-8 print:border-0 print:shadow-none">
      <div className="text-center border-b-2 border-ink pb-3 mb-4">
        <h2 className={cx('text-[19px]', isAR() ? 'font-arDisplay' : 'font-display')}>
          {isAR() && company.name_ar ? company.name_ar : company.name}</h2>
        <p className="font-data text-[11px] text-ink-soft mt-0.5">
          {[company.cr_no, company.address].filter(Boolean).join(' · ')}</p>
      </div>
      <div className="text-center mb-4">
        <b className={cx('text-base', isAR() ? 'font-arDisplay' : 'font-display')}>{t(title)}</b>
        <div className="font-data text-[11px] text-ink-soft">{period} · {isAR()
          ? 'جميع المبالغ بالريال القطري' : 'all amounts in Qatari Riyals'}</div>
      </div>
      {children}
    </div>
  );
}

function StatementRows({ groups, name }) {
  return (
    <table className="w-full text-sm">
      <tbody>
        {groups.map(([label, rows, subtotal, totalLabel, totalValue], gi) => (
          <React.Fragment key={gi}>
            {label && (
              <tr><td colSpan={2} className={cx('pt-4 pb-1 text-ink-soft',
                isAR() ? 'font-ar text-[11px]' : 'font-data text-[10px] uppercase tracking-[0.13em]')}>
                {t(label)}</td></tr>
            )}
            {rows?.map(r => (
              <tr key={r.code} className="border-b border-rule/50">
                <td className="py-1.5 ps-6"><Code>{r.code}</Code> {name(r)}</td>
                <td className="py-1.5 text-end font-data tabular-nums">{money(r.amount)}</td>
              </tr>
            ))}
            {subtotal != null && (
              <tr className="font-semibold border-t border-rule-strong">
                <td className="py-1.5">{t('Total')} {t(label).toLowerCase()}</td>
                <td className="py-1.5 text-end font-data tabular-nums">{money(subtotal)}</td>
              </tr>
            )}
            {totalLabel && (
              <tr className="font-bold border-t-2 border-ink border-b-4 border-double">
                <td className="py-2">{t(totalLabel)}</td>
                <td className="py-2 text-end font-data tabular-nums">{money(totalValue)}</td>
              </tr>
            )}
          </React.Fragment>
        ))}
      </tbody>
    </table>
  );
}

/* ==================== SIMPLE REGISTERS ==================== */
export function Parties() {
  const [kind, setKind] = useState('CUSTOMER');
  const s = useAsync(() => api.get('/parties'));
  const [editing, setEditing] = useState(null);
  return <>
    <PageHead title="Customers & Suppliers"
      actions={<Btn variant="primary" onClick={() => setEditing({ kind })}>{t('New')}</Btn>} />
    <Tabs value={kind} onChange={setKind} items={[['CUSTOMER', 'Customer'], ['SUPPLIER', 'Supplier']]} />
    <Card title="Customers & Suppliers">
      <Async state={s}>{rows => (
        <Table onRow={setEditing} rows={rows.filter(p => p.kind === kind || p.kind === 'BOTH')} columns={[
          { header: 'Code', cell: p => <Code>{p.code}</Code> },
          { header: 'Name', cell: p => <b>{isAR() ? (p.name_ar || p.name) : p.name}</b> },
          { header: 'Reference', cell: p => p.cr_no || '—' },
          { header: 'Contact', cell: p => p.contact_person || '—' },
          { header: 'Due', cell: p => `${p.terms_days} ${isAR() ? 'يوم' : 'days'}` },
          { header: 'Status', cell: p => p.is_active
              ? <Tag tone="green">{isAR() ? 'نشط' : 'Active'}</Tag> : <Tag tone="red">—</Tag> }
        ]} empty={{ title: 'Nothing here yet' }} />
      )}</Async>
    </Card>
    {editing && <PartyForm party={editing} onClose={() => setEditing(null)}
      onDone={() => { setEditing(null); s.reload(); }} />}
  </>;
}

function PartyForm({ party, onClose, onDone }) {
  const [v, setV] = useState({ kind: 'CUSTOMER', terms_days: 30, ...party });
  const set = (k, val) => setV(s => ({ ...s, [k]: val }));
  const save = async () => {
    try {
      const body = { code: v.code, kind: v.kind, name: v.name, name_ar: v.name_ar, cr_no: v.cr_no,
        contact_person: v.contact_person, phone: v.phone, email: v.email, address: v.address,
        terms_days: Number(v.terms_days) };
      if (v.id) await api.patch(`/parties/${v.id}`, body); else await api.post('/parties', body);
      toast(t('Save')); onDone();
    } catch (e) { toast(e.message); }
  };
  return (
    <Modal title={v.id ? 'Edit' : 'New'} onClose={onClose} footer={<>
      <span className="flex-1" /><Btn onClick={onClose}>{t('Cancel')}</Btn>
      <Btn variant="primary" onClick={save}>{t('Save')}</Btn></>}>
      <div className={grid}>
        <Field label="Code"><Input value={v.code || ''} onChange={e => set('code', e.target.value)} /></Field>
        <Field label="Type"><Select value={v.kind} onChange={e => set('kind', e.target.value)}
          options={[{ value: 'CUSTOMER', label: t('Customer') }, { value: 'SUPPLIER', label: t('Supplier') },
            { value: 'BOTH', label: t('All') }]} /></Field>
        <Field label="Name" wide><Input value={v.name || ''} onChange={e => set('name', e.target.value)} /></Field>
        <Field label="Name (Arabic)" wide><Input dir="rtl" value={v.name_ar || ''}
          onChange={e => set('name_ar', e.target.value)} /></Field>
        <Field label="Reference"><Input value={v.cr_no || ''} onChange={e => set('cr_no', e.target.value)} /></Field>
        <Field label="Contact"><Input value={v.contact_person || ''}
          onChange={e => set('contact_person', e.target.value)} /></Field>
        <Field label="Phone"><Input value={v.phone || ''} onChange={e => set('phone', e.target.value)} /></Field>
        <Field label="Email"><Input value={v.email || ''} onChange={e => set('email', e.target.value)} /></Field>
        <Field label="Due"><Input numeric type="number" value={v.terms_days}
          onChange={e => set('terms_days', e.target.value)} /></Field>
      </div>
    </Modal>
  );
}

export function Inventory() {
  const s = useAsync(() => api.get('/stock'));
  return <>
    <PageHead title="Inventory & Stock"
      sub={isAR() ? 'التقييم بمتوسط التكلفة المرجح، مطابَقاً مع حسابات المخزون'
        : 'Valued at weighted-average cost, reconciled to the inventory control accounts.'} />
    <Card title="Inventory & Stock">
      <Async state={s}>{rows => (
        <Table rows={rows} columns={[
          { header: 'Code', cell: i => <Code>{i.code}</Code> },
          { header: 'Description', cell: i => isAR() ? (i.name_ar || i.name) : i.name },
          { header: 'On hand', num: true, tone: i => Number(i.on_hand) < 0 ? 'neg' : null,
            cell: i => `${money(i.on_hand)} ${i.uom}` },
          { header: 'Avg cost', num: true, cell: i => i.avg_cost },
          { header: 'Stock value', num: true, cell: i => <b>{money(i.stock_value)}</b> },
          { header: 'Status', cell: i => Number(i.on_hand) <= Number(i.reorder_level)
              ? <Tag tone="amber">{isAR() ? 'حد الطلب' : 'Reorder'}</Tag>
              : <Tag tone="green">{isAR() ? 'متوفر' : 'In stock'}</Tag> }
        ]} empty={{ title: 'Nothing here yet' }} />
      )}</Async>
    </Card>
  </>;
}

export function Payroll() {
  const [form, setForm] = useState(null);
  const s = useAsync(() => api.get('/employees'));
  return <>
    <PageHead title="Staff & Liabilities"
      actions={<>
        <Btn onClick={() => setForm('gratuity')}>{t('Accrue gratuity')}</Btn>
        <Btn variant="primary" onClick={() => setForm('payroll')}>{t('Run payroll')}</Btn>
      </>} />
    <Card title="Staff & Liabilities">
      <Async state={s}>{rows => (
        <Table rows={rows} columns={[
          { header: 'Code', cell: e => <Code>{e.code}</Code> },
          { header: 'Name', cell: e => <b>{isAR() ? (e.name_ar || e.name) : e.name}</b> },
          { header: 'Description', cell: e => e.position || '—' },
          { header: 'Start', cell: e => fmtDate(e.joined_on) },
          { header: 'Basic', num: true, cell: e => money(e.basic_salary) },
          { header: 'Allowances', num: true, cell: e => money(e.allowances) },
          { header: 'Total', num: true, cell: e =>
              <b>{money((Number(e.basic_salary) + Number(e.allowances)).toFixed(2))}</b> }
        ]} empty={{ title: 'Nothing here yet' }} />
      )}</Async>
    </Card>
    {form && <RunForm kind={form} onClose={() => setForm(null)} onDone={() => { setForm(null); s.reload(); }} />}
  </>;
}

function RunForm({ kind, onClose, onDone }) {
  const endpoint = kind === 'payroll' ? '/payroll/run' : '/payroll/gratuity';
  const [v, setV] = useState({ periodEnd: today() });
  const [valid, setValid] = useState(false);
  return (
    <Modal title={kind === 'payroll' ? 'Run payroll' : 'Accrue gratuity'} wide onClose={onClose} footer={<>
      <span className="flex-1" /><Btn onClick={onClose}>{t('Cancel')}</Btn>
      <Btn variant="primary" disabled={!valid} onClick={async () => {
        try { await api.post(endpoint, v); toast(t('Save')); onDone(); } catch (e) { toast(e.message); }
      }}>{t('Post entry')}</Btn></>}>
      <div className={grid}>
        <Field label="Date"><Input type="date" value={v.periodEnd}
          onChange={e => setV({ periodEnd: e.target.value })} /></Field>
        <PostingSlip endpoint={endpoint} body={v} onValidity={setValid} />
      </div>
    </Modal>
  );
}

export function Assets() {
  const [form, setForm] = useState(false);
  const s = useAsync(() => api.get('/assets'));
  return <>
    <PageHead title="Fixed Assets"
      actions={<Btn variant="primary" onClick={() => setForm(true)}>{t('Run depreciation')}</Btn>} />
    <Card title="Fixed Assets">
      <Async state={s}>{rows => (
        <Table rows={rows} columns={[
          { header: 'Code', cell: a => <Code>{a.tag}</Code> },
          { header: 'Description', cell: a => <b>{isAR() ? (a.name_ar || a.name) : a.name}</b> },
          { header: 'Type', cell: a => a.category },
          { header: 'Start', cell: a => fmtDate(a.in_service_on) },
          { header: 'Cost', num: true, cell: a => money(a.cost) },
          { header: 'Balance', num: true, cell: a => fmtDate(a.depreciated_to) },
          { header: 'Status', cell: a => <Tag tone={a.status === 'IN_USE' ? 'green' : 'red'}>{a.status}</Tag> }
        ]} empty={{ title: 'Nothing here yet' }} />
      )}</Async>
    </Card>
    {form && <DepForm onClose={() => setForm(false)} onDone={() => { setForm(false); s.reload(); }} />}
  </>;
}

function DepForm({ onClose, onDone }) {
  const [v, setV] = useState({ runTo: today() });
  const [valid, setValid] = useState(false);
  return (
    <Modal title="Run depreciation" wide onClose={onClose} footer={<>
      <span className="flex-1" /><Btn onClick={onClose}>{t('Cancel')}</Btn>
      <Btn variant="primary" disabled={!valid} onClick={async () => {
        try { await api.post('/depreciation/run', v); toast(t('Save')); onDone(); } catch (e) { toast(e.message); }
      }}>{t('Post entry')}</Btn></>}>
      <div className={grid}>
        <Field label="Date"><Input type="date" value={v.runTo} onChange={e => setV({ runTo: e.target.value })} /></Field>
        <PostingSlip endpoint="/depreciation/run" body={v} onValidity={setValid} />
      </div>
    </Modal>
  );
}

export function Accounts() {
  const s = useAsync(() => api.get('/accounts'));
  return <>
    <PageHead title="Chart of Accounts" />
    <Card title="Chart of Accounts">
      <Async state={s}>{rows => (
        <Table rows={rows} columns={[
          { header: 'Code', cell: a => <Code>{a.code}</Code> },
          { header: 'Name', cell: a => a.is_group
              ? <b>{isAR() ? (a.name_ar || a.name) : a.name}</b>
              : <span className="ps-5 inline-block">{isAR() ? (a.name_ar || a.name) : a.name}</span> },
          { header: 'Type', cell: a => <Tag>{a.type}</Tag> },
          { header: 'Status', cell: a => a.is_group ? <Tag>{isAR() ? 'عنوان' : 'Heading'}</Tag>
              : a.class_tag ? <Tag tone="green">{a.class_tag}</Tag> : null }
        ]} />
      )}</Async>
    </Card>
  </>;
}

export function Settings({ user }) {
  const s = useAsync(async () => ({
    company: await api.get('/company'),
    periods: await api.get('/periods'),
    users: user.can_admin ? await api.get('/users') : []
  }));
  return (
    <Async state={s}>{d => <>
      <PageHead title="Company Setup" />
      <div className="grid gap-3.5 lg:grid-cols-2">
        <Card title="Company Setup">
          <div className="p-3.5">
            <table className="w-full text-sm">
              <tbody>
                {[['Name', d.company.name],
                  ['Name (Arabic)', d.company.name_ar || (isAR() ? '— غير مُدخل —' : '— not set —')],
                  ['Reference', d.company.cr_no || '—'],
                  ['Retention', `${d.company.retention_pct}%`],
                  ['Gratuity', `${d.company.gratuity_days_year} ${isAR() ? 'يوم/سنة' : 'days per year'}`],
                  ['Approval', money(d.company.payment_approval_limit)]].map(([k, v], i) => (
                  <tr key={i} className="border-b border-rule/60">
                    <td className="py-1.5 text-ink-soft">{t(k)}</td>
                    <td className="py-1.5 text-end">{v}</td>
                  </tr>))}
              </tbody>
            </table>
          </div>
        </Card>
        <Card title="Periods">
          <Table rows={d.periods} columns={[
            { header: 'Date', cell: p => `${fmtDate(p.starts_on)} — ${fmtDate(p.ends_on)}` },
            { header: 'Status', cell: p => <Tag tone={p.status === 'OPEN' ? 'green' : 'red'}>{p.status}</Tag> },
            { header: '', cell: p => user.can_close_period && (
              <Btn size="sm" onClick={async () => {
                try { await api.post(`/periods/${p.id}/status`,
                  { status: p.status === 'OPEN' ? 'LOCKED' : 'OPEN' }); toast(t('Save')); s.reload(); }
                catch (e) { toast(e.message); }
              }}>{p.status === 'OPEN' ? (isAR() ? 'قفل' : 'Lock') : (isAR() ? 'فتح' : 'Open')}</Btn>) }
          ]} />
        </Card>
        {user.can_admin && (
          <Card title="Users & Access" className="lg:col-span-2">
            <Table rows={d.users} columns={[
              { header: 'Name', cell: u => <b>{u.name}</b> },
              { header: 'Email', cell: u => <Code>{u.email}</Code> },
              { header: 'Type', cell: u => <Tag>{isAR() ? (u.role_name_ar || u.role_name) : u.role_name}</Tag> },
              { header: 'Status', cell: u => u.can_post
                  ? <Tag tone="green">{isAR() ? 'يُرحّل' : 'Can post'}</Tag>
                  : <Tag>{isAR() ? 'اطلاع فقط' : 'Read only'}</Tag> }
            ]} />
          </Card>
        )}
      </div>
    </>}</Async>
  );
}
