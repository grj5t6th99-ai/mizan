# MIZAN ERP — production build

Trading and contracting ERP for a single Qatari company. Real books, real go-live date.

## Stack

| Layer | Choice | Why |
|---|---|---|
| Database | **PostgreSQL 16+** | `NUMERIC` for money, deferrable constraint triggers, point-in-time restore |
| Server | Node 22 + Express, `pg` driver, raw SQL | No ORM — an ORM abstracts away exactly the transaction control the ledger needs |
| Frontend | React + Vite + Tailwind | Same as SIB CRM; the prototype's UI language ports over |
| Hosting | Railway (app + managed Postgres) | Already your deploy path |
| Migrations | Numbered `.sql` files, applied in order, never edited after release | Inspectable by an auditor |

**Not SQLite.** It has no decimal type — money in floats is the classic accounting bug — and no deferrable constraint triggers, which is how "debits must equal credits" becomes a database guarantee instead of a hope.

## The central decision

**No balance is ever stored.** Not on an account, not on a customer, not on an item. Every figure in every report is computed from `journal_line`. A report therefore *cannot* disagree with the ledger, because there is nothing for it to disagree with. This was proven over eight months of transactions in the prototype and carries over unchanged.

The corollary: posting must be transactional and irreversible, and the journal must be the only writer of truth.

## Invariants enforced by the database

Not by application code, so that no bug, no migration script and no `psql` session can break the books. Each is tested in `test/schema.test.js`, which tries to violate it and asserts the specific error:

| # | Rule | Mechanism |
|---|---|---|
| 1 | Every entry balances | Deferred constraint trigger, checked at COMMIT |
| 2 | Every entry has ≥ 2 lines | Same trigger |
| 3 | A line has a debit **or** a credit, never both, never negative | CHECK constraints |
| 4 | Nothing posts into a locked period or closed year | BEFORE INSERT trigger, which also stamps `period_id` |
| 5 | Posted entries and lines can never be updated or deleted | BEFORE UPDATE/DELETE trigger |
| 6 | Lines may only hit active, non-heading accounts | BEFORE INSERT trigger |
| 7 | Control-account lines must name a party | Same trigger, driven by `account.requires_party` |
| 8 | An entry can be reversed only once | Partial unique index |
| 9 | The audit log is append-only | Same immutability trigger |
| 10 | A project's baseline end date can never change | BEFORE UPDATE trigger |
| 11 | Moving a project end date requires a logged revision | Same trigger |
| 12 | The revision log is append-only | Immutability trigger |
| 13 | Nobody approves their own payment | BEFORE INSERT/UPDATE trigger |
| 14 | Document numbers are gapless | Locked-row allocator, not a sequence |

Run them: `node test/schema.test.js` — 41 assertions, no external database needed (PGlite).

## Design notes worth knowing

**Correction is by reversal.** A posted document is never edited. Voiding posts a mirror-image entry and links it via `reversal_of_id`. `v_journal.is_reversed` is derived, not stored.

**Documents are mutable while `DRAFT`; posting freezes them.** This is what makes maker/checker possible: a payment can sit in `PENDING_APPROVAL` with no ledger impact until a second person approves it, at which point the journal entry is created.

**Gapless numbering.** Postgres sequences skip numbers on rollback, and auditors ask about gaps. `next_doc_no()` takes a row lock instead, so a rolled-back transaction releases the number rather than burning it.

**No hardcoded account codes.** Modules ask `control('ar')`, not `'1130'`. The accountant can rebind a control account without a code change.

**One party table, not two.** In trading the same company is very often both customer and supplier; two tables means two balances for one relationship.

**Stock moves carry their own running balance and weighted-average cost.** Stock can be valued at any past date, and the item master can be rebuilt from the moves alone. Value moved is rounded exactly as the journal rounds it, so the stock ledger and accounts 1140/1141 cannot drift — the bug that bit us in the prototype.

**`posted_by_name` is denormalised** onto every entry, and `user_name` onto every audit row. An audit trail that breaks when a user is deleted is not an audit trail.

## Money

Amounts are BigInt minor units parsed from decimal strings, never JavaScript numbers.
`Math.round(2.675 * 100)` is 267, not 268 — in an accounting system that is not a
rounding quirk, it is a wrong invoice. The `pg` driver is configured to return NUMERIC
**and DATE** as strings, so the driver can never turn money into a float or shift a
date by a timezone.

Rounding happens per line and per person, not on totals: gratuity for two employees is
280.00 + 554.17 = 834.17, not 834.16 from the combined basic. The provision has to be
settleable per employee, so it must be the sum of its parts.

## What is built

```
src/money.js                    exact decimal arithmetic (BigInt minor units)
src/db.js                       pool, transactions, human-readable error mapping
src/ledger.js                   the ONLY writer of journal entries
src/auth.js                     scrypt hashing, server-side sessions, RBAC
src/services/documents.js       sales, purchases, cash, advances, weighted-average stock
src/services/operations.js      payroll, gratuity, depreciation, schedule, period close
src/services/reports.js         trial balance, P&L, balance sheet, ageing, health
src/app.js  src/server.js       REST API and process lifecycle

migrations/001_foundation.sql   roles, users, audit log, fiscal calendar,
                                chart of accounts, control-account binding,
                                asset categories, gapless numbering, company
migrations/002_ledger.sql       journal entry + lines, all five ledger
                                invariants, derived reporting views
migrations/003_masters.sql      parties, employees, projects + revision log,
                                items + stock moves, fixed assets
migrations/004_documents.sql    sales/purchase invoices, cash documents with
                                maker-checker, allocations, advances view,
                                payroll runs, depreciation runs
seeds/010_chart_of_accounts.sql 81 accounts, English + Arabic, 20 control
                                bindings, 5 asset categories
migrations/005_sessions_tax.sql sessions, login throttling, tax placeholders
migrations/006_contracting.sql  estimates, cost codes, variations, subcontract
                                packages, cost-value reconciliation views
src/services/contracting.js     estimating, award, variations, packages

test/money.test.js              19 assertions on decimal arithmetic
test/schema.test.js             41 assertions on the database invariants
test/api.test.js                51 assertions: a full month through the HTTP API
test/contracting.test.js        41 assertions: price a job, win it, watch it overrun
```

Run everything: `npm test`, then `DATABASE_URL=... npm run test:api`, then
`cd web && npm test`. 182 assertions in total.

## Getting it running

**RUNBOOK.md** is the step-by-step guide: private repo, try it online in a
throwaway Codespace, provision the server, DNS, deploy, prove the backups restore.

`.devcontainer/` makes the repository open directly in GitHub Codespaces with
Node and Postgres already wired together. `npm run try` migrates, creates the
company and the first user, and starts the server on port 3000. Nothing is
installed locally.

## First run

```bash
npm run migrate
DATABASE_URL=... npm run bootstrap --  --year 2026 --email you@alrwfaa.qa
```

That creates the company, the roles, the fiscal year with twelve open periods, and one
administrator whose password is printed once. The company's Arabic name is deliberately
left empty: it prints on statements that go to the auditor, so it should be typed by
someone who knows the registered Arabic name rather than transliterated by software.

## The contracting flow

The module that separates a contracting ERP from bookkeeping software.

```
Enquiry -> Estimate (BOQ priced by resource build-up) -> Quotation
        -> Won -> Project, and EVERY estimate line becomes a cost code
                  carrying its budget
        -> Purchases, subcontract certificates and payroll are tagged
           to a cost code
        -> Budget vs committed vs actual vs forecast, per cost head
```

**The estimate becomes the budget.** Most systems price a job in one place and
account for it in another, so nobody ever compares the two. Awarding an estimate
here writes a `cost_code` row per BOQ line, carrying the material / labour / plant
/ subcontract split. From that moment every riyal spent can be set against the
riyal that was priced, at the level of the individual work item rather than the
whole job.

**Cost codes, not just accounts.** "Direct Materials — Projects" cannot tell you
that ductwork is 24,000 over while cabling is under. `journal_line.cost_code_id`
can, and a trigger refuses a cost code belonging to a different project.

**Committed cost, not just actual.** Award a 402,000 subcontract package against a
378,000 budget line and the overrun exists that day, months before an invoice
arrives. `v_cost_code_position` reports budget / actual / committed / forecast, so
the forecast moves when the order is placed, not when the bill lands.

**Awarded estimates freeze.** A budget you can still edit is not a budget.
Re-pricing a submitted estimate is refused; you create a revision, and the original
stays on record with its outcome.

**Variations move price, budget and time together.** Approving one adds to the
contract value, adds a cost code with its budget, and — where an extension of time
was claimed — writes a project revision naming the variation as the reason. A
variation that raised the price without raising the budget would flatter the
forecast, which is the opposite of the point.

Subcontract certificates cannot exceed the package they are drawn against, tender
win rate falls out of the estimate pipeline, and `v_project_cvr` gives the
one-page cost-value reconciliation.

## The frontend

React + Vite + Tailwind, in `web/`. The design tokens, the navigation shape and the
posting slip carry over from the prototype, which is why there was no visual design
work to redo.

**The posting slip is fed by the server.** It does not compute anything. On every
change the form asks `POST /api/<document>/preview`, which runs the real posting
service inside a transaction that is then rolled back. What the user sees is exactly
what will hit the ledger, or exactly the error that will stop it. There is no second
implementation of the accounting rules in the browser to fall out of step with the
first — the classic way an ERP starts lying to its users.

The save button is enabled only when that preview succeeds, so the button and the slip
agree by construction rather than by discipline.

Bilingual EN/AR with full RTL. Amounts, account codes and dates stay left-to-right
inside an RTL page, which is how Qatari finance departments read them.

```
web/src/api.js         fetch client, money/date formatting, translations, RTL
web/src/ui.jsx         design system, table, modal, PostingSlip, data loading
web/src/pages.jsx      dashboard, sales, purchases, cash, projects
web/src/registers.jsx  journal, reports, parties, inventory, payroll, assets, setup
web/src/App.jsx        shell, navigation, sign-in
web/test/smoke.test.jsx  27 assertions: sign-in, RTL, overdue flag, posting slip
```

Run them: `cd web && npm test`.

## What is not built yet

Phase 3 — frontend screens for estimating and the CVR (the services and API are
done and tested; there is no UI for them yet), progress measurement so certificates
are built from measured cost codes rather than typed, purchase orders, PDF output,
WPS SIF export, bank reconciliation.
Phase 4 — opening-balance migration and go-live.

Qatar tax is deliberately deferred. `tax_code`, `tax_amount` and the rate table exist
with everything at zero, so introducing VAT later is a rate change and a migration
rather than a reshaping of documents that already carry postings.

## Before real books go in

- [ ] Auditor signs off on the chart of accounts and the close process
- [ ] Confirm the current Qatar tax and e-invoicing position before the schema is frozen — retrofitting a tax line into a posted ledger is painful
- [ ] Fiscal year and periods created for the go-live year
- [ ] Opening balances posted as a single dated journal and agreed to the prior year's audited accounts
- [ ] Backups **restored into a scratch database and checked** — an untested backup is not a backup
- [ ] Payment approval limit set in `company.payment_approval_limit`
- [ ] At least two users with different roles, so maker/checker is real
- [ ] A dry-run month posted in parallel with the existing books and reconciled
