-- ============================================================
-- MIZAN ERP · 006 · the contracting flow
--
--   Enquiry -> Estimate (BOQ with a cost build-up) -> Quotation
--           -> Won -> Project, and every estimate line becomes a
--              COST CODE carrying its budget
--           -> Purchases, subcontract certificates and payroll are
--              tagged to a cost code
--           -> Budget vs committed vs actual, per cost head, live
--
-- The point of all this is one number a contractor cannot otherwise
-- get: what this job will finally cost, known before it is too late
-- to do anything about it.
-- ============================================================

CREATE TYPE estimate_status AS ENUM
  ('DRAFT','SUBMITTED','WON','LOST','WITHDRAWN','SUPERSEDED');
CREATE TYPE variation_status AS ENUM
  ('DRAFT','SUBMITTED','APPROVED','REJECTED');
CREATE TYPE package_status AS ENUM
  ('DRAFT','AWARDED','CLOSED','CANCELLED');
CREATE TYPE cost_category AS ENUM
  ('MATERIAL','LABOUR','PLANT','SUBCONTRACT','OTHER');

-- ---------- teach the chart of accounts about cost heads ----------
-- An account already says WHAT was spent. This says which column of
-- the estimate build-up it belongs in, so actuals line up with the
-- way the job was priced.
ALTER TABLE account ADD COLUMN cost_category cost_category;

-- These match nothing on a brand-new database, because seeds run after
-- migrations and the accounts do not exist yet; seeds/020 repeats them.
-- They are kept here so an existing database is migrated correctly.
UPDATE account SET cost_category = 'SUBCONTRACT' WHERE code = '5200';
UPDATE account SET cost_category = 'MATERIAL'    WHERE code IN ('5210','5100','5250');
UPDATE account SET cost_category = 'LABOUR'      WHERE code = '5220';
UPDATE account SET cost_category = 'PLANT'       WHERE code = '5230';
UPDATE account SET cost_category = 'OTHER'       WHERE code = '5240';

-- ============================================================
-- ESTIMATING
-- ============================================================
CREATE TABLE estimate (
  id                BIGSERIAL PRIMARY KEY,
  ref               TEXT NOT NULL UNIQUE,
  title             TEXT NOT NULL,
  title_ar          TEXT,
  client_id         BIGINT REFERENCES party(id),
  status            estimate_status NOT NULL DEFAULT 'DRAFT',
  estimate_date     DATE NOT NULL DEFAULT CURRENT_DATE,
  valid_until       DATE,
  -- Both are markups ON COST, applied in order. Naming them
  -- explicitly because "margin" is read two different ways and the
  -- difference is worth real money on a large tender.
  overhead_pct      NUMERIC(6,3) NOT NULL DEFAULT 8,
  profit_pct        NUMERIC(6,3) NOT NULL DEFAULT 12,
  contingency_pct   NUMERIC(6,3) NOT NULL DEFAULT 0,
  -- proposed contract terms, carried onto the project when won
  duration_days     INT,
  retention_pct     NUMERIC(5,2) NOT NULL DEFAULT 10,
  advance_pct       NUMERIC(5,2) NOT NULL DEFAULT 0,
  scope             TEXT,
  notes             TEXT,
  supersedes_id     BIGINT REFERENCES estimate(id),
  submitted_on      DATE,
  decided_on        DATE,
  outcome_note      TEXT,             -- why it was lost; the most useful field here
  project_id        BIGINT REFERENCES project(id),
  created_by        BIGINT REFERENCES app_user(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (overhead_pct >= 0 AND profit_pct >= 0 AND contingency_pct >= 0),
  CHECK (valid_until IS NULL OR valid_until >= estimate_date),
  -- a won estimate must point at the project it became
  CHECK (status <> 'WON' OR project_id IS NOT NULL)
);
CREATE INDEX estimate_status_idx ON estimate (status, estimate_date);
CREATE INDEX estimate_client_idx ON estimate (client_id);

-- A bill of quantities line, priced by its resource build-up rather
-- than a single guessed rate. This is what makes the estimate useful
-- later: when blockwork overruns you can see whether it was the
-- material, the labour or the subcontractor.
CREATE TABLE estimate_line (
  id                BIGSERIAL PRIMARY KEY,
  estimate_id       BIGINT NOT NULL REFERENCES estimate(id) ON DELETE CASCADE,
  line_no           INT NOT NULL,
  section           TEXT,                       -- 'Civil', 'MEP', 'Finishes'
  code              TEXT,                       -- becomes the cost code
  description       TEXT NOT NULL,
  description_ar    TEXT,
  unit              TEXT NOT NULL DEFAULT 'NOS',
  quantity          qty NOT NULL DEFAULT 1,
  material_rate     unit_cost NOT NULL DEFAULT 0,
  labour_rate       unit_cost NOT NULL DEFAULT 0,
  plant_rate        unit_cost NOT NULL DEFAULT 0,
  subcontract_rate  unit_cost NOT NULL DEFAULT 0,
  other_rate        unit_cost NOT NULL DEFAULT 0,
  note              TEXT,
  UNIQUE (estimate_id, line_no),
  CHECK (quantity >= 0),
  CHECK (material_rate >= 0 AND labour_rate >= 0 AND plant_rate >= 0
         AND subcontract_rate >= 0 AND other_rate >= 0)
);
CREATE INDEX estimate_line_estimate_idx ON estimate_line (estimate_id, line_no);

-- Rates and totals derived, never stored: a stored total is a total
-- that can disagree with its parts.
CREATE VIEW v_estimate_line AS
SELECT l.*,
       (l.material_rate + l.labour_rate + l.plant_rate + l.subcontract_rate + l.other_rate) AS cost_rate,
       ROUND(l.quantity * l.material_rate, 2)    AS material_amount,
       ROUND(l.quantity * l.labour_rate, 2)      AS labour_amount,
       ROUND(l.quantity * l.plant_rate, 2)       AS plant_amount,
       ROUND(l.quantity * l.subcontract_rate, 2) AS subcontract_amount,
       ROUND(l.quantity * l.other_rate, 2)       AS other_amount,
       ROUND(l.quantity * (l.material_rate + l.labour_rate + l.plant_rate
                           + l.subcontract_rate + l.other_rate), 2) AS cost_amount,
       ROUND(l.quantity * (l.material_rate + l.labour_rate + l.plant_rate
                           + l.subcontract_rate + l.other_rate)
             * (1 + e.contingency_pct/100)
             * (1 + e.overhead_pct/100)
             * (1 + e.profit_pct/100), 2) AS sell_amount
  FROM estimate_line l JOIN estimate e ON e.id = l.estimate_id;

CREATE VIEW v_estimate AS
SELECT e.*, p.name AS client_name, p.name_ar AS client_name_ar,
       COALESCE(t.cost_total, 0)  AS cost_total,
       COALESCE(t.sell_total, 0)  AS sell_total,
       COALESCE(t.sell_total, 0) - COALESCE(t.cost_total, 0) AS margin_value,
       CASE WHEN COALESCE(t.sell_total,0) = 0 THEN NULL
            ELSE ROUND((t.sell_total - t.cost_total) / t.sell_total * 100, 2)
       END AS gross_margin_pct,      -- margin as a share of the PRICE
       COALESCE(t.material_total,0)    AS material_total,
       COALESCE(t.labour_total,0)      AS labour_total,
       COALESCE(t.plant_total,0)       AS plant_total,
       COALESCE(t.subcontract_total,0) AS subcontract_total,
       COALESCE(t.other_total,0)       AS other_total,
       COALESCE(t.line_count, 0)       AS line_count
  FROM estimate e
  LEFT JOIN party p ON p.id = e.client_id
  LEFT JOIN LATERAL (
    SELECT SUM(cost_amount) cost_total, SUM(sell_amount) sell_total,
           SUM(material_amount) material_total, SUM(labour_amount) labour_total,
           SUM(plant_amount) plant_total, SUM(subcontract_amount) subcontract_total,
           SUM(other_amount) other_total, COUNT(*) line_count
      FROM v_estimate_line WHERE estimate_id = e.id) t ON TRUE;

-- ============================================================
-- COST CODES — the estimate, carried into the job as its budget
-- ============================================================
CREATE TABLE cost_code (
  id                   BIGSERIAL PRIMARY KEY,
  project_id           BIGINT NOT NULL REFERENCES project(id),
  code                 TEXT NOT NULL,
  section              TEXT,
  description          TEXT NOT NULL,
  description_ar       TEXT,
  unit                 TEXT NOT NULL DEFAULT 'NOS',
  budget_quantity      qty NOT NULL DEFAULT 0,
  budget_material      money_qar NOT NULL DEFAULT 0,
  budget_labour        money_qar NOT NULL DEFAULT 0,
  budget_plant         money_qar NOT NULL DEFAULT 0,
  budget_subcontract   money_qar NOT NULL DEFAULT 0,
  budget_other         money_qar NOT NULL DEFAULT 0,
  sell_amount          money_qar NOT NULL DEFAULT 0,   -- the revenue this line carries
  source_line_id       BIGINT REFERENCES estimate_line(id),
  variation_id         BIGINT,                          -- set when added by a variation
  is_active            BOOLEAN NOT NULL DEFAULT TRUE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (project_id, code)
);
CREATE INDEX cost_code_project_idx ON cost_code (project_id) WHERE is_active;

-- Actual costs are tagged to a cost code. Without this the estimate
-- and the ledger stay in separate worlds, which is the normal state
-- of affairs and the reason contractors find out late.
ALTER TABLE journal_line ADD COLUMN cost_code_id BIGINT REFERENCES cost_code(id);
CREATE INDEX journal_line_cost_code_idx ON journal_line (cost_code_id)
  WHERE cost_code_id IS NOT NULL;

-- A cost code belongs to exactly one project; a line may not borrow
-- another job's budget.
CREATE OR REPLACE FUNCTION assert_cost_code_matches_project() RETURNS TRIGGER AS $$
DECLARE v_project BIGINT;
BEGIN
  IF NEW.cost_code_id IS NULL THEN RETURN NEW; END IF;
  SELECT project_id INTO v_project FROM cost_code WHERE id = NEW.cost_code_id;
  IF NEW.project_id IS NULL THEN
    NEW.project_id := v_project;                 -- infer it rather than nag
  ELSIF NEW.project_id <> v_project THEN
    RAISE EXCEPTION 'That cost code belongs to a different project'
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER journal_line_cost_code_project BEFORE INSERT ON journal_line
  FOR EACH ROW EXECUTE FUNCTION assert_cost_code_matches_project();

-- Staff who work to a particular cost head can be charged there by
-- default, so payroll lands in the budget without anyone re-keying it.
ALTER TABLE employee ADD COLUMN cost_code_id BIGINT REFERENCES cost_code(id);

-- ============================================================
-- VARIATION ORDERS
-- ============================================================
CREATE TABLE variation_order (
  id             BIGSERIAL PRIMARY KEY,
  project_id     BIGINT NOT NULL REFERENCES project(id),
  ref            TEXT NOT NULL UNIQUE,
  title          TEXT NOT NULL,
  description    TEXT,
  status         variation_status NOT NULL DEFAULT 'DRAFT',
  submitted_on   DATE,
  decided_on     DATE,
  sell_value     money_qar NOT NULL DEFAULT 0,   -- added to the contract
  cost_value     money_qar NOT NULL DEFAULT 0,   -- added to the budget
  days_claimed   INT NOT NULL DEFAULT 0,         -- extension of time sought
  outcome_note   TEXT,
  created_by     BIGINT REFERENCES app_user(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (sell_value >= 0 AND cost_value >= 0)
);
CREATE INDEX variation_project_idx ON variation_order (project_id, status);
ALTER TABLE cost_code ADD CONSTRAINT cost_code_variation_fk
  FOREIGN KEY (variation_id) REFERENCES variation_order(id);

-- ============================================================
-- SUBCONTRACT PACKAGES
-- What you have committed to pay, as distinct from what you have
-- been invoiced. A report showing only invoices says the job is
-- fine right up until it isn't.
-- ============================================================
CREATE TABLE subcontract_package (
  id             BIGSERIAL PRIMARY KEY,
  project_id     BIGINT NOT NULL REFERENCES project(id),
  party_id       BIGINT NOT NULL REFERENCES party(id),
  ref            TEXT NOT NULL UNIQUE,
  title          TEXT NOT NULL,
  scope          TEXT,
  status         package_status NOT NULL DEFAULT 'DRAFT',
  order_value    money_qar NOT NULL DEFAULT 0,
  retention_pct  NUMERIC(5,2) NOT NULL DEFAULT 10,
  advance_pct    NUMERIC(5,2) NOT NULL DEFAULT 0,
  starts_on      DATE,
  ends_on        DATE,
  awarded_on     DATE,
  cost_code_id   BIGINT REFERENCES cost_code(id),
  created_by     BIGINT REFERENCES app_user(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (order_value >= 0),
  CHECK (retention_pct BETWEEN 0 AND 100),
  CHECK (status <> 'AWARDED' OR awarded_on IS NOT NULL)
);
CREATE INDEX package_project_idx ON subcontract_package (project_id, status);

-- Certificates against a package, so certified-to-date can be
-- measured against what was ordered.
ALTER TABLE purchase_invoice ADD COLUMN subcontract_id BIGINT REFERENCES subcontract_package(id);
ALTER TABLE purchase_invoice ADD COLUMN cost_code_id  BIGINT REFERENCES cost_code(id);
ALTER TABLE purchase_invoice_line ADD COLUMN cost_code_id BIGINT REFERENCES cost_code(id);
ALTER TABLE sales_invoice_line ADD COLUMN cost_code_id BIGINT REFERENCES cost_code(id);

CREATE VIEW v_subcontract_package AS
SELECT s.*, p.name AS party_name, p.name_ar AS party_name_ar, pr.code AS project_code,
       COALESCE(c.certified, 0) AS certified_to_date,
       s.order_value - COALESCE(c.certified, 0) AS uncertified_commitment,
       CASE WHEN s.order_value = 0 THEN NULL
            ELSE ROUND(COALESCE(c.certified,0) / s.order_value * 100, 1) END AS certified_pct
  FROM subcontract_package s
  JOIN party p    ON p.id = s.party_id
  JOIN project pr ON pr.id = s.project_id
  LEFT JOIN LATERAL (
    SELECT SUM(gross_amount) AS certified FROM purchase_invoice
     WHERE subcontract_id = s.id AND status = 'POSTED') c ON TRUE;

-- ============================================================
-- COST VALUE RECONCILIATION
-- The report a contractor actually runs the business on.
-- ============================================================

-- Per cost code: what we priced, what we have committed, what we
-- have actually spent, and what we now think it will finish at.
CREATE VIEW v_cost_code_position AS
SELECT c.id, c.project_id, c.code, c.section, c.description, c.description_ar,
       c.unit, c.budget_quantity, c.sell_amount,
       (c.budget_material + c.budget_labour + c.budget_plant
        + c.budget_subcontract + c.budget_other) AS budget_cost,
       c.budget_material, c.budget_labour, c.budget_plant,
       c.budget_subcontract, c.budget_other,
       COALESCE(a.actual_cost, 0)   AS actual_cost,
       COALESCE(a.material, 0)      AS actual_material,
       COALESCE(a.labour, 0)        AS actual_labour,
       COALESCE(a.plant, 0)         AS actual_plant,
       COALESCE(a.subcontract, 0)   AS actual_subcontract,
       COALESCE(a.other, 0)         AS actual_other,
       COALESCE(k.committed, 0)     AS uncertified_commitment,
       -- forecast: what is spent, plus what is committed but not yet
       -- invoiced, plus whatever budget is left uncommitted
       GREATEST(
         COALESCE(a.actual_cost,0) + COALESCE(k.committed,0),
         (c.budget_material + c.budget_labour + c.budget_plant
          + c.budget_subcontract + c.budget_other)
       ) AS forecast_cost,
       (c.budget_material + c.budget_labour + c.budget_plant
        + c.budget_subcontract + c.budget_other) - COALESCE(a.actual_cost,0) AS budget_remaining
  FROM cost_code c
  LEFT JOIN LATERAL (
    SELECT SUM(l.debit - l.credit) AS actual_cost,
           SUM(CASE WHEN ac.cost_category='MATERIAL'    THEN l.debit - l.credit ELSE 0 END) material,
           SUM(CASE WHEN ac.cost_category='LABOUR'      THEN l.debit - l.credit ELSE 0 END) labour,
           SUM(CASE WHEN ac.cost_category='PLANT'       THEN l.debit - l.credit ELSE 0 END) plant,
           SUM(CASE WHEN ac.cost_category='SUBCONTRACT' THEN l.debit - l.credit ELSE 0 END) subcontract,
           SUM(CASE WHEN ac.cost_category='OTHER' OR ac.cost_category IS NULL
                    THEN l.debit - l.credit ELSE 0 END) other
      FROM journal_line l
      JOIN account ac ON ac.code = l.account_code AND ac.type IN ('COS','EXPENSE')
     WHERE l.cost_code_id = c.id) a ON TRUE
  LEFT JOIN LATERAL (
    SELECT SUM(order_value - COALESCE((
             SELECT SUM(gross_amount) FROM purchase_invoice
              WHERE subcontract_id = s.id AND status='POSTED'), 0)) AS committed
      FROM subcontract_package s
     WHERE s.cost_code_id = c.id AND s.status = 'AWARDED') k ON TRUE
 WHERE c.is_active;

-- Per project: the one-page picture.
CREATE VIEW v_project_cvr AS
SELECT p.id, p.code, p.name, p.name_ar, p.status, p.contract_value,
       cl.name AS client_name,
       COALESCE(v.approved_variations, 0) AS approved_variations,
       p.contract_value + COALESCE(v.approved_variations, 0) AS revised_contract_value,
       COALESCE(b.budget_cost, 0)     AS budget_cost,
       COALESCE(b.actual_cost, 0)     AS actual_cost,
       COALESCE(b.uncertified_commitment, 0) AS committed_cost,
       COALESCE(b.forecast_cost, 0)   AS forecast_cost,
       COALESCE(r.certified_revenue, 0) AS certified_revenue,
       -- margin as priced, versus margin as it is actually going
       p.contract_value + COALESCE(v.approved_variations,0) - COALESCE(b.budget_cost,0) AS margin_as_priced,
       p.contract_value + COALESCE(v.approved_variations,0) - COALESCE(b.forecast_cost,0) AS margin_forecast,
       COALESCE(b.forecast_cost,0) - COALESCE(b.budget_cost,0) AS forecast_overrun
  FROM project p
  LEFT JOIN party cl ON cl.id = p.client_id
  LEFT JOIN LATERAL (
    SELECT SUM(budget_cost) budget_cost, SUM(actual_cost) actual_cost,
           SUM(uncertified_commitment) uncertified_commitment, SUM(forecast_cost) forecast_cost
      FROM v_cost_code_position WHERE project_id = p.id) b ON TRUE
  LEFT JOIN LATERAL (
    SELECT SUM(sell_value) approved_variations FROM variation_order
     WHERE project_id = p.id AND status = 'APPROVED') v ON TRUE
  LEFT JOIN LATERAL (
    SELECT SUM(l.credit - l.debit) certified_revenue
      FROM journal_line l JOIN account a ON a.code = l.account_code AND a.type = 'REVENUE'
     WHERE l.project_id = p.id) r ON TRUE;

-- Tender pipeline and win rate.
CREATE VIEW v_estimate_pipeline AS
SELECT status,
       COUNT(*)               AS count,
       SUM(sell_total)        AS value,
       SUM(margin_value)      AS margin
  FROM v_estimate GROUP BY status;
