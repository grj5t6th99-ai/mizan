-- ============================================================
-- MIZAN ERP · 002 · the general ledger
--
-- Five invariants are enforced HERE, not in application code, so
-- that no bug, no script and no psql session can break the books:
--   1. every entry balances (deferred to commit)
--   2. every entry has at least two lines
--   3. nothing may be posted into a locked or closed period
--   4. posted entries and lines can never be updated or deleted
--   5. lines may only hit active, non-group accounts
-- Corrections are made by posting a reversal, never by editing.
-- ============================================================

CREATE TABLE journal_entry (
  id             BIGSERIAL PRIMARY KEY,
  entry_no       TEXT NOT NULL UNIQUE,
  entry_date     DATE NOT NULL,
  memo           TEXT NOT NULL,
  source         TEXT NOT NULL,              -- 'Sales Invoice', 'Payroll', ...
  source_table   TEXT,                       -- document that produced it
  source_id      BIGINT,
  project_id     BIGINT,                     -- FK added in 003
  reversal_of_id BIGINT REFERENCES journal_entry(id),
  posted_by      BIGINT NOT NULL REFERENCES app_user(id),
  posted_by_name TEXT NOT NULL,              -- survives user deletion
  posted_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  period_id      INT NOT NULL REFERENCES fiscal_period(id),
  CHECK (memo <> '')
);
CREATE INDEX journal_entry_date_idx   ON journal_entry (entry_date);
CREATE INDEX journal_entry_source_idx ON journal_entry (source_table, source_id);
CREATE UNIQUE INDEX journal_entry_one_reversal ON journal_entry (reversal_of_id)
  WHERE reversal_of_id IS NOT NULL;   -- an entry can be reversed only once

CREATE TABLE journal_line (
  id           BIGSERIAL PRIMARY KEY,
  entry_id     BIGINT NOT NULL REFERENCES journal_entry(id),
  line_no      INT NOT NULL,
  account_code TEXT NOT NULL REFERENCES account(code),
  debit        money_qar NOT NULL DEFAULT 0,
  credit       money_qar NOT NULL DEFAULT 0,
  party_id     BIGINT,        -- FK added in 003
  project_id   BIGINT,
  employee_id  BIGINT,
  asset_id     BIGINT,
  item_id      BIGINT,
  memo         TEXT,
  UNIQUE (entry_id, line_no),
  CHECK (debit >= 0 AND credit >= 0),
  -- exactly one side carries a non-zero amount
  CHECK ((debit = 0) <> (credit = 0))
);
CREATE INDEX journal_line_entry_idx   ON journal_line (entry_id);
CREATE INDEX journal_line_account_idx ON journal_line (account_code, entry_id);
CREATE INDEX journal_line_party_idx   ON journal_line (party_id)   WHERE party_id   IS NOT NULL;
CREATE INDEX journal_line_project_idx ON journal_line (project_id) WHERE project_id IS NOT NULL;

-- ---------- 1 + 2. balance and minimum two lines ----------
-- DEFERRABLE so lines can be inserted one at a time inside the
-- transaction; the check runs once, at COMMIT.
CREATE OR REPLACE FUNCTION assert_entry_balanced() RETURNS TRIGGER AS $$
DECLARE v_dr money_qar; v_cr money_qar; v_n INT; v_id BIGINT;
BEGIN
  -- the same check guards both tables; NEW has different shapes
  IF TG_TABLE_NAME = 'journal_entry' THEN v_id := NEW.id; ELSE v_id := NEW.entry_id; END IF;
  SELECT COALESCE(SUM(debit),0), COALESCE(SUM(credit),0), COUNT(*)
    INTO v_dr, v_cr, v_n FROM journal_line WHERE entry_id = v_id;

  IF v_n < 2 THEN
    RAISE EXCEPTION 'Entry % has % line(s); a journal entry needs at least two', v_id, v_n
      USING ERRCODE = 'check_violation';
  END IF;
  IF v_dr <> v_cr THEN
    RAISE EXCEPTION 'Entry % does not balance: debits % vs credits % (out by %)',
      v_id, v_dr, v_cr, (v_dr - v_cr) USING ERRCODE = 'check_violation';
  END IF;
  IF v_dr = 0 THEN
    RAISE EXCEPTION 'Entry % has no value', v_id USING ERRCODE = 'check_violation';
  END IF;
  RETURN NULL;
END $$ LANGUAGE plpgsql;

CREATE CONSTRAINT TRIGGER journal_entry_balances
  AFTER INSERT ON journal_entry
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION assert_entry_balanced();

CREATE CONSTRAINT TRIGGER journal_line_balances
  AFTER INSERT ON journal_line
  DEFERRABLE INITIALLY DEFERRED
  FOR EACH ROW EXECUTE FUNCTION assert_entry_balanced();

-- ---------- 3. the period must be open ----------
CREATE OR REPLACE FUNCTION assert_period_open() RETURNS TRIGGER AS $$
DECLARE v_period fiscal_period; v_year_status period_status;
BEGIN
  SELECT * INTO v_period FROM fiscal_period
   WHERE NEW.entry_date BETWEEN starts_on AND ends_on;

  IF v_period.id IS NULL THEN
    RAISE EXCEPTION 'No fiscal period covers %; open the year before posting to it', NEW.entry_date
      USING ERRCODE = 'check_violation';
  END IF;
  IF v_period.status <> 'OPEN' THEN
    RAISE EXCEPTION 'Period % (% to %) is %; reopen it or post to an open period',
      v_period.period_no, v_period.starts_on, v_period.ends_on, v_period.status
      USING ERRCODE = 'check_violation';
  END IF;

  SELECT status INTO v_year_status FROM fiscal_year WHERE id = v_period.fiscal_year_id;
  IF v_year_status <> 'OPEN' THEN
    RAISE EXCEPTION 'Financial year is %; it cannot receive postings', v_year_status
      USING ERRCODE = 'check_violation';
  END IF;

  NEW.period_id := v_period.id;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER journal_entry_period_open BEFORE INSERT ON journal_entry
  FOR EACH ROW EXECUTE FUNCTION assert_period_open();

-- ---------- 4. immutability ----------
CREATE TRIGGER journal_entry_immutable BEFORE UPDATE OR DELETE ON journal_entry
  FOR EACH ROW EXECUTE FUNCTION deny_change();
CREATE TRIGGER journal_line_immutable BEFORE UPDATE OR DELETE ON journal_line
  FOR EACH ROW EXECUTE FUNCTION deny_change();

-- ---------- 5. lines may only hit postable accounts ----------
CREATE OR REPLACE FUNCTION assert_account_postable() RETURNS TRIGGER AS $$
DECLARE a account;
BEGIN
  SELECT * INTO a FROM account WHERE code = NEW.account_code;
  IF a.is_group THEN
    RAISE EXCEPTION 'Account % (%) is a heading and cannot be posted to', a.code, a.name
      USING ERRCODE = 'check_violation';
  END IF;
  IF NOT a.is_active THEN
    RAISE EXCEPTION 'Account % (%) is inactive', a.code, a.name USING ERRCODE = 'check_violation';
  END IF;
  IF a.requires_party AND NEW.party_id IS NULL THEN
    RAISE EXCEPTION 'Account % (%) is a control account; every line must name a party', a.code, a.name
      USING ERRCODE = 'check_violation';
  END IF;
  -- Staff advances and gratuity are tracked per employee, who is not
  -- a party. Without this the provision cannot be split per person
  -- and an end-of-service settlement has nothing to settle against.
  IF a.requires_employee AND NEW.employee_id IS NULL THEN
    RAISE EXCEPTION 'Account % (%) is tracked per employee; every line must name one', a.code, a.name
      USING ERRCODE = 'check_violation';
  END IF;
  IF a.requires_project AND NEW.project_id IS NULL THEN
    RAISE EXCEPTION 'Account % (%) requires a project', a.code, a.name USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER journal_line_postable BEFORE INSERT ON journal_line
  FOR EACH ROW EXECUTE FUNCTION assert_account_postable();

-- ============================================================
-- Derived views. No balance is ever stored: every figure in every
-- report is computed from these, so a report cannot disagree with
-- the ledger.
-- ============================================================

CREATE VIEW v_journal AS
SELECT e.id, e.entry_no, e.entry_date, e.memo, e.source, e.project_id,
       e.posted_by_name, e.posted_at, e.reversal_of_id,
       (r.id IS NOT NULL) AS is_reversed,
       (SELECT SUM(debit) FROM journal_line l WHERE l.entry_id = e.id) AS amount
  FROM journal_entry e
  LEFT JOIN journal_entry r ON r.reversal_of_id = e.id;

-- Signed movement per line: positive = the account's normal side.
CREATE VIEW v_ledger AS
SELECT l.id AS line_id, l.entry_id, e.entry_no, e.entry_date, e.source, e.memo AS entry_memo,
       l.line_no, l.account_code, a.name AS account_name, a.name_ar AS account_name_ar,
       a.type AS account_type, l.debit, l.credit,
       (l.debit - l.credit) AS movement,
       (l.debit - l.credit) * account_sign(a.type) AS natural_movement,
       l.party_id, l.project_id, l.employee_id, l.asset_id, l.item_id,
       COALESCE(l.memo, e.memo) AS line_memo, e.period_id
  FROM journal_line l
  JOIN journal_entry e ON e.id = l.entry_id
  JOIN account a       ON a.code = l.account_code;

CREATE VIEW v_trial_balance AS
SELECT a.code, a.name, a.name_ar, a.type,
       COALESCE(SUM(l.debit),0)  AS total_debit,
       COALESCE(SUM(l.credit),0) AS total_credit,
       COALESCE(SUM(l.debit - l.credit),0) AS balance,
       COALESCE(SUM(l.debit - l.credit),0) * account_sign(a.type) AS natural_balance
  FROM account a
  LEFT JOIN journal_line l ON l.account_code = a.code
 WHERE NOT a.is_group
 GROUP BY a.code, a.name, a.name_ar, a.type;

-- Health check: if this ever returns a non-zero row, stop and investigate.
CREATE VIEW v_ledger_health AS
SELECT (SELECT COALESCE(SUM(debit - credit),0) FROM journal_line)      AS trial_balance_net,
       (SELECT COUNT(*) FROM (
          SELECT entry_id FROM journal_line GROUP BY entry_id
           HAVING SUM(debit) <> SUM(credit)) x)                        AS unbalanced_entries,
       (SELECT COUNT(*) FROM (
          SELECT entry_id FROM journal_line GROUP BY entry_id
           HAVING COUNT(*) < 2) y)                                     AS single_line_entries;
