-- ============================================================
-- MIZAN ERP · 003 · master data
-- ============================================================

CREATE TYPE party_kind    AS ENUM ('CUSTOMER','SUPPLIER','BOTH');
CREATE TYPE project_status AS ENUM ('NOT_STARTED','IN_PROGRESS','ON_HOLD','COMPLETED','CLOSED');
CREATE TYPE asset_status  AS ENUM ('IN_USE','DISPOSED','WRITTEN_OFF');

-- One table for customers and suppliers: in trading the same
-- company is very often both, and two tables means two balances.
CREATE TABLE party (
  id             BIGSERIAL PRIMARY KEY,
  code           TEXT NOT NULL UNIQUE,
  kind           party_kind NOT NULL,
  name           TEXT NOT NULL,
  name_ar        TEXT,
  cr_no          TEXT,
  tax_no         TEXT,
  contact_person TEXT,
  phone          TEXT,
  email          TEXT,
  address        TEXT,
  terms_days     INT NOT NULL DEFAULT 30,
  credit_limit   money_qar,
  is_active      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_by     BIGINT REFERENCES app_user(id),
  CHECK (terms_days >= 0)
);
CREATE INDEX party_kind_idx ON party (kind) WHERE is_active;

CREATE TABLE employee (
  id           BIGSERIAL PRIMARY KEY,
  code         TEXT NOT NULL UNIQUE,
  name         TEXT NOT NULL,
  name_ar      TEXT,
  qid          TEXT,
  position     TEXT,
  department   TEXT,
  joined_on    DATE NOT NULL,
  left_on      DATE,
  basic_salary money_qar NOT NULL DEFAULT 0,
  allowances   money_qar NOT NULL DEFAULT 0,
  bank_name    TEXT,
  iban         TEXT,
  project_id   BIGINT,                -- default cost centre
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (basic_salary >= 0 AND allowances >= 0),
  CHECK (left_on IS NULL OR left_on >= joined_on)
);

-- ---------- projects, with a schedule baseline that never moves ----------
CREATE TABLE project (
  id               BIGSERIAL PRIMARY KEY,
  code             TEXT NOT NULL UNIQUE,
  name             TEXT NOT NULL,
  name_ar          TEXT,
  client_id        BIGINT REFERENCES party(id),
  starts_on        DATE NOT NULL,
  baseline_end_on  DATE NOT NULL,     -- the original contract date; set once
  end_on           DATE NOT NULL,     -- current, after approved revisions
  contract_value   money_qar NOT NULL DEFAULT 0,
  retention_pct    NUMERIC(5,2) NOT NULL DEFAULT 10,
  advance_pct      NUMERIC(5,2) NOT NULL DEFAULT 0,
  manager          TEXT,
  location         TEXT,
  scope            TEXT,
  status           project_status NOT NULL DEFAULT 'IN_PROGRESS',
  created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (end_on >= starts_on),
  CHECK (retention_pct BETWEEN 0 AND 100),
  CHECK (contract_value >= 0)
);

ALTER TABLE employee       ADD CONSTRAINT employee_project_fk       FOREIGN KEY (project_id) REFERENCES project(id);
ALTER TABLE journal_entry  ADD CONSTRAINT journal_entry_project_fk  FOREIGN KEY (project_id) REFERENCES project(id);
ALTER TABLE journal_line   ADD CONSTRAINT journal_line_project_fk   FOREIGN KEY (project_id) REFERENCES project(id);
ALTER TABLE journal_line   ADD CONSTRAINT journal_line_party_fk     FOREIGN KEY (party_id)   REFERENCES party(id);
ALTER TABLE journal_line   ADD CONSTRAINT journal_line_employee_fk  FOREIGN KEY (employee_id) REFERENCES employee(id);

-- Moving a contract end date is an event with a reason and an
-- approver, never a silent edit. The baseline is immutable.
CREATE TABLE project_revision (
  id            BIGSERIAL PRIMARY KEY,
  project_id    BIGINT NOT NULL REFERENCES project(id),
  logged_on     DATE NOT NULL DEFAULT CURRENT_DATE,
  from_end_on   DATE NOT NULL,
  to_end_on     DATE NOT NULL,
  days_moved    INT GENERATED ALWAYS AS (to_end_on - from_end_on) STORED,
  reason        TEXT NOT NULL,
  approved_by   TEXT NOT NULL,
  created_by    BIGINT REFERENCES app_user(id),
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (reason <> '' AND approved_by <> '')
);
CREATE INDEX project_revision_project_idx ON project_revision (project_id, logged_on);
CREATE TRIGGER project_revision_immutable BEFORE UPDATE OR DELETE ON project_revision
  FOR EACH ROW EXECUTE FUNCTION deny_change();

-- The baseline may never be changed once the project exists, and
-- any change to end_on must leave a revision behind.
CREATE OR REPLACE FUNCTION assert_schedule_traceable() RETURNS TRIGGER AS $$
DECLARE v_logged INT;
BEGIN
  IF NEW.baseline_end_on <> OLD.baseline_end_on THEN
    RAISE EXCEPTION 'The baseline end date is fixed at % and cannot be changed', OLD.baseline_end_on
      USING ERRCODE = 'check_violation';
  END IF;
  IF NEW.end_on <> OLD.end_on THEN
    SELECT COUNT(*) INTO v_logged FROM project_revision
     WHERE project_id = NEW.id AND from_end_on = OLD.end_on AND to_end_on = NEW.end_on;
    IF v_logged = 0 THEN
      RAISE EXCEPTION 'Log a project_revision before moving the end date from % to %', OLD.end_on, NEW.end_on
        USING ERRCODE = 'check_violation';
    END IF;
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER project_schedule_traceable BEFORE UPDATE ON project
  FOR EACH ROW EXECUTE FUNCTION assert_schedule_traceable();

-- Days a contract is past its end date; the red flag is > 1.
CREATE VIEW v_project_schedule AS
SELECT p.*,
       (CURRENT_DATE - p.end_on) AS days_over,
       (p.end_on - p.baseline_end_on) AS slip_days,
       (SELECT COUNT(*) FROM project_revision r WHERE r.project_id = p.id) AS revision_count,
       (p.status NOT IN ('COMPLETED','CLOSED') AND (CURRENT_DATE - p.end_on) > 1) AS is_overdue
  FROM project p;

-- ---------- inventory ----------
CREATE TABLE item (
  id                BIGSERIAL PRIMARY KEY,
  code              TEXT NOT NULL UNIQUE,
  name              TEXT NOT NULL,
  name_ar           TEXT,
  category          TEXT,
  uom               TEXT NOT NULL DEFAULT 'NOS',
  inventory_account TEXT NOT NULL REFERENCES account(code),
  reorder_level     qty NOT NULL DEFAULT 0,
  sell_price        money_qar NOT NULL DEFAULT 0,
  is_active         BOOLEAN NOT NULL DEFAULT TRUE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Every movement carries the running balance and weighted-average
-- cost as at that moment, so stock can be valued at any past date
-- and the item master can be rebuilt from the moves alone.
CREATE TABLE stock_move (
  id             BIGSERIAL PRIMARY KEY,
  item_id        BIGINT NOT NULL REFERENCES item(id),
  moved_on       DATE NOT NULL,
  qty            qty NOT NULL,              -- signed: + in, - out
  unit_cost      unit_cost NOT NULL,
  value          money_qar NOT NULL,        -- rounded exactly as the journal rounds it
  balance_qty    qty NOT NULL,
  balance_value  money_qar NOT NULL,
  wac            unit_cost NOT NULL,
  reference      TEXT,
  entry_id       BIGINT REFERENCES journal_entry(id),
  project_id     BIGINT REFERENCES project(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (qty <> 0)
);
CREATE INDEX stock_move_item_idx ON stock_move (item_id, moved_on, id);
CREATE TRIGGER stock_move_immutable BEFORE UPDATE OR DELETE ON stock_move
  FOR EACH ROW EXECUTE FUNCTION deny_change();

CREATE VIEW v_stock_on_hand AS
SELECT i.id, i.code, i.name, i.name_ar, i.uom, i.category, i.inventory_account,
       i.reorder_level, i.sell_price,
       COALESCE(m.balance_qty, 0)   AS on_hand,
       COALESCE(m.balance_value, 0) AS stock_value,
       COALESCE(m.wac, 0)           AS avg_cost
  FROM item i
  LEFT JOIN LATERAL (
    SELECT balance_qty, balance_value, wac FROM stock_move
     WHERE item_id = i.id ORDER BY moved_on DESC, id DESC LIMIT 1) m ON TRUE;

-- ---------- fixed assets ----------
CREATE TABLE fixed_asset (
  id              BIGSERIAL PRIMARY KEY,
  tag             TEXT NOT NULL UNIQUE,
  name            TEXT NOT NULL,
  name_ar         TEXT,
  category        TEXT NOT NULL,
  asset_account   TEXT NOT NULL REFERENCES account(code),
  accdep_account  TEXT NOT NULL REFERENCES account(code),
  serial_no       TEXT,
  acquired_on     DATE NOT NULL,
  in_service_on   DATE NOT NULL,
  cost            money_qar NOT NULL,
  residual_value  money_qar NOT NULL DEFAULT 0,
  life_months     INT NOT NULL,
  custodian       TEXT,
  project_id      BIGINT REFERENCES project(id),
  depreciated_to  DATE,
  status          asset_status NOT NULL DEFAULT 'IN_USE',
  disposed_on     DATE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (cost > 0 AND residual_value >= 0 AND residual_value < cost),
  CHECK (life_months > 0),
  CHECK (in_service_on >= acquired_on)
);

ALTER TABLE journal_line ADD CONSTRAINT journal_line_asset_fk FOREIGN KEY (asset_id) REFERENCES fixed_asset(id);
ALTER TABLE journal_line ADD CONSTRAINT journal_line_item_fk  FOREIGN KEY (item_id)  REFERENCES item(id);

CREATE VIEW v_asset_register AS
SELECT a.*,
       ROUND((a.cost - a.residual_value) / a.life_months, 2) AS monthly_charge,
       COALESCE((SELECT SUM(l.credit - l.debit) FROM journal_line l
                  WHERE l.asset_id = a.id AND l.account_code = a.accdep_account), 0) AS accumulated_depreciation,
       a.cost - COALESCE((SELECT SUM(l.credit - l.debit) FROM journal_line l
                  WHERE l.asset_id = a.id AND l.account_code = a.accdep_account), 0) AS net_book_value
  FROM fixed_asset a;
