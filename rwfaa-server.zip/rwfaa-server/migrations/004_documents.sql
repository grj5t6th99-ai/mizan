-- ============================================================
-- MIZAN ERP · 004 · sub-ledger documents
--
-- Documents are mutable while DRAFT. Posting creates the journal
-- entry and freezes the document. A posted document is corrected
-- by voiding it, which posts a reversal — never by editing.
-- ============================================================

CREATE TYPE sales_doc_type    AS ENUM ('TRADING','CERTIFICATE','SERVICE','CREDIT_NOTE');
CREATE TYPE purchase_doc_type AS ENUM ('STOCK','PROJECT_COST','SUBCONTRACT','OVERHEAD','DEBIT_NOTE');
CREATE TYPE cash_direction    AS ENUM ('IN','OUT');

-- ---------- sales ----------
CREATE TABLE sales_invoice (
  id                BIGSERIAL PRIMARY KEY,
  doc_no            TEXT UNIQUE,               -- allocated at posting
  doc_type          sales_doc_type NOT NULL,
  status            doc_status NOT NULL DEFAULT 'DRAFT',
  invoice_date      DATE NOT NULL,
  due_date          DATE NOT NULL,
  party_id          BIGINT NOT NULL REFERENCES party(id),
  project_id        BIGINT REFERENCES project(id),
  gross_amount      money_qar NOT NULL DEFAULT 0,
  retention_amount  money_qar NOT NULL DEFAULT 0,
  advance_recovered money_qar NOT NULL DEFAULT 0,
  net_receivable    money_qar NOT NULL DEFAULT 0,
  narration         TEXT,
  entry_id          BIGINT UNIQUE REFERENCES journal_entry(id),
  created_by        BIGINT REFERENCES app_user(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  posted_at         TIMESTAMPTZ,
  voided_by_entry   BIGINT REFERENCES journal_entry(id),
  CHECK (gross_amount >= 0 AND retention_amount >= 0 AND advance_recovered >= 0),
  CHECK (due_date >= invoice_date),
  CHECK (retention_amount + advance_recovered <= gross_amount),
  CHECK ((status = 'POSTED') = (entry_id IS NOT NULL)),
  CHECK ((status = 'POSTED') = (doc_no IS NOT NULL)),
  -- a payment certificate always belongs to a contract
  CHECK (doc_type <> 'CERTIFICATE' OR project_id IS NOT NULL)
);
CREATE INDEX sales_invoice_party_idx ON sales_invoice (party_id, status);

CREATE TABLE sales_invoice_line (
  id           BIGSERIAL PRIMARY KEY,
  invoice_id   BIGINT NOT NULL REFERENCES sales_invoice(id) ON DELETE CASCADE,
  line_no      INT NOT NULL,
  item_id      BIGINT REFERENCES item(id),
  description  TEXT,
  quantity     qty NOT NULL DEFAULT 1,
  unit_price   unit_cost NOT NULL DEFAULT 0,
  revenue_account TEXT REFERENCES account(code),
  line_total   money_qar NOT NULL DEFAULT 0,
  UNIQUE (invoice_id, line_no)
);

-- ---------- purchases ----------
CREATE TABLE purchase_invoice (
  id                BIGSERIAL PRIMARY KEY,
  doc_no            TEXT UNIQUE,
  doc_type          purchase_doc_type NOT NULL,
  status            doc_status NOT NULL DEFAULT 'DRAFT',
  invoice_date      DATE NOT NULL,
  due_date          DATE NOT NULL,
  party_id          BIGINT NOT NULL REFERENCES party(id),
  project_id        BIGINT REFERENCES project(id),
  supplier_ref      TEXT,
  gross_amount      money_qar NOT NULL DEFAULT 0,
  retention_amount  money_qar NOT NULL DEFAULT 0,
  advance_recovered money_qar NOT NULL DEFAULT 0,
  net_payable       money_qar NOT NULL DEFAULT 0,
  narration         TEXT,
  entry_id          BIGINT UNIQUE REFERENCES journal_entry(id),
  created_by        BIGINT REFERENCES app_user(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
  posted_at         TIMESTAMPTZ,
  voided_by_entry   BIGINT REFERENCES journal_entry(id),
  CHECK (gross_amount >= 0 AND retention_amount >= 0 AND advance_recovered >= 0),
  CHECK (due_date >= invoice_date),
  CHECK (retention_amount + advance_recovered <= gross_amount),
  CHECK ((status = 'POSTED') = (entry_id IS NOT NULL)),
  CHECK ((status = 'POSTED') = (doc_no IS NOT NULL))
);
CREATE INDEX purchase_invoice_party_idx ON purchase_invoice (party_id, status);

CREATE TABLE purchase_invoice_line (
  id           BIGSERIAL PRIMARY KEY,
  invoice_id   BIGINT NOT NULL REFERENCES purchase_invoice(id) ON DELETE CASCADE,
  line_no      INT NOT NULL,
  item_id      BIGINT REFERENCES item(id),
  expense_account TEXT REFERENCES account(code),
  description  TEXT,
  quantity     qty NOT NULL DEFAULT 1,
  unit_cost    unit_cost NOT NULL DEFAULT 0,
  line_total   money_qar NOT NULL DEFAULT 0,
  UNIQUE (invoice_id, line_no)
);

-- ---------- cash movements, with maker/checker ----------
CREATE TABLE cash_document (
  id             BIGSERIAL PRIMARY KEY,
  doc_no         TEXT UNIQUE,
  direction      cash_direction NOT NULL,
  status         doc_status NOT NULL DEFAULT 'DRAFT',
  doc_date       DATE NOT NULL,
  party_id       BIGINT REFERENCES party(id),
  employee_id    BIGINT REFERENCES employee(id),
  project_id     BIGINT REFERENCES project(id),
  cash_account   TEXT NOT NULL REFERENCES account(code),
  contra_account TEXT REFERENCES account(code),   -- for direct receipts/payments
  purpose        TEXT NOT NULL,                   -- SETTLEMENT | ADVANCE | DIRECT | TRANSFER | PAYROLL
  method         TEXT,
  reference      TEXT,
  amount         money_qar NOT NULL,
  narration      TEXT,
  entry_id       BIGINT UNIQUE REFERENCES journal_entry(id),
  created_by     BIGINT REFERENCES app_user(id),
  created_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
  approved_by    BIGINT REFERENCES app_user(id),
  approved_at    TIMESTAMPTZ,
  posted_at      TIMESTAMPTZ,
  CHECK (amount > 0),
  CHECK ((status = 'POSTED') = (entry_id IS NOT NULL))
);
CREATE INDEX cash_document_status_idx ON cash_document (status, doc_date);

-- The maker may not be the checker. Enforced, not trusted.
CREATE OR REPLACE FUNCTION assert_segregation_of_duties() RETURNS TRIGGER AS $$
BEGIN
  IF NEW.approved_by IS NOT NULL AND NEW.approved_by = NEW.created_by THEN
    RAISE EXCEPTION 'A payment cannot be approved by the person who raised it'
      USING ERRCODE = 'check_violation';
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE TRIGGER cash_document_segregation BEFORE INSERT OR UPDATE ON cash_document
  FOR EACH ROW EXECUTE FUNCTION assert_segregation_of_duties();

-- Which invoices a receipt or payment was applied to.
CREATE TABLE cash_allocation (
  id                  BIGSERIAL PRIMARY KEY,
  cash_document_id    BIGINT NOT NULL REFERENCES cash_document(id) ON DELETE CASCADE,
  sales_invoice_id    BIGINT REFERENCES sales_invoice(id),
  purchase_invoice_id BIGINT REFERENCES purchase_invoice(id),
  amount              money_qar NOT NULL,
  CHECK (amount > 0),
  CHECK ((sales_invoice_id IS NOT NULL) <> (purchase_invoice_id IS NOT NULL))
);
CREATE INDEX cash_allocation_si_idx ON cash_allocation (sales_invoice_id);
CREATE INDEX cash_allocation_pi_idx ON cash_allocation (purchase_invoice_id);

-- ---------- open-item views: the sub-ledgers ----------
CREATE VIEW v_open_sales_invoice AS
SELECT i.*, p.name AS party_name, p.name_ar AS party_name_ar,
       COALESCE(a.paid, 0) AS paid,
       i.net_receivable - COALESCE(a.paid, 0) AS outstanding,
       GREATEST(CURRENT_DATE - i.due_date, 0) AS days_overdue
  FROM sales_invoice i
  JOIN party p ON p.id = i.party_id
  LEFT JOIN LATERAL (
    SELECT SUM(al.amount) AS paid FROM cash_allocation al
      JOIN cash_document c ON c.id = al.cash_document_id AND c.status = 'POSTED'
     WHERE al.sales_invoice_id = i.id) a ON TRUE
 WHERE i.status = 'POSTED';

CREATE VIEW v_open_purchase_invoice AS
SELECT i.*, p.name AS party_name, p.name_ar AS party_name_ar,
       COALESCE(a.paid, 0) AS paid,
       i.net_payable - COALESCE(a.paid, 0) AS outstanding,
       GREATEST(CURRENT_DATE - i.due_date, 0) AS days_overdue
  FROM purchase_invoice i
  JOIN party p ON p.id = i.party_id
  LEFT JOIN LATERAL (
    SELECT SUM(al.amount) AS paid FROM cash_allocation al
      JOIN cash_document c ON c.id = al.cash_document_id AND c.status = 'POSTED'
     WHERE al.purchase_invoice_id = i.id) a ON TRUE
 WHERE i.status = 'POSTED';

-- ---------- advances: derived from the ledger, never stored ----------
CREATE VIEW v_advance_position AS
SELECT 'CUSTOMER' AS side, l.party_id, l.project_id,
       SUM(l.credit) AS advanced, SUM(l.debit) AS recovered,
       SUM(l.credit - l.debit) AS outstanding
  FROM journal_line l JOIN account a ON a.code = l.account_code
 WHERE a.code = control('cust_adv') GROUP BY l.party_id, l.project_id
UNION ALL
SELECT 'SUPPLIER', l.party_id, l.project_id,
       SUM(l.debit), SUM(l.credit), SUM(l.debit - l.credit)
  FROM journal_line l JOIN account a ON a.code = l.account_code
 WHERE a.code = control('supp_adv') GROUP BY l.party_id, l.project_id;

-- ---------- payroll ----------
CREATE TABLE payroll_run (
  id           BIGSERIAL PRIMARY KEY,
  period_end   DATE NOT NULL UNIQUE,        -- one run per month, enforced
  status       doc_status NOT NULL DEFAULT 'DRAFT',
  gross_total  money_qar NOT NULL DEFAULT 0,
  deductions   money_qar NOT NULL DEFAULT 0,
  net_total    money_qar NOT NULL DEFAULT 0,
  entry_id     BIGINT UNIQUE REFERENCES journal_entry(id),
  created_by   BIGINT REFERENCES app_user(id),
  approved_by  BIGINT REFERENCES app_user(id),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  posted_at    TIMESTAMPTZ
);

CREATE TABLE payroll_line (
  id                BIGSERIAL PRIMARY KEY,
  run_id            BIGINT NOT NULL REFERENCES payroll_run(id) ON DELETE CASCADE,
  employee_id       BIGINT NOT NULL REFERENCES employee(id),
  project_id        BIGINT REFERENCES project(id),
  basic             money_qar NOT NULL DEFAULT 0,
  allowances        money_qar NOT NULL DEFAULT 0,
  overtime          money_qar NOT NULL DEFAULT 0,
  other_deductions  money_qar NOT NULL DEFAULT 0,
  advance_recovered money_qar NOT NULL DEFAULT 0,
  net_pay           money_qar NOT NULL DEFAULT 0,
  UNIQUE (run_id, employee_id)
);

-- ---------- depreciation ----------
CREATE TABLE depreciation_run (
  id         BIGSERIAL PRIMARY KEY,
  run_to     DATE NOT NULL UNIQUE,
  status     doc_status NOT NULL DEFAULT 'DRAFT',
  total      money_qar NOT NULL DEFAULT 0,
  entry_id   BIGINT UNIQUE REFERENCES journal_entry(id),
  created_by BIGINT REFERENCES app_user(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE depreciation_line (
  id       BIGSERIAL PRIMARY KEY,
  run_id   BIGINT NOT NULL REFERENCES depreciation_run(id) ON DELETE CASCADE,
  asset_id BIGINT NOT NULL REFERENCES fixed_asset(id),
  months   INT NOT NULL,
  amount   money_qar NOT NULL,
  UNIQUE (run_id, asset_id)
);
