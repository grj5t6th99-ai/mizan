-- ============================================================
-- MIZAN ERP · 005 · sessions, login safety, tax placeholders
-- ============================================================

-- ---------- sessions ----------
-- Server-side sessions, not JWTs: revoking access must be instant
-- for a system holding statutory books.
CREATE TABLE session (
  id          TEXT PRIMARY KEY,          -- 32 random bytes, base64url
  user_id     BIGINT NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at  TIMESTAMPTZ NOT NULL,
  ip          TEXT,
  user_agent  TEXT
);
CREATE INDEX session_user_idx    ON session (user_id);
CREATE INDEX session_expires_idx ON session (expires_at);

-- ---------- brute-force protection ----------
ALTER TABLE app_user
  ADD COLUMN failed_logins INT NOT NULL DEFAULT 0,
  ADD COLUMN locked_until  TIMESTAMPTZ,
  ADD COLUMN must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN locale TEXT NOT NULL DEFAULT 'en';

-- ---------- tax placeholders ----------
-- Qatar has not implemented VAT, so every rate below is zero and
-- every posted amount is tax-free. The columns exist now so that
-- introducing tax later is a migration and a rate change, not a
-- reshaping of documents that already carry postings.
CREATE TABLE tax_code (
  code        TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  name_ar     TEXT,
  rate_pct    NUMERIC(6,3) NOT NULL DEFAULT 0,
  output_account TEXT REFERENCES account(code),  -- tax charged on sales
  input_account  TEXT REFERENCES account(code),  -- tax paid on purchases
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  effective_from DATE,
  CHECK (rate_pct >= 0)
);

INSERT INTO tax_code (code, name, name_ar, rate_pct, effective_from) VALUES
  ('NONE', 'No tax', 'بدون ضريبة', 0, '2000-01-01');

ALTER TABLE sales_invoice
  ADD COLUMN tax_code   TEXT NOT NULL DEFAULT 'NONE' REFERENCES tax_code(code),
  ADD COLUMN tax_amount money_qar NOT NULL DEFAULT 0;
ALTER TABLE purchase_invoice
  ADD COLUMN tax_code   TEXT NOT NULL DEFAULT 'NONE' REFERENCES tax_code(code),
  ADD COLUMN tax_amount money_qar NOT NULL DEFAULT 0;
ALTER TABLE sales_invoice_line    ADD COLUMN tax_amount money_qar NOT NULL DEFAULT 0;
ALTER TABLE purchase_invoice_line ADD COLUMN tax_amount money_qar NOT NULL DEFAULT 0;

-- ---------- convenience: who am I allowed to be ----------
CREATE VIEW v_user AS
SELECT u.id, u.email, u.name, u.name_ar, u.locale, u.is_active, u.must_change_password,
       u.role_code, r.name AS role_name, r.name_ar AS role_name_ar,
       r.can_post, r.can_approve, r.can_close_period, r.can_admin, r.approval_limit
  FROM app_user u JOIN role r ON r.code = u.role_code;
