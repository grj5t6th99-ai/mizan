-- ============================================================
-- MIZAN ERP · 001 · foundation
-- Users, immutable audit trail, fiscal calendar, chart of
-- accounts, and gapless document numbering.
-- ============================================================

-- Money: NUMERIC never float. 2dp for posted amounts (QAR has
-- 100 dirhams), 6dp for unit costs so weighted-average cost does
-- not lose precision before it is rounded into the journal.
CREATE DOMAIN money_qar AS NUMERIC(18,2);
CREATE DOMAIN unit_cost AS NUMERIC(18,6);
CREATE DOMAIN qty       AS NUMERIC(18,3);

CREATE TYPE account_type AS ENUM ('ASSET','LIABILITY','EQUITY','REVENUE','COS','EXPENSE');
CREATE TYPE period_status AS ENUM ('OPEN','LOCKED','CLOSED');
CREATE TYPE doc_status AS ENUM ('DRAFT','PENDING_APPROVAL','POSTED','VOID');

-- ---------- who ----------
CREATE TABLE role (
  code              TEXT PRIMARY KEY,
  name              TEXT NOT NULL,
  name_ar           TEXT,
  can_post          BOOLEAN NOT NULL DEFAULT FALSE,
  can_approve       BOOLEAN NOT NULL DEFAULT FALSE,
  can_close_period  BOOLEAN NOT NULL DEFAULT FALSE,
  can_admin         BOOLEAN NOT NULL DEFAULT FALSE,
  -- payments at or above this need a second pair of eyes; NULL = no limit
  approval_limit    money_qar
);

CREATE TABLE app_user (
  id            BIGSERIAL PRIMARY KEY,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT NOT NULL,
  name_ar       TEXT,
  role_code     TEXT NOT NULL REFERENCES role(code),
  password_hash TEXT,
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  last_login_at TIMESTAMPTZ,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- audit: append-only, survives what it audits ----------
CREATE TABLE audit_log (
  id         BIGSERIAL PRIMARY KEY,
  at         TIMESTAMPTZ NOT NULL DEFAULT now(),
  user_id    BIGINT REFERENCES app_user(id),
  user_name  TEXT NOT NULL,           -- denormalised: survives user deletion
  action     TEXT NOT NULL,
  entity     TEXT,
  entity_id  TEXT,
  detail     JSONB,
  ip         TEXT
);
CREATE INDEX audit_log_at_idx ON audit_log (at DESC);
CREATE INDEX audit_log_entity_idx ON audit_log (entity, entity_id);

CREATE OR REPLACE FUNCTION deny_change() RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION '% is append-only: % is not permitted', TG_TABLE_NAME, TG_OP
    USING ERRCODE = 'restrict_violation';
END $$ LANGUAGE plpgsql;

CREATE TRIGGER audit_log_immutable BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION deny_change();

-- ---------- when: the fiscal calendar ----------
CREATE TABLE fiscal_year (
  id        SERIAL PRIMARY KEY,
  code      TEXT NOT NULL UNIQUE,
  starts_on DATE NOT NULL,
  ends_on   DATE NOT NULL,
  status    period_status NOT NULL DEFAULT 'OPEN',
  closed_at TIMESTAMPTZ,
  closed_by BIGINT REFERENCES app_user(id),
  CHECK (ends_on > starts_on)
);

CREATE TABLE fiscal_period (
  id             SERIAL PRIMARY KEY,
  fiscal_year_id INT NOT NULL REFERENCES fiscal_year(id),
  period_no      INT NOT NULL,
  starts_on      DATE NOT NULL,
  ends_on        DATE NOT NULL,
  status         period_status NOT NULL DEFAULT 'OPEN',
  locked_at      TIMESTAMPTZ,
  locked_by      BIGINT REFERENCES app_user(id),
  UNIQUE (fiscal_year_id, period_no),
  CHECK (ends_on >= starts_on)
);
CREATE INDEX fiscal_period_range_idx ON fiscal_period (starts_on, ends_on);

-- Which period does a date fall in, and is it open?
CREATE OR REPLACE FUNCTION period_for(p_date DATE)
RETURNS fiscal_period AS $$
  SELECT * FROM fiscal_period WHERE p_date BETWEEN starts_on AND ends_on LIMIT 1;
$$ LANGUAGE sql STABLE;

-- ---------- what: the chart of accounts ----------
CREATE TABLE account (
  code         TEXT PRIMARY KEY,
  name         TEXT NOT NULL,
  name_ar      TEXT,
  type         account_type NOT NULL,
  is_group     BOOLEAN NOT NULL DEFAULT FALSE,
  parent_code  TEXT REFERENCES account(code),
  class_tag    TEXT,                 -- classification, may repeat: 'cash','bank','inventory'
  is_active    BOOLEAN NOT NULL DEFAULT TRUE,
  requires_party    BOOLEAN NOT NULL DEFAULT FALSE, -- AR/AP lines must name a party
  requires_employee BOOLEAN NOT NULL DEFAULT FALSE, -- staff advances, gratuity
  requires_project  BOOLEAN NOT NULL DEFAULT FALSE,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (code ~ '^[0-9]{3,8}$')
);
CREATE INDEX account_type_idx  ON account (type) WHERE NOT is_group;
CREATE INDEX account_class_idx ON account (class_tag) WHERE class_tag IS NOT NULL;

-- Modules must never hardcode an account code. They ask for a
-- control account by role, so the accountant can rebind one
-- (say, move receivables to a new code) without touching code.
CREATE TABLE control_account (
  tag          TEXT PRIMARY KEY,
  account_code TEXT NOT NULL REFERENCES account(code),
  description  TEXT NOT NULL
);

CREATE OR REPLACE FUNCTION control(p_tag TEXT) RETURNS TEXT AS $$
DECLARE v TEXT;
BEGIN
  SELECT account_code INTO v FROM control_account WHERE tag = p_tag;
  IF v IS NULL THEN
    RAISE EXCEPTION 'No control account is bound to "%"', p_tag USING ERRCODE = 'check_violation';
  END IF;
  RETURN v;
END $$ LANGUAGE plpgsql STABLE;

-- Asset categories bind a class of asset to its cost and
-- accumulated-depreciation accounts.
CREATE TABLE asset_category (
  code                TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  name_ar             TEXT,
  asset_account       TEXT NOT NULL REFERENCES account(code),
  accdep_account      TEXT NOT NULL REFERENCES account(code),
  default_life_months INT NOT NULL DEFAULT 60
);

-- The normal side of an account, used to present balances.
CREATE OR REPLACE FUNCTION account_sign(p_type account_type) RETURNS INT AS $$
  SELECT CASE WHEN p_type IN ('ASSET','COS','EXPENSE') THEN 1 ELSE -1 END;
$$ LANGUAGE sql IMMUTABLE;

-- ---------- document numbering ----------
-- Postgres sequences skip numbers on rollback. Auditors ask for
-- gapless series, so numbers come from a locked row instead: the
-- number is released if the transaction rolls back.
CREATE TABLE doc_sequence (
  prefix   TEXT NOT NULL,
  fy       INT  NOT NULL,
  last_no  INT  NOT NULL DEFAULT 0,
  PRIMARY KEY (prefix, fy)
);

CREATE OR REPLACE FUNCTION next_doc_no(p_prefix TEXT, p_date DATE)
RETURNS TEXT AS $$
DECLARE v_fy INT; v_no INT;
BEGIN
  SELECT EXTRACT(YEAR FROM fy.starts_on)::INT INTO v_fy
    FROM fiscal_period p JOIN fiscal_year fy ON fy.id = p.fiscal_year_id
   WHERE p_date BETWEEN p.starts_on AND p.ends_on;
  IF v_fy IS NULL THEN
    RAISE EXCEPTION 'No fiscal period covers %', p_date USING ERRCODE = 'check_violation';
  END IF;

  INSERT INTO doc_sequence (prefix, fy, last_no) VALUES (p_prefix, v_fy, 0)
    ON CONFLICT (prefix, fy) DO NOTHING;

  UPDATE doc_sequence SET last_no = last_no + 1
   WHERE prefix = p_prefix AND fy = v_fy
   RETURNING last_no INTO v_no;

  RETURN p_prefix || '-' || v_fy || '-' || LPAD(v_no::TEXT, 5, '0');
END $$ LANGUAGE plpgsql;

-- ---------- company profile (single tenant) ----------
CREATE TABLE company (
  id                  INT PRIMARY KEY DEFAULT 1,
  name                TEXT NOT NULL,
  name_ar             TEXT,
  cr_no               TEXT,
  tax_no              TEXT,
  address             TEXT,
  address_ar          TEXT,
  phone               TEXT,
  base_currency       TEXT NOT NULL DEFAULT 'QAR',
  retention_pct       NUMERIC(5,2) NOT NULL DEFAULT 10,
  gratuity_days_year  INT NOT NULL DEFAULT 21,
  income_tax_pct      NUMERIC(5,2) NOT NULL DEFAULT 10,
  payment_approval_limit money_qar NOT NULL DEFAULT 50000,
  CHECK (id = 1)
);
