-- Which column of the estimate build-up each cost account belongs to.
--
-- This lives in a seed rather than in migration 006 because migrations
-- run before seeds: 006 adds the column, but the accounts themselves
-- are created by seeds/010, so an UPDATE inside 006 matches no rows on
-- a fresh database. The same statements are left in 006 as well, so an
-- existing database that already has accounts is also covered.
UPDATE account SET cost_category = 'SUBCONTRACT' WHERE code = '5200';
UPDATE account SET cost_category = 'MATERIAL'    WHERE code IN ('5210','5100','5250');
UPDATE account SET cost_category = 'LABOUR'      WHERE code = '5220';
UPDATE account SET cost_category = 'PLANT'       WHERE code = '5230';
UPDATE account SET cost_category = 'OTHER'       WHERE code = '5240';
