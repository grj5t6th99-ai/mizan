/* Runs the migrations against real Postgres (PGlite) and then tries
   hard to break the books. Every "blocked" line below is an attack
   the database refused. */
const { PGlite } = require('@electric-sql/pglite');
const fs = require('fs');

const files = [
  'migrations/001_foundation.sql',
  'migrations/002_ledger.sql',
  'migrations/003_masters.sql',
  'migrations/004_documents.sql',
  'seeds/010_chart_of_accounts.sql'
];

let pass = 0, fail = 0;
const ok  = (m, d) => { pass++; console.log('  \u2713 ' + m + (d ? '  \u2014 ' + d : '')); };
const bad = (m, d) => { fail++; console.log('  \u2717 ' + m + (d ? '  \u2014 ' + d : '')); };

// Assert a statement is refused BY THE DATABASE RULE WE MEAN, not by
// some incidental driver limitation. `expect` must appear in the error.
async function blocked(db, label, sql, expect, params) {
  let msg = null;
  try {
    if (params) { await db.query('BEGIN'); await db.query(sql, params); await db.query('COMMIT'); }
    else        { await db.exec('BEGIN; ' + sql.trim().replace(/;?$/, ';') + ' COMMIT;'); }
  } catch (e) { msg = e.message.split('\n')[0]; }
  await db.exec('ROLLBACK').catch(() => {});
  if (msg === null) return bad(label, 'IT WAS ALLOWED');
  if (/multiple commands|prepared statement/i.test(msg))
    return bad(label, 'driver refused it, so the rule was never exercised: ' + msg);
  if (expect && !msg.toLowerCase().includes(expect.toLowerCase()))
    return bad(label, `blocked, but for the wrong reason: ${msg}`);
  ok(label, msg);
}
async function allowed(db, label, fn) {
  try { await fn(); ok(label); }
  catch (e) { bad(label, e.message.split('\n')[0]); }
}

(async () => {
  const db = await PGlite.create();

  console.log('\n=== migrations ===');
  for (const f of files) {
    try { await db.exec(fs.readFileSync(f, 'utf8')); ok(f); }
    catch (e) { bad(f, e.message.split('\n')[0]); process.exit(1); }
  }

  const n = async (sql, p) => (await db.query(sql, p)).rows;

  console.log('\n=== chart of accounts ===');
  const acc = await n(`SELECT count(*) FILTER (WHERE NOT is_group) AS postable,
                              count(*) FILTER (WHERE is_group) AS headings,
                              count(*) FILTER (WHERE name_ar IS NOT NULL) AS arabic FROM account`);
  ok('accounts loaded', `${acc[0].postable} postable, ${acc[0].headings} headings, ${acc[0].arabic} with Arabic names`);
  const ctl = await n(`SELECT count(*) c FROM control_account`);
  ok('control accounts bound', `${ctl[0].c} roles, resolved via control('ar') not a hardcoded code`);
  ok('control() resolves', `ar -> ${(await n(`SELECT control('ar') c`))[0].c}, ap -> ${(await n(`SELECT control('ap') c`))[0].c}`);
  const orphan = await n(`SELECT count(*) c FROM account a
                           WHERE a.parent_code IS NOT NULL
                             AND NOT EXISTS (SELECT 1 FROM account p WHERE p.code=a.parent_code)`);
  (orphan[0].c === 0 ? ok : bad)('no orphaned parents');

  console.log('\n=== fixtures ===');
  await db.exec(`
    INSERT INTO role (code,name,can_post,can_approve,can_close_period,can_admin,approval_limit) VALUES
      ('OWNER','Owner',TRUE,TRUE,TRUE,TRUE,NULL),
      ('FINMGR','Finance Manager',TRUE,TRUE,TRUE,TRUE,NULL),
      ('ACCT','Accountant',TRUE,FALSE,FALSE,FALSE,50000),
      ('ENGR','Project Engineer',FALSE,FALSE,FALSE,FALSE,0);
    INSERT INTO app_user (email,name,role_code) VALUES
      ('suresh@x.qa','Suresh Menon','FINMGR'),
      ('priya@x.qa','Priya Varghese','ACCT'),
      ('yousef@x.qa','Yousef Baloch','ENGR');
    INSERT INTO company (id,name,name_ar,cr_no) VALUES (1,'Al Rayyan Trading & Contracting W.L.L.','شركة الريان للتجارة والمقاولات','CR 84512');
    INSERT INTO fiscal_year (code,starts_on,ends_on) VALUES ('FY2026','2026-01-01','2026-12-31');
    INSERT INTO fiscal_period (fiscal_year_id,period_no,starts_on,ends_on)
      SELECT 1, m, make_date(2026,m,1), (make_date(2026,m,1)+interval '1 month -1 day')::date
        FROM generate_series(1,12) m;
    INSERT INTO party (code,kind,name,name_ar,terms_days) VALUES
      ('C001','CUSTOMER','Qatari Diar Real Estate','قطري الديار للاستثمار العقاري',60),
      ('S001','SUPPLIER','Bin Omran MEP Subcontracting','بن عمران للمقاولات الكهروميكانيكية',60);
    INSERT INTO project (code,name,client_id,starts_on,baseline_end_on,end_on,contract_value,retention_pct)
      VALUES ('PRJ-2601','Lusail Marina Tower — MEP Fit-Out',1,'2026-01-15','2026-11-30','2026-11-30',4200000,10);
  `);
  ok('roles, users, fiscal calendar, parties, project');

  // helper: post a balanced entry
  async function post(date, memo, source, lines, userId = 1, userName = 'Suresh Menon') {
    await db.query('BEGIN');
    const no = (await db.query(`SELECT next_doc_no($1,$2) v`, ['JV', date])).rows[0].v;
    const e = (await db.query(
      `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ($1,$2,$3,$4,$5,$6,0) RETURNING id`, [no, date, memo, source, userId, userName])).rows[0];
    let i = 0;
    for (const l of lines) {
      await db.query(
        `INSERT INTO journal_line (entry_id,line_no,account_code,debit,credit,party_id,project_id,memo)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [e.id, ++i, l.account, l.debit || 0, l.credit || 0, l.party || null, l.project || null, l.memo || null]);
    }
    await db.query('COMMIT');
    return { id: e.id, no };
  }

  console.log('\n=== the ledger accepts correct work ===');
  let opening;
  await allowed(db, 'opening balances posted', async () => {
    opening = await post('2026-01-01', 'Opening balances brought forward', 'Journal', [
      { account: '1120', debit: 2800000 },
      { account: '1110', debit: 25000 },
      { account: '3100', credit: 2000000 },
      { account: '3300', credit: 825000 }
    ]);
  });
  ok('gapless numbering', `first voucher ${opening.no}`);

  let cert;
  await allowed(db, 'contract payment certificate with retention', async () => {
    cert = await post('2026-03-25', 'IPC 1 — PRJ-2601', 'Sales Invoice', [
      { account: '1130', debit: 558000, party: 1, project: 1, memo: 'Net receivable' },
      { account: '1131', debit: 62000, party: 1, project: 1, memo: 'Retention withheld' },
      { account: '4200', credit: 620000, project: 1, memo: 'Work certified' }
    ]);
  });

  console.log('\n=== and refuses everything else ===');
  await blocked(db, 'unbalanced entry',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-1','2026-04-01','Out of balance','Journal',1,'Suresh',0);
     INSERT INTO journal_line (entry_id,line_no,account_code,debit)
       SELECT id,1,'1120',500 FROM journal_entry WHERE entry_no='X-1';
     INSERT INTO journal_line (entry_id,line_no,account_code,credit)
       SELECT id,2,'4100',400 FROM journal_entry WHERE entry_no='X-1';`, 'does not balance');

  await blocked(db, 'single-line entry',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-2','2026-04-01','One leg','Journal',1,'Suresh',0);
     INSERT INTO journal_line (entry_id,line_no,account_code,debit)
       SELECT id,1,'1120',500 FROM journal_entry WHERE entry_no='X-2';`, 'at least two');

  await blocked(db, 'line with both debit and credit',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-3','2026-04-01','Both sides','Journal',1,'Suresh',0);
     INSERT INTO journal_line (entry_id,line_no,account_code,debit,credit)
       SELECT id,1,'1120',500,500 FROM journal_entry WHERE entry_no='X-3';`, 'journal_line_check');

  await blocked(db, 'negative amount',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-4','2026-04-01','Negative','Journal',1,'Suresh',0);
     INSERT INTO journal_line (entry_id,line_no,account_code,debit)
       SELECT id,1,'1120',-500 FROM journal_entry WHERE entry_no='X-4';`, 'journal_line_check');

  await blocked(db, 'posting to a heading account',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-5','2026-04-01','To a heading','Journal',1,'Suresh',0);
     INSERT INTO journal_line (entry_id,line_no,account_code,debit)
       SELECT id,1,'1000',500 FROM journal_entry WHERE entry_no='X-5';`, 'heading');

  await blocked(db, 'receivable line with no party named',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-6','2026-04-01','Anonymous debtor','Journal',1,'Suresh',0);
     INSERT INTO journal_line (entry_id,line_no,account_code,debit)
       SELECT id,1,'1130',500 FROM journal_entry WHERE entry_no='X-6';`, 'must name a party');

  await blocked(db, 'editing a posted entry',
    `UPDATE journal_entry SET memo='Amended' WHERE id=$1`, 'append-only', [cert.id]);
  await blocked(db, 'deleting a posted line',
    `DELETE FROM journal_line WHERE entry_id=$1`, 'append-only', [cert.id]);
  await blocked(db, 'deleting a posted entry',
    `DELETE FROM journal_entry WHERE id=$1`, 'append-only', [cert.id]);
  await blocked(db, 'tampering with the audit log',
    `INSERT INTO audit_log (user_name,action) VALUES ('x','y');
     UPDATE audit_log SET action='z';`, 'append-only');
  await blocked(db, 'posting to a date with no fiscal period',
    `SELECT next_doc_no('JV','2025-06-01')`, 'No fiscal period');

  console.log('\n=== period locking ===');
  await db.query(`UPDATE fiscal_period SET status='LOCKED' WHERE period_no=3`);
  await blocked(db, 'posting into a locked month',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-7','2026-03-10','Backdated','Journal',1,'Suresh',0);`, 'LOCKED');
  await allowed(db, 'posting into an open month still works', async () => {
    await post('2026-04-10', 'April expense', 'Payment', [
      { account: '6200', debit: 42000 }, { account: '1120', credit: 42000 }]);
  });
  await db.query(`UPDATE fiscal_year SET status='CLOSED' WHERE id=1`);
  await blocked(db, 'posting into a closed year',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,posted_by,posted_by_name,period_id)
       VALUES ('X-8','2026-05-10','After close','Journal',1,'Suresh',0);`, 'CLOSED');
  await db.query(`UPDATE fiscal_year SET status='OPEN' WHERE id=1`);

  console.log('\n=== correction is by reversal, never by edit ===');
  await allowed(db, 'reversal posted', async () => {
    await db.query('BEGIN');
    const no = (await db.query(`SELECT next_doc_no('JV','2026-04-30') v`)).rows[0].v;
    const r = (await db.query(
      `INSERT INTO journal_entry (entry_no,entry_date,memo,source,reversal_of_id,posted_by,posted_by_name,period_id)
       VALUES ($1,'2026-04-30',$2,'Reversal',$3,1,'Suresh Menon',0) RETURNING id`,
      [no, 'Reversal of ' + cert.no, cert.id])).rows[0];
    await db.query(`INSERT INTO journal_line (entry_id,line_no,account_code,debit,credit,party_id,project_id)
      SELECT $1, line_no, account_code, credit, debit, party_id, project_id
        FROM journal_line WHERE entry_id=$2`, [r.id, cert.id]);
    await db.query('COMMIT');
  });
  await blocked(db, 'reversing the same entry twice',
    `INSERT INTO journal_entry (entry_no,entry_date,memo,source,reversal_of_id,posted_by,posted_by_name,period_id)
       VALUES ('X-9','2026-04-30','Second reversal','Reversal',$1,1,'Suresh',0)`,
    'journal_entry_one_reversal', [cert.id]);
  const rev = await n(`SELECT is_reversed FROM v_journal WHERE id=$1`, [cert.id]);
  (rev[0].is_reversed ? ok : bad)('original shows as reversed in v_journal');

  console.log('\n=== project schedule is traceable ===');
  await blocked(db, 'moving the end date with no revision logged',
    `UPDATE project SET end_on='2027-02-28' WHERE id=1`, 'Log a project_revision');
  await blocked(db, 'changing the baseline date',
    `UPDATE project SET baseline_end_on='2027-01-01' WHERE id=1`, 'baseline end date is fixed');
  await allowed(db, 'extension of time with a logged reason', async () => {
    await db.query('BEGIN');
    await db.query(`INSERT INTO project_revision (project_id,logged_on,from_end_on,to_end_on,reason,approved_by,created_by)
      VALUES (1,'2026-08-01','2026-11-30','2027-02-28','Client-approved extension of time','Nasser Al Rayyan',1)`);
    await db.query(`UPDATE project SET end_on='2027-02-28' WHERE id=1`);
    await db.query('COMMIT');
  });
  const sched = await n(`SELECT code,baseline_end_on,end_on,slip_days,revision_count,is_overdue FROM v_project_schedule`);
  ok('baseline preserved', `baseline ${String(sched[0].baseline_end_on).slice(0,10)}, now ${String(sched[0].end_on).slice(0,10)}, slip ${sched[0].slip_days} days, ${sched[0].revision_count} revision`);
  await blocked(db, 'rewriting the revision log',
    `UPDATE project_revision SET reason='Nothing to see here' WHERE id=1`, 'append-only');

  console.log('\n=== segregation of duties ===');
  await db.query(`INSERT INTO cash_document (direction,doc_date,cash_account,purpose,amount,created_by)
                  VALUES ('OUT','2026-04-15','1120','SETTLEMENT',120000,2)`);
  await blocked(db, 'approving your own payment',
    `UPDATE cash_document SET approved_by=2, approved_at=now() WHERE id=1`, 'cannot be approved by the person');
  await allowed(db, 'a second person may approve it', async () => {
    await db.query(`UPDATE cash_document SET approved_by=1, approved_at=now() WHERE id=1`);
  });

  console.log('\n=== the books still stand up ===');
  const h = await n(`SELECT * FROM v_ledger_health`);
  const health = h[0];
  (Number(health.trial_balance_net) === 0 ? ok : bad)('trial balance nets to zero', String(health.trial_balance_net));
  (Number(health.unbalanced_entries) === 0 ? ok : bad)('no unbalanced entries');
  (Number(health.single_line_entries) === 0 ? ok : bad)('no single-line entries');
  const bs = await n(`
    SELECT SUM(natural_balance) FILTER (WHERE type='ASSET') a,
           SUM(natural_balance) FILTER (WHERE type='LIABILITY') l,
           SUM(natural_balance) FILTER (WHERE type='EQUITY') e,
           SUM(natural_balance) FILTER (WHERE type IN ('REVENUE')) r,
           SUM(natural_balance) FILTER (WHERE type IN ('COS','EXPENSE')) x
      FROM v_trial_balance`);
  const b = bs[0], profit = Number(b.r) - Number(b.x);
  const diff = Number(b.a) - (Number(b.l) + Number(b.e) + profit);
  (Math.abs(diff) < 0.005 ? ok : bad)('balance sheet equation holds',
    `assets ${b.a} = liabilities ${b.l} + equity ${b.e} + profit ${profit}`);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
