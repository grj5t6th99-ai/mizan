'use strict';
/* ============================================================
   The contracting flow end to end, against real Postgres:

     price a job -> quote it -> win it -> the estimate becomes the
     budget -> order subcontractors -> spend money -> and see the
     overrun before the job finishes.
   ============================================================ */
process.env.NODE_ENV = 'test';
const http = require('node:http');
const db = require('../src/db');
const auth = require('../src/auth');
const { buildApp } = require('../src/app');

let pass = 0, fail = 0;
const ok = (m, d) => { pass++; console.log('  \u2713 ' + m + (d ? '  \u2014 ' + d : '')); };
const bad = (m, d) => { fail++; console.log('  \u2717 ' + m + (d ? '  \u2014 ' + d : '')); };
const check = (c, m, d) => (c ? ok : bad)(m, d);
const checkR = (c, m, r, d) => (c ? ok : bad)(m, d || r?.body?.error || JSON.stringify(r?.body).slice(0, 120));
const n = v => Number(v);
const money = v => n(v).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

let base, cookie = {};
function req(method, path, body, who = 'fin') {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(base + path, { method, headers: {
      'content-type': 'application/json',
      ...(cookie[who] ? { cookie: cookie[who] } : {}),
      ...(data ? { 'content-length': Buffer.byteLength(data) } : {}) } }, res => {
      let buf = ''; res.on('data', d => buf += d);
      res.on('end', () => {
        const set = res.headers['set-cookie'];
        if (set) cookie[who] = set.map(c => c.split(';')[0]).join('; ');
        let json = null; try { json = JSON.parse(buf); } catch { /* */ }
        resolve({ status: res.statusCode, body: json });
      });
    });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}

(async () => {
  const server = http.createServer(buildApp());
  await new Promise(r => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;

  console.log('\n=== setup ===');
  await db.query(`TRUNCATE audit_log, session, cash_allocation, cash_document,
    sales_invoice_line, sales_invoice, purchase_invoice_line, purchase_invoice,
    payroll_line, payroll_run, depreciation_line, depreciation_run, stock_move,
    subcontract_package, variation_order, journal_line, journal_entry,
    project_revision, cost_code, estimate_line, estimate,
    fixed_asset, item, project, employee, party, doc_sequence,
    fiscal_period, fiscal_year, company, app_user, role RESTART IDENTITY CASCADE`);
  const pw = await auth.hashPassword('correct-horse-battery');
  await db.query(`INSERT INTO role (code,name,can_post,can_approve,can_close_period,can_admin) VALUES
    ('FINMGR','Finance Manager',TRUE,TRUE,TRUE,TRUE),('ACCT','Accountant',TRUE,FALSE,FALSE,FALSE)`);
  await db.query(`INSERT INTO app_user (email,name,role_code,password_hash)
    VALUES ('fin@x.qa','Suresh Menon','FINMGR',$1),('acct@x.qa','Priya Varghese','ACCT',$1)`, [pw]);
  await db.query(`INSERT INTO company (id,name,payment_approval_limit)
    VALUES (1,'Al-Rwfaa Trading and Contracting W.L.L.',100000)`);
  await db.query(`INSERT INTO fiscal_year (code,starts_on,ends_on) VALUES ('FY2026','2026-01-01','2026-12-31')`);
  await db.query(`INSERT INTO fiscal_period (fiscal_year_id,period_no,starts_on,ends_on)
    SELECT 1,m,make_date(2026,m,1),(make_date(2026,m,1)+interval '1 month -1 day')::date FROM generate_series(1,12) m`);
  await req('POST', '/api/auth/login', { email: 'fin@x.qa', password: 'correct-horse-battery' }, 'fin');
  await req('POST', '/api/auth/login', { email: 'acct@x.qa', password: 'correct-horse-battery' }, 'acct');
  const client = (await req('POST', '/api/parties', {
    code: 'C001', kind: 'CUSTOMER', name: 'Msheireb Properties', terms_days: 45 })).body;
  const sub = (await req('POST', '/api/parties', {
    code: 'S001', kind: 'SUPPLIER', name: 'Bin Omran MEP', terms_days: 60 })).body;
  const supplier = (await req('POST', '/api/parties', {
    code: 'S002', kind: 'SUPPLIER', name: 'Qatar Steel Supplies', terms_days: 30 })).body;
  ok('client, subcontractor, supplier');

  /* ---------------- 1. ESTIMATE ---------------- */
  console.log('\n=== 1. price the job ===');
  let r = await req('POST', '/api/estimates', {
    title: 'Msheireb Retail Block C — MEP fit-out',
    clientId: client.id, estimateDate: '2026-01-08',
    overheadPct: 8, profitPct: 12, contingencyPct: 2,
    durationDays: 210, retentionPct: 10, advancePct: 10,
    lines: [
      { section: 'Electrical', code: 'E-100', description: 'LV distribution boards',
        unit: 'NOS', quantity: 12, materialRate: 6400, labourRate: 900, otherRate: 150 },
      { section: 'Electrical', code: 'E-200', description: 'Containment and cabling',
        unit: 'MTR', quantity: 4200, materialRate: 31.5, labourRate: 9.25 },
      { section: 'HVAC', code: 'H-100', description: 'Ductwork supply and install',
        unit: 'M2', quantity: 1800, subcontractRate: 210 },
      { section: 'HVAC', code: 'H-200', description: 'Chilled water pipework',
        unit: 'MTR', quantity: 950, materialRate: 88, labourRate: 34, plantRate: 6 },
      { section: 'Plumbing', code: 'P-100', description: 'Sanitary fit-out',
        unit: 'NOS', quantity: 46, materialRate: 1250, labourRate: 380 }
    ]});
  const est = r.body;
  checkR(r.status === 201, 'estimate created', r, est.ref);
  check(est.line_count === '5' || n(est.line_count) === 5, 'five priced lines', String(est.line_count));

  //   E-100  12 x 7,450.00  =  89,400     E-200  4,200 x 40.75 = 171,150
  //   H-100  1,800 x 210    = 378,000     H-200    950 x 128   = 121,600
  //   P-100     46 x 1,630  =  74,980                    total = 835,130
  check(n(est.cost_total) === 835130, 'cost build-up totals correctly', money(est.cost_total));
  ok('by category', `material ${money(est.material_total)}, labour ${money(est.labour_total)}, ` +
     `plant ${money(est.plant_total)}, subcontract ${money(est.subcontract_total)}`);
  // 835,130 x 1.02 contingency x 1.08 overhead x 1.12 profit = 1,030,376.71
  check(Math.abs(n(est.sell_total) - 1030376.71) < 1, 'price after contingency, overhead and profit',
    money(est.sell_total));
  ok('gross margin as a share of price', `${est.gross_margin_pct}%  (markups were 2 + 8 + 12 on cost)`);

  r = await req('POST', `/api/estimates/${est.id}/submit`, { submittedOn: '2026-01-12' });
  checkR(r.status === 200 && r.body.status === 'SUBMITTED', 'quoted to the client', r, r.body?.status);

  r = await req('PATCH', `/api/estimates/${est.id}`, { profitPct: 30 });
  checkR(r.status === 409, 'a submitted estimate cannot be quietly re-priced', r, r.body?.error);

  r = await req('GET', '/api/estimates/pipeline');
  check(n(r.body.liveValue) > 0, 'it shows in the live pipeline', money(r.body.liveValue));

  /* ---------------- 2. AWARD ---------------- */
  console.log('\n=== 2. win it, and the estimate becomes the budget ===');
  r = await req('POST', `/api/estimates/${est.id}/award`, { startsOn: '2026-02-01' }, 'acct');
  checkR(r.status === 403, 'an accountant cannot award a contract', r, r.body?.error);

  r = await req('POST', `/api/estimates/${est.id}/award`, {
    startsOn: '2026-02-01', manager: 'Eng. Rania Haddad', location: 'Msheireb Downtown' });
  const award = r.body;
  checkR(r.status === 201, 'awarded', r, `${award.projectCode} at ${money(award.contractValue)}`);
  check(n(award.costCodes) === 5, 'every priced line became a cost code', String(award.costCodes));
  check(n(award.budgetCost) === 835130, 'the budget is the estimated cost', money(award.budgetCost));

  const projectId = award.projectId;
  let codes = (await req('GET', `/api/projects/${projectId}/cost-codes`)).body;
  const e100 = codes.find(c => c.code === 'E-100');
  check(n(e100.budget_material) === 76800 && n(e100.budget_labour) === 10800,
    'budget carries the resource split, not just a total',
    `E-100 material ${money(e100.budget_material)}, labour ${money(e100.budget_labour)}`);

  r = await req('POST', `/api/estimates/${est.id}/award`, {});
  checkR(r.status === 409, 'it cannot be awarded twice', r, r.body?.error);

  /* ---------------- 3. COMMIT ---------------- */
  console.log('\n=== 3. order the subcontract ===');
  const h100 = codes.find(c => c.code === 'H-100');
  r = await req('POST', '/api/packages', {
    projectId, partyId: sub.id, title: 'Ductwork package',
    orderValue: '402000', retentionPct: 10, costCodeId: h100.id, awardedOn: '2026-02-15' });
  const pkg = r.body;
  checkR(r.status === 201, 'package awarded', r, `${pkg.ref} at ${money(pkg.order_value)}`);
  // priced at 1800 x 210 = 378,000 but ordered at 402,000
  check(n(pkg.order_value) > n(h100.budget_subcontract),
    'ordered ABOVE the price — the overrun exists from the day of the order',
    `budget ${money(h100.budget_subcontract)} vs order ${money(pkg.order_value)}`);

  let cvr = (await req('GET', `/api/projects/${projectId}/cvr`)).body;
  check(n(cvr.committed_cost) === 402000, 'committed cost appears before any invoice',
    money(cvr.committed_cost));
  check(n(cvr.actual_cost) === 0, 'with nothing yet spent', money(cvr.actual_cost));
  check(n(cvr.forecast_cost) > n(cvr.budget_cost),
    'and the forecast already shows the overrun',
    `budget ${money(cvr.budget_cost)} -> forecast ${money(cvr.forecast_cost)}`);

  /* ---------------- 4. SPEND ---------------- */
  console.log('\n=== 4. spend against the cost codes ===');
  const e200 = codes.find(c => c.code === 'E-200');
  r = await req('POST', '/api/purchase-invoices', {
    docType: 'PROJECT_COST', partyId: supplier.id, projectId, invoiceDate: '2026-03-10',
    supplierRef: 'QSS-4471',
    lines: [{ expenseAccount: '5210', description: 'Cable and containment', amount: '148000',
              costCodeId: e200.id }]});
  checkR(r.status === 201, 'material invoice charged to a cost code', r, money(r.body?.gross));

  r = await req('POST', '/api/purchase-invoices', {
    docType: 'SUBCONTRACT', partyId: sub.id, projectId, invoiceDate: '2026-04-20',
    grossAmount: '180000', retentionPct: 10, subcontractId: pkg.id, costCodeId: h100.id });
  checkR(r.status === 201, 'subcontract certificate against the package', r, money(r.body?.gross));

  r = await req('POST', '/api/purchase-invoices', {
    docType: 'SUBCONTRACT', partyId: sub.id, projectId, invoiceDate: '2026-05-20',
    grossAmount: '400000', retentionPct: 10, subcontractId: pkg.id, costCodeId: h100.id });
  checkR(r.status === 400 && /ordered at/.test(r.body.error || ''),
    'certifying beyond the order is refused', r, r.body?.error);

  const pkgNow = (await req('GET', `/api/packages?projectId=${projectId}`)).body[0];
  check(n(pkgNow.certified_to_date) === 180000 && n(pkgNow.uncertified_commitment) === 222000,
    'the package tracks certified against ordered',
    `${money(pkgNow.certified_to_date)} of ${money(pkgNow.order_value)} (${pkgNow.certified_pct}%)`);

  /* ---------------- 5. THE POSITION ---------------- */
  console.log('\n=== 5. where the job actually stands ===');
  codes = (await req('GET', `/api/projects/${projectId}/cost-codes`)).body;
  const over = codes.filter(c => n(c.forecast_cost) > n(c.budget_cost));
  ok('cost codes now reporting', `${codes.length} codes, ${over.length} forecast over budget`);
  for (const c of codes) {
    console.log(`      ${c.code.padEnd(6)} ${c.description.slice(0, 28).padEnd(30)}` +
      ` budget ${money(c.budget_cost).padStart(12)}` +
      ` actual ${money(c.actual_cost).padStart(12)}` +
      ` committed ${money(c.uncertified_commitment).padStart(11)}` +
      ` forecast ${money(c.forecast_cost).padStart(12)}`);
  }
  const e200now = codes.find(c => c.code === 'E-200');
  check(n(e200now.actual_cost) === 148000, 'material spend landed on E-200', money(e200now.actual_cost));
  check(n(e200now.actual_material) === 148000, 'and in the material column, matching how it was priced',
    money(e200now.actual_material));

  cvr = (await req('GET', `/api/projects/${projectId}/cvr`)).body;
  ok('project position',
    `contract ${money(cvr.revised_contract_value)} | budget ${money(cvr.budget_cost)} | ` +
    `actual ${money(cvr.actual_cost)} | committed ${money(cvr.committed_cost)} | forecast ${money(cvr.forecast_cost)}`);
  ok('margin', `as priced ${money(cvr.margin_as_priced)} -> forecast ${money(cvr.margin_forecast)} ` +
     `(overrun ${money(cvr.forecast_overrun)})`);
  check(n(cvr.margin_forecast) < n(cvr.margin_as_priced),
    'the forecast margin is below the priced margin, and says so before the job ends');

  /* ---------------- 6. VARIATION ---------------- */
  console.log('\n=== 6. a variation moves price, budget and time together ===');
  r = await req('POST', '/api/variations', {
    projectId, title: 'Additional 4 distribution boards to Block C2',
    sellValue: '52000', costValue: '38000', daysClaimed: 21, submit: true });
  const vo = r.body;
  checkR(r.status === 201, 'variation raised', r, vo.ref);

  const before = (await req('GET', `/api/projects/${projectId}/cvr`)).body;
  const schedBefore = (await req('GET', '/api/reports/schedule')).body.find(p => p.id === projectId);

  r = await req('POST', `/api/variations/${vo.id}/approve`, { approvedBy: 'Client PM' });
  checkR(r.status === 200, 'approved', r);
  const after = r.body.project;
  check(n(after.revised_contract_value) - n(before.revised_contract_value) === 52000,
    'contract value rose by the variation', money(after.revised_contract_value));
  check(n(after.budget_cost) - n(before.budget_cost) === 38000,
    'and so did the budget, so the forecast is not flattered', money(after.budget_cost));

  const schedAfter = (await req('GET', '/api/reports/schedule')).body.find(p => p.id === projectId);
  check(n(schedAfter.slip_days) - n(schedBefore.slip_days) === 21,
    'the extension of time was logged against the baseline',
    `${schedBefore.slip_days} -> ${schedAfter.slip_days} days`);
  const revs = (await req('GET', `/api/projects/${projectId}/revisions`)).body;
  check(revs.length === 1 && /VO-/.test(revs[0].reason),
    'with the variation named as the reason', revs[0]?.reason);

  /* ---------------- 7. PIPELINE ---------------- */
  console.log('\n=== 7. tender pipeline ===');
  await req('POST', '/api/estimates', { title: 'Lusail villas — lost bid', clientId: client.id,
    lines: [{ description: 'Enabling works', quantity: 1, materialRate: 200000 }] })
    .then(x => req('POST', `/api/estimates/${x.body.id}/submit`, {})
      .then(() => req('POST', `/api/estimates/${x.body.id}/lost`, { reason: 'Price — 9% above winner' })));
  const pipe = (await req('GET', '/api/estimates/pipeline')).body;
  check(pipe.winRateByCount === 50, 'win rate by count', `${pipe.winRateByCount}%`);
  ok('won and lost value', `won ${money(pipe.wonValue)}, lost ${money(pipe.lostValue)}`);

  /* ---------------- 8. THE BOOKS ---------------- */
  console.log('\n=== 8. the books still stand up ===');
  const h = (await req('GET', '/api/reports/health')).body;
  check(h.ok, 'ledger health', JSON.stringify(h));
  const tb = (await req('GET', '/api/reports/trial-balance')).body;
  check(tb.balanced, 'trial balance balances', `Dr ${money(tb.totals.debit)}`);

  server.close(); await db.pool.end();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
