'use strict';
/* ============================================================
   Posts a whole accounting month through the HTTP API against a
   real PostgreSQL server, then checks the books.

   Set DATABASE_URL and run: node test/api.test.js
   ============================================================ */
process.env.NODE_ENV = 'test';
const http = require('node:http');
const db = require('../src/db');
const auth = require('../src/auth');
const { buildApp } = require('../src/app');

let pass = 0, fail = 0;
const ok = (m, d) => { pass++; console.log('  \u2713 ' + m + (d ? '  \u2014 ' + d : '')); };
const bad = (m, d) => { fail++; console.log('  \u2717 ' + m + (d ? '  \u2014 ' + d : '')); };
const check = (cond, m, d) => (cond ? ok : bad)(m, d);
/* when an assertion about a response fails, show what the server said */
const checkR = (cond, m, r, d) => (cond ? ok : bad)(m, d || r?.body?.error || JSON.stringify(r?.body));

let base, cookie = {};
function req(method, path, body, who = 'fin') {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request(base + path, {
      method,
      headers: {
        'content-type': 'application/json',
        ...(cookie[who] ? { cookie: cookie[who] } : {}),
        ...(data ? { 'content-length': Buffer.byteLength(data) } : {})
      }
    }, res => {
      let buf = '';
      res.on('data', d => buf += d);
      res.on('end', () => {
        const set = res.headers['set-cookie'];
        if (set) cookie[who] = set.map(c => c.split(';')[0]).join('; ');
        let json = null; try { json = JSON.parse(buf); } catch { /* empty */ }
        resolve({ status: res.statusCode, body: json });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

(async () => {
  const server = http.createServer(buildApp());
  await new Promise(r => server.listen(0, r));
  base = `http://127.0.0.1:${server.address().port}`;

  /* ---------- fixtures ---------- */
  console.log('\n=== setup ===');
  await db.query(`TRUNCATE audit_log, session, cash_allocation, cash_document,
    sales_invoice_line, sales_invoice, purchase_invoice_line, purchase_invoice,
    payroll_line, payroll_run, depreciation_line, depreciation_run,
    stock_move, journal_line, journal_entry, project_revision,
    fixed_asset, item, project, employee, party, doc_sequence,
    fiscal_period, fiscal_year, company, app_user, role RESTART IDENTITY CASCADE`);

  const pw = await auth.hashPassword('correct-horse-battery');
  await db.query(`INSERT INTO role (code,name,can_post,can_approve,can_close_period,can_admin,approval_limit) VALUES
    ('FINMGR','Finance Manager',TRUE,TRUE,TRUE,TRUE,NULL),
    ('ACCT','Accountant',TRUE,FALSE,FALSE,FALSE,50000),
    ('ENGR','Project Engineer',FALSE,FALSE,FALSE,FALSE,0)`);
  await db.query(`INSERT INTO app_user (email,name,role_code,password_hash) VALUES
    ('fin@x.qa','Suresh Menon','FINMGR',$1),
    ('acct@x.qa','Priya Varghese','ACCT',$1),
    ('engr@x.qa','Yousef Baloch','ENGR',$1)`, [pw]);
  await db.query(`INSERT INTO company (id,name,name_ar,cr_no,payment_approval_limit)
    VALUES (1,'Al Rayyan Trading & Contracting W.L.L.','شركة الريان للتجارة والمقاولات','CR 84512',100000)`);
  await db.query(`INSERT INTO fiscal_year (code,starts_on,ends_on) VALUES ('FY2026','2026-01-01','2026-12-31')`);
  await db.query(`INSERT INTO fiscal_period (fiscal_year_id,period_no,starts_on,ends_on)
    SELECT 1,m,make_date(2026,m,1),(make_date(2026,m,1)+interval '1 month -1 day')::date FROM generate_series(1,12) m`);
  ok('roles, users, company, fiscal calendar');

  /* ---------- auth ---------- */
  console.log('\n=== authentication ===');
  let r = await req('POST', '/api/auth/login', { email: 'fin@x.qa', password: 'wrong' });
  checkR(r.status === 401, 'wrong password rejected', r);
  r = await req('POST', '/api/auth/login', { email: 'nobody@x.qa', password: 'whatever' });
  check(r.status === 401 && /do not match/.test(r.body.error),
    'unknown user gets the same message as a wrong password', r.body.error);
  r = await req('GET', '/api/accounts');
  check(r.status === 401, 'no session, no data');

  r = await req('POST', '/api/auth/login', { email: 'fin@x.qa', password: 'correct-horse-battery' }, 'fin');
  check(r.status === 200 && r.body.user.can_post, 'finance manager signed in', r.body.user?.role);
  await req('POST', '/api/auth/login', { email: 'acct@x.qa', password: 'correct-horse-battery' }, 'acct');
  await req('POST', '/api/auth/login', { email: 'engr@x.qa', password: 'correct-horse-battery' }, 'engr');
  ok('accountant and engineer signed in');

  r = await req('GET', '/api/users', null, 'acct');
  check(r.status === 403, 'accountant cannot list users', r.body?.error);

  /* ---------- master data ---------- */
  console.log('\n=== master data ===');
  const client = (await req('POST', '/api/parties', {
    code: 'C001', kind: 'CUSTOMER', name: 'Qatari Diar Real Estate',
    name_ar: 'قطري الديار', terms_days: 60 })).body;
  const sub = (await req('POST', '/api/parties', {
    code: 'S001', kind: 'SUPPLIER', name: 'Bin Omran MEP', terms_days: 60 })).body;
  const supplier = (await req('POST', '/api/parties', {
    code: 'S002', kind: 'SUPPLIER', name: 'Al Jaber Electrical', terms_days: 30 })).body;
  const project = (await req('POST', '/api/projects', {
    code: 'PRJ-2601', name: 'Lusail Marina Tower — MEP', client_id: client.id,
    starts_on: '2026-01-15', baseline_end_on: '2026-11-30', end_on: '2026-11-30',
    contract_value: '4200000', retention_pct: '10' })).body;
  const cable = (await req('POST', '/api/items', {
    code: 'CBL-4C16', name: 'Armoured Cable 4C x 16mm²', uom: 'MTR',
    inventory_account: '1140', sell_price: '38.50' })).body;
  await req('POST', '/api/employees', {
    code: 'E001', name: 'Mohammed Iqbal', joined_on: '2025-06-01',
    basic_salary: '4800', allowances: '2400', project_id: project.id });
  await req('POST', '/api/employees', {
    code: 'E002', name: 'Suresh Menon', joined_on: '2024-01-01',
    basic_salary: '9500', allowances: '3800' });
  await req('POST', '/api/assets', {
    tag: 'FA-0001', name: 'Toyota Hilux', category: 'Motor Vehicles',
    asset_account: '1250', accdep_account: '1251', acquired_on: '2026-01-10',
    in_service_on: '2026-01-10', cost: '96000', residual_value: '6000', life_months: 60 });
  ok('customer, subcontractor, supplier, project, item, 2 employees, 1 asset');

  r = await req('POST', '/api/parties', { code: 'X', kind: 'CUSTOMER', name: 'X' }, 'engr');
  check(r.status === 403, 'project engineer is read-only', r.body?.error);

  /* ---------- opening balances ---------- */
  console.log('\n=== opening balances ===');
  r = await req('POST', '/api/journal', {
    date: '2026-01-01', memo: 'Opening balances brought forward', source: 'Journal',
    lines: [
      { account: '1120', debit: '2800000' },
      { account: '1110', debit: '25000' },
      { account: '3100', credit: '2000000' },
      { account: '3300', credit: '825000' }
    ]});
  check(r.status === 201, 'opening balances posted', r.body?.entry_no || r.body?.error);

  r = await req('POST', '/api/journal', {
    date: '2026-02-01', memo: 'Out of balance', source: 'Journal',
    lines: [{ account: '1120', debit: '500' }, { account: '4100', credit: '400' }]});
  check(r.status === 400 && /out by 100/.test(r.body.error),
    'unbalanced entry refused with a readable message', r.body.error);

  /* ---------- goods in, then a trading sale ---------- */
  console.log('\n=== inventory and trading ===');
  r = await req('POST', '/api/purchase-invoices', {
    docType: 'STOCK', partyId: supplier.id, invoiceDate: '2026-02-06', supplierRef: 'AJ-8842',
    lines: [{ itemId: cable.id, quantity: '4200', unitCost: '29.4' }]});
  checkR(r.status === 201 && r.body.gross === '123480.00', 'goods received, 4200m @ 29.40', r, r.body?.gross);

  r = await req('POST', '/api/purchase-invoices', {
    docType: 'STOCK', partyId: supplier.id, invoiceDate: '2026-03-06',
    lines: [{ itemId: cable.id, quantity: '2600', unitCost: '30.8' }]});
  ok('second receipt at a different price, 2600m @ 30.80');

  let stock = (await req('GET', '/api/stock')).body[0];
  check(stock.on_hand === '6800.000', 'stock on hand', stock.on_hand + ' ' + stock.uom);
  // (4200*29.40 + 2600*30.80) / 6800 = 29.935294...
  check(stock.avg_cost.startsWith('29.9352'), 'weighted average cost blended', stock.avg_cost);

  r = await req('POST', '/api/sales-invoices', {
    docType: 'TRADING', partyId: client.id, invoiceDate: '2026-03-11',
    lines: [{ itemId: cable.id, quantity: '850', unitPrice: '38.50' }]});
  const tradingInv = r.body;
  checkR(r.status === 201 && r.body.gross === '32725.00', 'trading invoice raised', r, r.body?.gross);
  stock = (await req('GET', '/api/stock')).body[0];
  check(stock.on_hand === '5950.000', 'stock relieved by the sale', stock.on_hand);

  /* ---------- advance, then a certificate that recovers it ---------- */
  console.log('\n=== advances and payment certificates ===');
  r = await req('POST', '/api/cash', {
    direction: 'IN', purpose: 'ADVANCE', docDate: '2026-01-18', partyId: client.id,
    projectId: project.id, cashAccount: '1120', amount: '420000',
    reference: 'APG-QNB-2601', narration: 'Advance against guarantee' });
  check(r.status === 201 && r.body.status === 'POSTED', 'client advance received', r.body.amount);

  r = await req('GET', '/api/advances');
  const adv = r.body.find(a => a.side === 'CUSTOMER');
  check(adv && adv.outstanding === '420000.00', 'advance shows as outstanding', adv?.outstanding);

  r = await req('POST', '/api/sales-invoices', {
    docType: 'CERTIFICATE', partyId: client.id, projectId: project.id,
    invoiceDate: '2026-03-25', grossAmount: '620000', retentionPct: '10',
    advanceRecovered: '142800', narration: 'IPC 1 — PRJ-2601' });
  const ipc = r.body;
  checkR(r.status === 201 && ipc.retention === '62000.00' && ipc.netReceivable === '415200.00',
    'certificate: 620,000 less 10% retention less advance', r, ipc.netReceivable && `net ${ipc.netReceivable}`);

  r = await req('POST', '/api/sales-invoices', {
    docType: 'CERTIFICATE', partyId: client.id, projectId: project.id,
    invoiceDate: '2026-04-25', grossAmount: '500000', retentionPct: '10',
    advanceRecovered: '999999' });
  check(r.status === 400 && /only 277,?200/.test(r.body.error.replace(/,/g, '')),
    'over-recovering the advance is refused', r.body.error);

  /* ---------- subcontractor with retention ---------- */
  r = await req('POST', '/api/purchase-invoices', {
    docType: 'SUBCONTRACT', partyId: sub.id, projectId: project.id,
    invoiceDate: '2026-04-20', grossAmount: '285000', retentionPct: '10' });
  checkR(r.status === 201 && r.body.retention === '28500.00' && r.body.netPayable === '256500.00',
    'subcontract certificate with retention held', r, r.body?.netPayable);

  /* ---------- collection ---------- */
  console.log('\n=== collections and maker/checker ===');
  r = await req('POST', '/api/cash', {
    direction: 'IN', purpose: 'SETTLEMENT', docDate: '2026-04-10', partyId: client.id,
    cashAccount: '1120', amount: '415200', method: 'Bank transfer',
    allocations: [{ salesInvoiceId: ipc.id, amount: '415200' }]});
  checkR(r.status === 201 && r.body.status === 'POSTED', 'certificate collected in full', r);

  r = await req('GET', '/api/sales-invoices?open=true');
  const stillOpen = r.body.map(i => i.doc_no);
  check(!stillOpen.includes(ipc.docNo) && stillOpen.includes(tradingInv.docNo),
    'settled invoice leaves the open list, unpaid one stays', stillOpen.join(', '));

  r = await req('POST', '/api/cash', {
    direction: 'IN', purpose: 'SETTLEMENT', docDate: '2026-04-11', partyId: client.id,
    cashAccount: '1120', amount: '50000',
    allocations: [{ salesInvoiceId: ipc.id, amount: '50000' }]});
  check(r.status === 400 && /overpay/.test(r.body.error), 'overpaying an invoice is refused', r.body.error);

  // a payment at or above the approval limit must wait for a second person
  r = await req('POST', '/api/cash', {
    direction: 'OUT', purpose: 'SETTLEMENT', docDate: '2026-05-15', partyId: sub.id,
    cashAccount: '1120', amount: '256500', method: 'Cheque' }, 'acct');
  const bigPayment = r.body;
  check(r.status === 201 && bigPayment.status === 'PENDING_APPROVAL',
    'payment over the limit is held for approval', bigPayment.message);

  r = await req('POST', `/api/cash/${bigPayment.id}/approve`, {}, 'acct');
  check(r.status === 403, 'the accountant cannot approve it', r.body?.error);

  r = await req('POST', `/api/cash/${bigPayment.id}/approve`, {}, 'fin');
  check(r.status === 200 && r.body.status === 'POSTED', 'a second person approves and it posts', r.body.docNo);

  /* ---------- payroll, gratuity, depreciation ---------- */
  console.log('\n=== monthly runs ===');
  r = await req('POST', '/api/payroll/run', { periodEnd: '2026-05-31' });
  check(r.status === 201 && r.body.gross === '20500.00', 'payroll posted', `${r.body.employees} staff, net ${r.body.netPayable}`);

  r = await req('POST', '/api/payroll/run', { periodEnd: '2026-05-20' });
  check(r.status === 409 || r.status === 400, 'payroll cannot run twice for a month', r.body?.error);

  r = await req('POST', '/api/payroll/gratuity', { periodEnd: '2026-05-31' });
  // Rounded PER EMPLOYEE, because the provision is tracked per person
  // and must be settleable individually at end of service:
  //   4800/30*21/12 = 280.00 ; 9500/30*21/12 = 554.17 ; total 834.17
  // Rounding the combined basic instead would give 834.16 and leave
  // the provision one fils short of the sum of its parts.
  checkR(r.status === 201 && r.body.amount === '834.17', 'gratuity accrued per employee at 21 days basic', r, r.body?.amount);

  r = await req('POST', '/api/depreciation/run', { runTo: '2026-05-31' });
  // (96000 - 6000) / 60 = 1500 a month, Jan..May = 5 months
  checkR(r.status === 201 && r.body.amount === '7500.00', 'depreciation, 5 months on the Hilux', r, r.body?.amount);

  r = await req('POST', '/api/depreciation/run', { runTo: '2026-05-31' });
  check(r.status !== 201, 'depreciation will not run twice to the same date', r.body?.error);

  /* ---------- posting preview ---------- */
  console.log('\n=== posting preview ===');
  const previewBody = {
    docType: 'CERTIFICATE', partyId: client.id, projectId: project.id,
    invoiceDate: '2026-05-25', grossAmount: '300000', retentionPct: '10', advanceRecovered: '50000' };
  const before = (await req('GET', '/api/journal')).body.length;
  r = await req('POST', '/api/sales-invoices/preview', previewBody);
  const pv = r.body;
  checkR(r.status === 200 && pv.lines?.length === 4, 'preview returns the journal it would post', r,
    pv.lines?.map(l => `${l.account_code} ${l.debit !== '0.00' ? 'Dr ' + l.debit : 'Cr ' + l.credit}`).join(', '));
  check(pv?.totals?.debit === '300000.00', 'preview balances', pv?.totals?.debit);
  const after = (await req('GET', '/api/journal')).body.length;
  check(before === after, 'preview posted nothing', `${before} entries before and after`);

  r = await req('POST', '/api/sales-invoices/preview',
    { ...previewBody, advanceRecovered: '999999' });
  check(r.status === 400 && /only/.test(r.body.error),
    'preview reports the same refusal the real posting would', r.body.error);

  /* ---------- project schedule ---------- */
  console.log('\n=== project schedule ===');
  r = await req('PATCH', `/api/projects/${project.id}`, { end_on: '2027-02-28' });
  check(r.status === 400 && /project_revision/.test(r.body.error),
    'the end date cannot be moved silently', r.body.error);

  r = await req('POST', `/api/projects/${project.id}/revise-end-date`, {
    toEndOn: '2027-02-28', reason: 'Client-approved extension of time',
    approvedBy: 'Nasser Al Rayyan', loggedOn: '2026-05-20' });
  check(r.status === 200 && String(r.body.slip_days) === '90',
    'extension logged, baseline untouched', `slip ${r.body.slip_days} days`);

  r = await req('PATCH', `/api/projects/${project.id}`, { baseline_end_on: '2027-01-01' });
  check(r.status === 400 && /baseline/.test(r.body.error), 'the baseline can never be changed', r.body.error);

  /* ---------- reversal ---------- */
  console.log('\n=== corrections ===');
  const je = (await req('GET', '/api/journal?source=Sales%20Invoice')).body[0];
  r = await req('POST', `/api/journal/${je.id}/reverse`, { date: '2026-05-31', reason: 'Certificate re-measured' });
  check(r.status === 200, 'entry reversed by a mirror posting', r.body?.entry_no);
  r = await req('POST', `/api/journal/${je.id}/reverse`, { date: '2026-05-31' });
  check(r.status === 400 || r.status === 409, 'it cannot be reversed twice', r.body?.error);

  /* ---------- period lock ---------- */
  console.log('\n=== period control ===');
  const periods = (await req('GET', '/api/periods')).body;
  const march = periods.find(p => p.period_no === 3);
  r = await req('POST', `/api/periods/${march.id}/status`, { status: 'LOCKED' }, 'acct');
  check(r.status === 403, 'the accountant cannot lock a period', r.body?.error);
  r = await req('POST', `/api/periods/${march.id}/status`, { status: 'LOCKED' }, 'fin');
  check(r.status === 200 && r.body.status === 'LOCKED', 'finance manager locks March');
  r = await req('POST', '/api/journal', {
    date: '2026-03-15', memo: 'Backdated into a locked month', source: 'Journal',
    lines: [{ account: '6900', debit: '100' }, { account: '1110', credit: '100' }]});
  check(r.status === 400 && /LOCKED/.test(r.body.error), 'backdating into a locked month is refused', r.body.error);

  /* ---------- the books ---------- */
  console.log('\n=== the books ===');
  const tb = (await req('GET', '/api/reports/trial-balance')).body;
  check(tb.balanced, 'trial balance balances', `Dr ${tb.totals.debit} / Cr ${tb.totals.credit}`);

  const pl = (await req('GET', '/api/reports/profit-and-loss?from=2026-01-01&to=2026-12-31')).body;
  ok('profit and loss', `revenue ${pl.totals.revenue}, gross ${pl.totals.grossProfit}, net ${pl.totals.netProfit}`);

  const bs = (await req('GET', '/api/reports/balance-sheet?asAt=2026-12-31')).body;
  check(bs.balanced, 'balance sheet balances',
    `assets ${bs.totals.assets} = liabilities ${bs.totals.liabilities} + equity ${bs.totals.equity}`);

  const h = (await req('GET', '/api/reports/health')).body;
  check(h.ok, 'ledger health check', JSON.stringify(h));

  const projRep = (await req('GET', '/api/reports/projects')).body[0];
  ok('project profitability', `certified ${projRep.certified}, cost ${projRep.cost}, margin ${projRep.margin}`);

  const audits = (await req('GET', '/api/audit')).body;
  check(audits.length > 20, 'audit trail recorded', `${audits.length} entries`);

  server.close();
  await db.pool.end();
  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
