const M = require('../src/money.js');
let p=0,f=0;
const eq=(got,want,label)=>{ if(String(got)===String(want)){p++;console.log('  ✓',label,'=',got);} else {f++;console.log('  ✗',label,'got',got,'want',want);} };

console.log('--- the float traps ---');
eq(M.format(M.parse('2.675')), '2.68', '2.675 rounds to 2.68 (Math.round gives 2.67)');
eq(M.format(M.parse('1.005')), '1.01', '1.005 rounds to 1.01');
eq(M.format(M.parse('0.1') + M.parse('0.2')), '0.30', '0.1 + 0.2');
eq(M.format(M.parse('-2.675')), '-2.68', 'negative rounds away from zero');
eq(M.format(M.parse('8.345')), '8.35', '8.345');

console.log('--- extension: qty x unit cost ---');
eq(M.format(M.extend('3', '38.50')), '115.50', '3 x 38.50');
eq(M.format(M.extend('1400', '13.2')), '18480.00', '1400 bags x 13.20');
eq(M.format(M.extend('0.333', '2650')), '882.45', '0.333 ton x 2650');
eq(M.format(M.extend('7', '29.4')), '205.80', '7m x 29.40');

console.log('--- retention and percentages ---');
eq(M.format(M.percent(M.parse('620000'), '10')), '62000.00', '10% retention on 620,000');
eq(M.format(M.percent(M.parse('88000'), '5')), '4400.00', '5% retention on 88,000');
eq(M.format(M.percent(M.parse('14000'), '70')), '9800.00', 'gratuity 21/30 days of basic');
eq(M.format(M.percent(M.parse('333.33'), '7.5')), '25.00', '7.5% of 333.33');

console.log('--- allocation always sums back to the total ---');
const parts = M.allocate(M.parse('100.00'), ['1','1','1']);
eq(parts.map(M.format).join(' + '), '33.34 + 33.33 + 33.33', '100 across three, remainder on the largest part');
eq(M.format(M.parse('7.5')), '7.50', 'format ignores a stray second argument from .map()');
eq(M.format(M.sum(parts)), '100.00', 'parts sum exactly to the total');
const p2 = M.allocate(M.parse('1000.00'), ['3','5','2']);
eq(M.format(M.sum(p2)), '1000.00', 'weighted allocation sums exactly');

console.log('--- big numbers stay exact ---');
eq(M.format(M.parse('4200000.55') + M.parse('0.45')), '4200001.00', 'contract value plus fils');
let acc = 0n; for (let i=0;i<10000;i++) acc += M.parse('0.01');
eq(M.format(acc), '100.00', '10,000 x 0.01 accumulated');

console.log(`\n${p} passed, ${f} failed`);
process.exit(f?1:0);
