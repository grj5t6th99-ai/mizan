#!/usr/bin/env bash
# ============================================================
# MIZAN ERP — nightly backup
#
# Produces one encrypted, compressed logical dump per run, keeps a
# grandfather-father-son ladder locally, and mirrors everything to
# object storage. Qatar's Commercial Companies Law requires books
# to be retained for 10 years, so yearly archives are never pruned
# by this script.
#
#   ./backup.sh              normal nightly run
#   ./backup.sh --tag close  label a run (e.g. before a period close)
#
# Exit codes: 0 ok, 1 config error, 2 dump failed, 3 upload failed,
#             4 verification failed.
# ============================================================
set -Eeuo pipefail

: "${DATABASE_URL:?DATABASE_URL is not set}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/mizan}"
AGE_RECIPIENTS="${AGE_RECIPIENTS:-}"          # age public key(s)
RCLONE_REMOTE="${RCLONE_REMOTE:-}"            # e.g. r2:mizan-backups
KEEP_DAILY="${KEEP_DAILY:-14}"
KEEP_WEEKLY="${KEEP_WEEKLY:-8}"
KEEP_MONTHLY="${KEEP_MONTHLY:-24}"
HEALTHCHECK_URL="${HEALTHCHECK_URL:-}"        # pinged only on success
TAG=""
[[ "${1:-}" == "--tag" ]] && TAG="-${2:?tag value missing}"

now=$(date -u +%Y%m%dT%H%M%SZ)
day=$(date -u +%Y-%m-%d)
dow=$(date -u +%u)      # 7 = Sunday
dom=$(date -u +%d)
doy=$(date -u +%j)

if [[ "$doy" == "001" ]]; then tier=yearly
elif [[ "$dom" == "01" ]]; then tier=monthly
elif [[ "$dow" == "7"  ]]; then tier=weekly
else tier=daily; fi

dest="$BACKUP_DIR/$tier"
mkdir -p "$dest"
base="mizan-$day-$now$TAG"
dump="$dest/$base.dump"

log()  { printf '%s  %s\n' "$(date -u +%H:%M:%S)" "$*"; }
fail() { log "FAILED: $*"; exit "${2:-2}"; }

# ---------- 1. dump ----------
# -Fc is the custom format: compressed, and pg_restore can read a
# single table out of it without unpacking the whole file.
log "Dumping to $dump"
pg_dump --dbname="$DATABASE_URL" --format=custom --compress=9 \
        --no-owner --no-privileges --file="$dump" \
  || fail "pg_dump returned non-zero" 2

size=$(stat -c%s "$dump")
[[ "$size" -gt 1024 ]] || fail "dump is only ${size} bytes; refusing to keep it" 2
log "Dump written, $(numfmt --to=iec "$size")"

# ---------- 2. verify the dump can actually be read ----------
# A dump that pg_restore cannot list is not a backup. This catches
# truncation and disk-full silently corrupting the file.
pg_restore --list "$dump" > /dev/null 2>&1 || fail "dump is unreadable by pg_restore" 4
tables=$(pg_restore --list "$dump" | grep -c 'TABLE DATA' || true)
[[ "$tables" -gt 10 ]] || fail "only $tables tables in the dump; expected the full schema" 4
log "Dump verified readable, $tables tables"

# ---------- 3. encrypt ----------
# Accounting data leaves the server encrypted. age keeps the private
# key off this machine, so a stolen backup is useless.
final="$dump"
if [[ -n "$AGE_RECIPIENTS" ]]; then
  age -r "$AGE_RECIPIENTS" -o "$dump.age" "$dump" || fail "encryption failed" 2
  shred -u "$dump" 2>/dev/null || rm -f "$dump"
  final="$dump.age"
  log "Encrypted to $(basename "$final")"
else
  log "WARNING: AGE_RECIPIENTS not set — this backup is NOT encrypted"
fi

sha256sum "$final" > "$final.sha256"

# ---------- 4. mirror offsite ----------
if [[ -n "$RCLONE_REMOTE" ]]; then
  rclone copy "$final" "$RCLONE_REMOTE/$tier/" --no-traverse \
    || fail "rclone upload failed" 3
  rclone copy "$final.sha256" "$RCLONE_REMOTE/$tier/" --no-traverse || true
  log "Uploaded to $RCLONE_REMOTE/$tier/"
else
  log "WARNING: RCLONE_REMOTE not set — this backup exists in ONE place only"
fi

# ---------- 5. retention ----------
# Yearly archives are deliberately never pruned: 10-year statutory
# retention. Delete those by hand, with the auditor's agreement.
prune() {
  local dir="$1" keep="$2"
  [[ -d "$dir" ]] || return 0
  local n; n=$(find "$dir" -name 'mizan-*' -type f ! -name '*.sha256' | wc -l)
  if (( n > keep )); then
    find "$dir" -name 'mizan-*' -type f ! -name '*.sha256' -printf '%T@ %p\n' \
      | sort -n | head -n $(( n - keep )) | cut -d' ' -f2- \
      | while read -r f; do rm -f "$f" "$f.sha256"; log "Pruned $(basename "$f")"; done
  fi
}
prune "$BACKUP_DIR/daily"   "$KEEP_DAILY"
prune "$BACKUP_DIR/weekly"  "$KEEP_WEEKLY"
prune "$BACKUP_DIR/monthly" "$KEEP_MONTHLY"

if [[ -n "$RCLONE_REMOTE" ]]; then
  rclone delete "$RCLONE_REMOTE/daily"   --min-age "$(( KEEP_DAILY   * 24 ))h" 2>/dev/null || true
  rclone delete "$RCLONE_REMOTE/weekly"  --min-age "$(( KEEP_WEEKLY  * 7 * 24 ))h" 2>/dev/null || true
  rclone delete "$RCLONE_REMOTE/monthly" --min-age "$(( KEEP_MONTHLY * 31 * 24 ))h" 2>/dev/null || true
fi

log "Backup complete: $tier/$(basename "$final")"
[[ -n "$HEALTHCHECK_URL" ]] && curl -fsS -m 10 "$HEALTHCHECK_URL" > /dev/null || true
exit 0
