#!/usr/bin/env bash
# ============================================================
# MIZAN ERP — restore verification
#
# An untested backup is not a backup. This restores the most recent
# backup into a throwaway database and then asks the restored copy
# the only questions that matter:
#
#   does the trial balance still net to zero?
#   is every entry still balanced?
#   is the journal the size we expect?
#
# A backup that restores but produces books that do not balance is a
# failure, and this script treats it as one.
#
# Run it nightly, an hour after backup.sh. If it ever fails, the
# backups have been worthless since the last time it passed.
# ============================================================
set -Eeuo pipefail

: "${DATABASE_URL:?DATABASE_URL is not set}"
BACKUP_DIR="${BACKUP_DIR:-/var/backups/mizan}"
AGE_KEY_FILE="${AGE_KEY_FILE:-}"
SCRATCH_DB="${SCRATCH_DB:-mizan_restore_test}"
HEALTHCHECK_URL="${HEALTHCHECK_URL:-}"

log()  { printf '%s  %s\n' "$(date -u +%H:%M:%S)" "$*"; }
fail() { log "RESTORE TEST FAILED: $*"; exit 1; }

# Swap the database name in a connection URL, keeping any query
# string intact. Naive ${url%/*} surgery silently drops
# ?host=...&port=... and sends you to the wrong server.
swap_db() {
  local u="$1" db="$2" q=""
  if [[ "$u" == *\?* ]]; then q="?${u#*\?}"; u="${u%%\?*}"; fi
  printf '%s/%s%s' "${u%/*}" "$db" "$q"
}
ADMIN_URL="${ADMIN_URL:-$(swap_db "$DATABASE_URL" postgres)}"

# ---------- find the newest backup anywhere in the ladder ----------
latest=$(find "$BACKUP_DIR" -name 'mizan-*' -type f ! -name '*.sha256' \
         -printf '%T@ %p\n' | sort -rn | head -1 | cut -d' ' -f2-)
[[ -n "$latest" ]] || fail "no backup files found under $BACKUP_DIR"
age_hrs=$(( ( $(date +%s) - $(stat -c %Y "$latest") ) / 3600 ))
log "Testing $(basename "$latest")  (${age_hrs}h old)"
(( age_hrs < 36 )) || fail "newest backup is ${age_hrs}h old — the nightly job is not running"

# ---------- checksum ----------
if [[ -f "$latest.sha256" ]]; then
  (cd "$(dirname "$latest")" && sha256sum -c "$(basename "$latest").sha256" >/dev/null) \
    || fail "checksum mismatch — the file is corrupt"
  log "Checksum OK"
fi

# ---------- decrypt ----------
work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
dump="$work/restore.dump"
if [[ "$latest" == *.age ]]; then
  [[ -n "$AGE_KEY_FILE" ]] || fail "backup is encrypted but AGE_KEY_FILE is not set"
  age -d -i "$AGE_KEY_FILE" -o "$dump" "$latest" || fail "decryption failed"
  log "Decrypted"
else
  cp "$latest" "$dump"
fi

# ---------- restore into a scratch database ----------
psql "$ADMIN_URL" -v ON_ERROR_STOP=1 -qc "DROP DATABASE IF EXISTS $SCRATCH_DB;" >/dev/null
psql "$ADMIN_URL" -v ON_ERROR_STOP=1 -qc "CREATE DATABASE $SCRATCH_DB;"        >/dev/null
target=$(swap_db "$ADMIN_URL" "$SCRATCH_DB")

# --exit-on-error so a partial restore is a failure, not a warning.
# Keep pg_restore's own message: "it failed" with no reason wastes
# the hour you most need back.
if ! err=$(pg_restore --dbname="$target" --no-owner --no-privileges \
                      --exit-on-error "$dump" 2>&1); then
  log "pg_restore said:"; printf '%s\n' "$err" | head -15
  fail "pg_restore could not rebuild the database"
fi
log "Restored into $SCRATCH_DB"

q() { psql "$target" -tAc "$1"; }

# ---------- the questions that actually matter ----------
net=$(q "SELECT COALESCE(SUM(debit - credit),0) FROM journal_line")
[[ "$(echo "$net" | tr -d '0.-')" == "" ]] || fail "restored trial balance does not net to zero: $net"
log "Trial balance nets to zero"

unbal=$(q "SELECT COUNT(*) FROM (SELECT entry_id FROM journal_line
           GROUP BY entry_id HAVING SUM(debit) <> SUM(credit)) x")
[[ "$unbal" == "0" ]] || fail "$unbal unbalanced entries in the restored copy"
log "No unbalanced entries"

single=$(q "SELECT COUNT(*) FROM (SELECT entry_id FROM journal_line
            GROUP BY entry_id HAVING COUNT(*) < 2) y")
[[ "$single" == "0" ]] || fail "$single single-line entries in the restored copy"
log "No single-line entries"

# ---------- did we restore everything, or a stale subset? ----------
live_entries=$(psql "$DATABASE_URL" -tAc "SELECT COUNT(*) FROM journal_entry")
rest_entries=$(q "SELECT COUNT(*) FROM journal_entry")
log "Journal entries: live $live_entries, restored $rest_entries"
(( rest_entries > 0 )) || fail "restored journal is empty"
# The backup is older than live, so restored <= live is expected;
# restored materially ahead of live means we restored the wrong database.
(( rest_entries <= live_entries )) || fail "restored copy has MORE entries than live — wrong database?"

for t in account journal_entry journal_line party project fiscal_period; do
  c=$(q "SELECT COUNT(*) FROM $t")
  (( c > 0 )) || fail "table $t is empty in the restored copy"
done
log "All core tables present and populated"

acc=$(q "SELECT COUNT(*) FROM account")
log "Chart of accounts: $acc accounts"

psql "$ADMIN_URL" -qc "DROP DATABASE $SCRATCH_DB;" >/dev/null
log "PASS — $(basename "$latest") is a restorable, self-consistent copy of the books"
[[ -n "$HEALTHCHECK_URL" ]] && curl -fsS -m 10 "$HEALTHCHECK_URL" > /dev/null || true
exit 0
