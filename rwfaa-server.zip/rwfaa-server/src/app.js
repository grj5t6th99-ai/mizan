'use strict';
const path = require('node:path');
const express = require('express');
const cookieParser = require('cookie-parser');
const db = require('./db');
const auth = require('./auth');
const L = require('./ledger');
const D = require('./services/documents');
const O = require('./services/operations');
const R = require('./services/reports');
const C = require('./services/contracting');

const { badRequest, notFound } = db;
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function buildApp() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser());

  const api = express.Router();

  /* ---------- health ---------- */
  api.get('/health', wrap(async (_req, res) => {
    await db.query('SELECT 1');
    res.json({ ok: true });
  }));

  /* ---------- session ---------- */
  api.post('/auth/login', wrap(async (req, res) => {
    const { email, password } = req.body || {};
    if (!email || !password) throw badRequest('Enter your email address and password.');
    const out = await auth.login(email, password, { ip: req.ip, userAgent: req.get('user-agent') });
    res.cookie(auth.COOKIE, out.sessionId, auth.cookieOptions());
    res.json({ user: out.user });
  }));

  api.use(auth.attachUser);

  api.post('/auth/logout', wrap(async (req, res) => {
    await auth.logout(req.cookies?.[auth.COOKIE], req.user);
    res.clearCookie(auth.COOKIE, { path: '/' });
    res.json({ ok: true });
  }));

  api.get('/auth/me', auth.requireUser, (req, res) => res.json({ user: req.user }));

  api.post('/auth/password', auth.requireUser, wrap(async (req, res) => {
    const { currentPassword, newPassword } = req.body || {};
    const row = await db.one('SELECT password_hash FROM app_user WHERE id=$1', [req.user.id]);
    if (!await auth.verifyPassword(currentPassword || '', row.password_hash)) {
      throw badRequest('Your current password is not correct.');
    }
    await db.query('UPDATE app_user SET password_hash=$1, must_change_password=FALSE WHERE id=$2',
      [await auth.hashPassword(newPassword), req.user.id]);
    await db.query('DELETE FROM session WHERE user_id=$1 AND id <> $2', [req.user.id, req.user.sessionId]);
    res.json({ ok: true });
  }));

  api.use(auth.requireUser);

  /* ---------- reference data ---------- */
  api.get('/company', wrap(async (_q, res) => res.json(await db.one('SELECT * FROM company WHERE id=1'))));
  api.get('/accounts', wrap(async (_q, res) =>
    res.json(await db.many('SELECT * FROM account ORDER BY code'))));
  api.get('/accounts/:code/ledger', wrap(async (req, res) =>
    res.json(await L.ledgerRows(db.pool, req.params.code, req.query))));
  api.get('/periods', wrap(async (_q, res) => res.json(await db.many(
    `SELECT p.*, y.code AS year_code, y.status AS year_status
       FROM fiscal_period p JOIN fiscal_year y ON y.id=p.fiscal_year_id
      ORDER BY p.starts_on`))));

  /* ---------- master data ---------- */
  const crud = (path, table, cols, orderBy = 'id') => {
    api.get(`/${path}`, wrap(async (req, res) => {
      const where = req.query.q ? `WHERE name ILIKE $1 OR code ILIKE $1` : '';
      res.json(await db.many(
        `SELECT * FROM ${table} ${where} ORDER BY ${orderBy}`,
        req.query.q ? [`%${req.query.q}%`] : []));
    }));
    api.get(`/${path}/:id`, wrap(async (req, res) => {
      const row = await db.one(`SELECT * FROM ${table} WHERE id=$1`, [req.params.id]);
      if (!row) throw notFound();
      res.json(row);
    }));
    api.post(`/${path}`, auth.requirePost, wrap(async (req, res) => {
      const keys = cols.filter(c => req.body[c] !== undefined);
      if (!keys.length) throw badRequest('Nothing to save.');
      const row = await db.tx(async c => {
        const { rows } = await c.query(
          `INSERT INTO ${table} (${keys.join(',')})
           VALUES (${keys.map((_, i) => '$' + (i + 1)).join(',')}) RETURNING *`,
          keys.map(k => req.body[k]));
        await L.audit(c, req.user, 'CREATE', table, rows[0].id, req.body);
        return rows[0];
      });
      res.status(201).json(row);
    }));
    api.patch(`/${path}/:id`, auth.requirePost, wrap(async (req, res) => {
      const keys = cols.filter(c => req.body[c] !== undefined);
      if (!keys.length) throw badRequest('Nothing to change.');
      const row = await db.tx(async c => {
        const { rows } = await c.query(
          `UPDATE ${table} SET ${keys.map((k, i) => `${k}=$${i + 2}`).join(',')}
            WHERE id=$1 RETURNING *`, [req.params.id, ...keys.map(k => req.body[k])]);
        if (!rows[0]) throw notFound();
        await L.audit(c, req.user, 'UPDATE', table, req.params.id, req.body);
        return rows[0];
      });
      res.json(row);
    }));
  };

  crud('parties', 'party',
    ['code', 'kind', 'name', 'name_ar', 'cr_no', 'tax_no', 'contact_person', 'phone', 'email',
     'address', 'terms_days', 'credit_limit', 'is_active'], 'code');
  crud('employees', 'employee',
    ['code', 'name', 'name_ar', 'qid', 'position', 'department', 'joined_on', 'left_on',
     'basic_salary', 'allowances', 'bank_name', 'iban', 'project_id', 'is_active'], 'code');
  crud('items', 'item',
    ['code', 'name', 'name_ar', 'category', 'uom', 'inventory_account', 'reorder_level',
     'sell_price', 'is_active'], 'code');
  crud('projects', 'project',
    ['code', 'name', 'name_ar', 'client_id', 'starts_on', 'baseline_end_on', 'end_on',
     'contract_value', 'retention_pct', 'advance_pct', 'manager', 'location', 'scope', 'status'], 'code');
  crud('assets', 'fixed_asset',
    ['tag', 'name', 'name_ar', 'category', 'asset_account', 'accdep_account', 'serial_no',
     'acquired_on', 'in_service_on', 'cost', 'residual_value', 'life_months', 'custodian',
     'project_id', 'status'], 'tag');

  /* ---------- posting preview ----------
     Every "what will this post?" answer comes from running the real
     service inside a transaction that is then rolled back. There is
     no second implementation to fall out of step. */
  const preview = (path, run) =>
    api.post(`/${path}/preview`, auth.requirePost, wrap(async (req, res) => {
      const out = await db.dryRun(async c => {
        const result = await run(c, req.user, req.body);
        const codes = [...new Set(result.lines.map(l => l.account_code))];
        const { rows } = await c.query(
          'SELECT code, name, name_ar FROM account WHERE code = ANY($1)', [codes]);
        const byCode = Object.fromEntries(rows.map(a => [a.code, a]));
        return {
          date: result.entry_date, memo: result.memo,
          lines: result.lines.map(l => ({
            ...l, account_name: byCode[l.account_code]?.name,
            account_name_ar: byCode[l.account_code]?.name_ar
          })),
          totals: { debit: result.amount, credit: result.amount },
          balanced: true
        };
      });
      res.json(out);
    }));

  const withEntry = fn => async (c, user, body) => {
    const out = await fn(c, user, body);
    // documents return their own shape; fetch the entry we just made
    if (out.lines) return out;
    const id = out.entryId || out.entry_id;
    const { rows } = await c.query('SELECT * FROM journal_entry WHERE id=$1', [id]);
    const { rows: ls } = await c.query(
      'SELECT * FROM journal_line WHERE entry_id=$1 ORDER BY line_no', [id]);
    return { ...rows[0], amount: out.gross || out.amount || out.netPayable,
             lines: ls, memo: rows[0].memo, entry_date: rows[0].entry_date };
  };

  preview('sales-invoices', withEntry(D.postSalesInvoice));
  preview('purchase-invoices', withEntry(D.postPurchaseInvoice));
  preview('cash', withEntry(D.postCashDocument));
  preview('journal', (c, u, b) => L.post(c, u, b));
  preview('payroll/run', withEntry(O.runPayroll));
  preview('payroll/gratuity', withEntry(O.accrueGratuity));
  preview('depreciation/run', withEntry(O.runDepreciation));

  /* ---------- documents ---------- */
  api.post('/sales-invoices', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => D.postSalesInvoice(c, req.user, req.body)))));
  api.get('/sales-invoices', wrap(async (req, res) => res.json(await db.many(
    `SELECT * FROM v_open_sales_invoice
      WHERE ($1::bigint IS NULL OR party_id=$1)
        AND ($2::boolean IS NOT TRUE OR outstanding > 0)
      ORDER BY invoice_date DESC, id DESC LIMIT 500`,
    [req.query.partyId || null, req.query.open === 'true']))));

  api.post('/purchase-invoices', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => D.postPurchaseInvoice(c, req.user, req.body)))));
  api.get('/purchase-invoices', wrap(async (req, res) => res.json(await db.many(
    `SELECT * FROM v_open_purchase_invoice
      WHERE ($1::bigint IS NULL OR party_id=$1)
        AND ($2::boolean IS NOT TRUE OR outstanding > 0)
      ORDER BY invoice_date DESC, id DESC LIMIT 500`,
    [req.query.partyId || null, req.query.open === 'true']))));

  api.post('/cash', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => D.postCashDocument(c, req.user, req.body)))));
  api.get('/cash/pending', wrap(async (_q, res) => res.json(await db.many(
    `SELECT c.*, u.name AS raised_by FROM cash_document c
       LEFT JOIN app_user u ON u.id = c.created_by
      WHERE c.status='PENDING_APPROVAL' ORDER BY c.doc_date`))));
  api.post('/cash/:id/approve', auth.requireApprove, wrap(async (req, res) =>
    res.json(await db.tx(c => D.approveCashDocument(c, req.user, req.params.id)))));

  api.get('/advances', wrap(async (_q, res) => res.json(await db.many(
    `SELECT v.*, p.name AS party_name, pr.code AS project_code
       FROM v_advance_position v
       LEFT JOIN party p ON p.id = v.party_id
       LEFT JOIN project pr ON pr.id = v.project_id
      WHERE v.outstanding <> 0 ORDER BY v.side, v.outstanding DESC`))));

  /* ---------- journal ---------- */
  api.post('/journal', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => L.post(c, req.user, req.body)))));
  api.get('/journal', wrap(async (req, res) => res.json(await db.many(
    `SELECT * FROM v_journal
      WHERE ($1::date IS NULL OR entry_date >= $1)
        AND ($2::date IS NULL OR entry_date <= $2)
        AND ($3::text IS NULL OR source = $3)
      ORDER BY entry_date DESC, id DESC LIMIT 500`,
    [req.query.from || null, req.query.to || null, req.query.source || null]))));
  api.get('/journal/:id', wrap(async (req, res) => {
    const head = await db.one('SELECT * FROM v_journal WHERE id=$1', [req.params.id]);
    if (!head) throw notFound();
    head.lines = await db.many('SELECT * FROM v_ledger WHERE entry_id=$1 ORDER BY line_no', [req.params.id]);
    res.json(head);
  }));
  api.post('/journal/:id/reverse', auth.requirePost, wrap(async (req, res) =>
    res.json(await db.tx(c => L.reverse(c, req.user, req.params.id, req.body)))));

  /* ---------- operations ---------- */
  api.post('/payroll/run', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => O.runPayroll(c, req.user, req.body)))));
  api.post('/payroll/gratuity', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => O.accrueGratuity(c, req.user, req.body)))));
  api.post('/depreciation/run', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => O.runDepreciation(c, req.user, req.body)))));
  api.post('/projects/:id/revise-end-date', auth.requirePost, wrap(async (req, res) =>
    res.json(await db.tx(c => O.reviseProjectEndDate(c, req.user, req.params.id, req.body)))));
  api.get('/projects/:id/revisions', wrap(async (req, res) => res.json(await db.many(
    'SELECT * FROM project_revision WHERE project_id=$1 ORDER BY logged_on DESC, id DESC',
    [req.params.id]))));
  api.post('/periods/:id/status', wrap(async (req, res) =>
    res.json(await db.tx(c => O.lockPeriod(c, req.user, req.params.id, req.body.status)))));
  api.post('/fiscal-years/:id/close', wrap(async (req, res) =>
    res.json(await db.tx(c => O.closeYear(c, req.user, req.params.id)))));

  /* ---------- estimating and contracting ---------- */
  api.get('/estimates', wrap(async (req, res) => res.json(await db.many(
    `SELECT * FROM v_estimate
      WHERE ($1::text IS NULL OR status = $1::estimate_status)
      ORDER BY estimate_date DESC, id DESC LIMIT 300`, [req.query.status || null]))));
  api.get('/estimates/pipeline', wrap(async (_q, res) => res.json(await C.pipeline(db.pool))));
  api.get('/estimates/:id', wrap(async (req, res) =>
    res.json(await C.readEstimate(db.pool, req.params.id))));
  api.post('/estimates', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => C.createEstimate(c, req.user, req.body)))));
  api.patch('/estimates/:id', auth.requirePost, wrap(async (req, res) =>
    res.json(await db.tx(c => C.updateEstimate(c, req.user, req.params.id, req.body)))));
  api.post('/estimates/:id/submit', auth.requirePost, wrap(async (req, res) =>
    res.json(await db.tx(c => C.submitEstimate(c, req.user, req.params.id, req.body)))));
  api.post('/estimates/:id/revise', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => C.reviseEstimate(c, req.user, req.params.id, req.body)))));
  api.post('/estimates/:id/lost', auth.requirePost, wrap(async (req, res) =>
    res.json(await db.tx(c => C.markLost(c, req.user, req.params.id, req.body)))));
  api.post('/estimates/:id/award', auth.requireApprove, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => C.awardEstimate(c, req.user, req.params.id, req.body)))));

  api.get('/projects/:id/cost-codes', wrap(async (req, res) =>
    res.json(await C.costCodes(db.pool, req.params.id))));
  api.get('/projects/:id/cvr', wrap(async (req, res) =>
    res.json(await C.cvr(db.pool, req.params.id))));
  api.get('/reports/cvr', wrap(async (_q, res) => res.json(await C.cvr(db.pool, null))));

  api.get('/variations', wrap(async (req, res) => res.json(await db.many(
    `SELECT v.*, p.code AS project_code FROM variation_order v
       JOIN project p ON p.id = v.project_id
      WHERE ($1::bigint IS NULL OR v.project_id = $1)
      ORDER BY v.id DESC`, [req.query.projectId || null]))));
  api.post('/variations', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => C.createVariation(c, req.user, req.body)))));
  api.post('/variations/:id/approve', auth.requireApprove, wrap(async (req, res) =>
    res.json(await db.tx(c => C.approveVariation(c, req.user, req.params.id, req.body)))));

  api.get('/packages', wrap(async (req, res) => res.json(await db.many(
    `SELECT * FROM v_subcontract_package
      WHERE ($1::bigint IS NULL OR project_id = $1) ORDER BY id DESC`,
    [req.query.projectId || null]))));
  api.post('/packages', auth.requirePost, wrap(async (req, res) =>
    res.status(201).json(await db.tx(c => C.createPackage(c, req.user, req.body)))));

  /* ---------- inventory ---------- */
  api.get('/stock', wrap(async (_q, res) =>
    res.json(await db.many('SELECT * FROM v_stock_on_hand ORDER BY code'))));
  api.get('/stock/:itemId/moves', wrap(async (req, res) => res.json(await db.many(
    'SELECT * FROM stock_move WHERE item_id=$1 ORDER BY moved_on DESC, id DESC LIMIT 500',
    [req.params.itemId]))));

  /* ---------- reports ---------- */
  api.get('/reports/trial-balance', wrap(async (req, res) => res.json(await R.trialBalance(db.pool, req.query))));
  api.get('/reports/profit-and-loss', wrap(async (req, res) => res.json(await R.profitAndLoss(db.pool, req.query))));
  api.get('/reports/balance-sheet', wrap(async (req, res) => res.json(await R.balanceSheet(db.pool, req.query))));
  api.get('/reports/ageing/:side', wrap(async (req, res) =>
    res.json(await R.ageing(db.pool, req.params.side.toUpperCase() === 'AP' ? 'AP' : 'AR'))));
  api.get('/reports/projects', wrap(async (_q, res) => res.json(await R.projectProfitability(db.pool))));
  api.get('/reports/schedule', wrap(async (_q, res) =>
    res.json(await db.many('SELECT * FROM v_project_schedule ORDER BY is_overdue DESC, days_over DESC'))));
  api.get('/reports/health', wrap(async (_q, res) => res.json(await R.health(db.pool))));

  /* ---------- admin ---------- */
  api.get('/users', auth.requireAdmin, wrap(async (_q, res) =>
    res.json(await db.many('SELECT * FROM v_user ORDER BY name'))));
  api.post('/users', auth.requireAdmin, wrap(async (req, res) => {
    const { email, name, name_ar, role_code, password } = req.body || {};
    if (!email || !name || !role_code) throw badRequest('Email, name and role are required.');
    const row = await db.tx(async c => {
      const { rows } = await c.query(
        `INSERT INTO app_user (email, name, name_ar, role_code, password_hash, must_change_password)
         VALUES ($1,$2,$3,$4,$5,TRUE) RETURNING id`,
        [email, name, name_ar || null, role_code, await auth.hashPassword(password)]);
      await L.audit(c, req.user, 'CREATE', 'app_user', rows[0].id, { email, role_code });
      return rows[0];
    });
    res.status(201).json(row);
  }));
  api.get('/audit', auth.requireAdmin, wrap(async (req, res) => res.json(await db.many(
    `SELECT * FROM audit_log
      WHERE ($1::text IS NULL OR entity=$1) ORDER BY at DESC LIMIT 300`,
    [req.query.entity || null]))));

  app.use('/api', api);

  /* ---------- the built frontend ----------
     Served by this process, from the same image, on the same origin.
     Sharing web/dist with the proxy through a named volume looked
     tidier but is a trap: Docker seeds a named volume from the image
     only the FIRST time, so every later deploy would keep serving the
     previous frontend against a new API. */
  const dist = path.join(__dirname, '..', 'web', 'dist');
  app.use(express.static(dist, {
    index: false,
    setHeaders(res, file) {
      // hashed asset filenames can be cached hard; index.html never
      res.setHeader('Cache-Control', /assets[/\\]/.test(file)
        ? 'public, max-age=31536000, immutable' : 'no-cache');
    }
  }));

  /* ---------- errors ---------- */
  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.', code: 'not_found' }));

  // Anything else is a client-side route: hand back the app shell.
  // Written as plain middleware rather than app.get('*') because the
  // wildcard path syntax changed between Express 4 and 5.
  app.use((req, res, next) => {
    if (req.method !== 'GET' && req.method !== 'HEAD') return next();
    // never cache the shell, or a deploy is invisible until users hard-refresh
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.join(dist, 'index.html'), err => err && next());
  });
  app.use((err, req, res, _next) => {
    const e = db.translate(err);
    const status = e.status || 500;
    if (status >= 500) console.error('[api]', req.method, req.path, err);
    res.status(status).json({
      error: status >= 500 ? 'Something went wrong on our side.' : e.message,
      code: e.code || 'server_error'
    });
  });

  return app;
}

module.exports = { buildApp };
