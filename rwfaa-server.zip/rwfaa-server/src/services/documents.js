'use strict';
const M = require('../money');
const L = require('../ledger');
const { badRequest, notFound, forbidden } = require('../db');

/* ============================================================
   Document services. Each one builds journal lines and hands them
   to the ledger. None of them writes a balance anywhere.
   ============================================================ */

const today = () => new Date().toISOString().slice(0, 10);
const addDays = (iso, n) => {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + Number(n || 0));
  return d.toISOString().slice(0, 10);
};

async function party(client, id, kind) {
  const { rows } = await client.query('SELECT * FROM party WHERE id = $1 AND is_active', [id]);
  const p = rows[0];
  if (!p) throw notFound('That account does not exist or is inactive.');
  if (kind && p.kind !== kind && p.kind !== 'BOTH') {
    throw badRequest(`${p.name} is not set up as a ${kind.toLowerCase()}.`);
  }
  return p;
}

/** How much of an advance is still outstanding for this party and project. */
async function advanceOutstanding(client, side, partyId, projectId) {
  const { rows } = await client.query(
    `SELECT COALESCE(SUM(outstanding),0) AS v FROM v_advance_position
      WHERE side = $1 AND party_id = $2
        AND (project_id IS NOT DISTINCT FROM $3)`,
    [side, partyId, projectId || null]);
  return M.parse(rows[0].v);
}

/* ==================== SALES ==================== */
/**
 * doc: { docType: TRADING|CERTIFICATE|SERVICE, partyId, projectId, invoiceDate,
 *        grossAmount | lines[], retentionPct, advanceRecovered, narration }
 */
async function postSalesInvoice(client, user, doc) {
  const p = await party(client, doc.partyId, 'CUSTOMER');
  const date = doc.invoiceDate || today();
  const dueDate = doc.dueDate || addDays(date, p.terms_days);

  const AR = await L.control(client, 'ar');
  const lines = [];
  let gross = 0n, retention = 0n;
  const advance = M.parse(doc.advanceRecovered || 0);

  if (doc.docType === 'CERTIFICATE') {
    if (!doc.projectId) throw badRequest('A payment certificate must name a contract.');
    gross = M.parse(doc.grossAmount);
    if (gross <= 0n) throw badRequest('Enter the value of work certified.');
    const pct = doc.retentionPct != null ? String(doc.retentionPct)
      : (await client.query('SELECT retention_pct FROM project WHERE id=$1', [doc.projectId])).rows[0]?.retention_pct || '0';
    retention = M.percent(gross, pct);
  } else {
    const rows = doc.lines || [];
    if (!rows.length) throw badRequest('Add at least one line.');
    for (const r of rows) r._total = M.extend(r.quantity ?? 1, r.unitPrice ?? 0);
    gross = M.sum(rows.map(r => r._total));
    if (gross <= 0n) throw badRequest('The invoice value is zero.');
  }

  // Never recover more advance than is actually held.
  if (advance > 0n) {
    const held = await advanceOutstanding(client, 'CUSTOMER', doc.partyId, doc.projectId);
    if (advance > held) {
      throw badRequest(
        `You are recovering ${M.format(advance)} of advance but only ${M.format(held)} is held from ${p.name} on this contract.`);
    }
  }
  if (retention + advance > gross) {
    throw badRequest('Retention plus advance recovery cannot exceed the gross value.');
  }

  const receivable = gross - retention - advance;
  lines.push({ account: AR, debit: receivable, partyId: p.id, projectId: doc.projectId, memo: 'Net receivable' });
  if (retention > 0n) {
    lines.push({ account: await L.control(client, 'retention_rec'), debit: retention,
                 partyId: p.id, projectId: doc.projectId, memo: 'Retention withheld by client' });
  }
  if (advance > 0n) {
    lines.push({ account: await L.control(client, 'cust_adv'), debit: advance,
                 partyId: p.id, projectId: doc.projectId, memo: 'Advance recovered' });
  }

  if (doc.docType === 'CERTIFICATE') {
    lines.push({ account: await L.control(client, 'sales_contract'), credit: gross,
                 projectId: doc.projectId, memo: 'Work certified' });
  } else if (doc.docType === 'SERVICE') {
    lines.push({ account: doc.revenueAccount || '4300', credit: gross,
                 projectId: doc.projectId, memo: 'Service income' });
  } else {
    lines.push({ account: await L.control(client, 'sales_trading'), credit: gross,
                 projectId: doc.projectId, memo: 'Trading sales' });
  }

  // Cost of sales, and relieve stock at weighted-average cost.
  const stockMoves = [];
  if (doc.docType === 'TRADING') {
    const byAccount = new Map();
    let cogsTotal = 0n;
    for (const r of doc.lines) {
      if (!r.itemId) continue;
      const { rows } = await client.query(
        `SELECT i.inventory_account, s.on_hand, s.avg_cost
           FROM item i JOIN v_stock_on_hand s ON s.id = i.id WHERE i.id = $1`, [r.itemId]);
      const it = rows[0];
      if (!it) throw notFound(`Item ${r.itemId} does not exist.`);
      const qty = String(r.quantity ?? 1);
      const cost = M.extend(qty, it.avg_cost);
      if (cost === 0n) continue;
      byAccount.set(it.inventory_account, (byAccount.get(it.inventory_account) || 0n) + cost);
      cogsTotal += cost;
      stockMoves.push({ itemId: r.itemId, qty: `-${qty}`, unitCost: it.avg_cost, value: cost });
    }
    if (cogsTotal > 0n) {
      lines.push({ account: await L.control(client, 'cogs'), debit: cogsTotal, projectId: doc.projectId, memo: 'Cost of goods sold' });
      for (const [acct, v] of byAccount) {
        lines.push({ account: acct, credit: v, memo: 'Stock relieved at average cost' });
      }
    }
  }

  const docNo = await L.nextDocNo(client, doc.docType === 'CERTIFICATE' ? 'IPC' : 'SI', date);
  const { rows: ins } = await client.query(
    // doc_no and entry_id are written by the UPDATE below, once the
    // entry has actually posted: the table constrains status='POSTED'
    // to mean both are present, so a half-made document cannot exist.
    `INSERT INTO sales_invoice
       (doc_type, status, invoice_date, due_date, party_id, project_id,
        gross_amount, retention_amount, advance_recovered, net_receivable, narration, created_by)
     VALUES ($1,'DRAFT',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
    [doc.docType, date, dueDate, p.id, doc.projectId || null,
     M.format(gross), M.format(retention), M.format(advance), M.format(receivable),
     doc.narration || null, user.id]);
  const invoiceId = ins[0].id;

  for (const [i, r] of (doc.lines || []).entries()) {
    await client.query(
      `INSERT INTO sales_invoice_line (invoice_id, line_no, item_id, description, quantity, unit_price, line_total)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [invoiceId, i + 1, r.itemId || null, r.description || null,
       String(r.quantity ?? 1), String(r.unitPrice ?? 0), M.format(r._total)]);
  }

  const entry = await L.post(client, user, {
    date, entryNo: docNo,
    memo: doc.narration || `${label(doc.docType)} — ${p.name}`,
    source: 'Sales Invoice', sourceTable: 'sales_invoice', sourceId: invoiceId,
    projectId: doc.projectId, lines
  });

  await client.query(
    `UPDATE sales_invoice SET status='POSTED', doc_no=$1, entry_id=$2, posted_at=now() WHERE id=$3`,
    [docNo, entry.id, invoiceId]);

  for (const m of stockMoves) await moveStock(client, m.itemId, m.qty, m.unitCost, docNo, date, doc.projectId, entry.id);

  return { id: invoiceId, docNo, entryId: entry.id, gross: M.format(gross),
           retention: M.format(retention), advanceRecovered: M.format(advance),
           netReceivable: M.format(receivable) };
}

const label = t => ({ TRADING: 'Trading invoice', CERTIFICATE: 'Payment certificate',
                      SERVICE: 'Service invoice', CREDIT_NOTE: 'Credit note' }[t] || t);

/* ==================== PURCHASES ==================== */
async function postPurchaseInvoice(client, user, doc) {
  const p = await party(client, doc.partyId, 'SUPPLIER');
  const date = doc.invoiceDate || today();
  const dueDate = doc.dueDate || addDays(date, p.terms_days);
  const AP = await L.control(client, 'ap');

  const lines = [];
  let gross = 0n, retention = 0n;
  const advance = M.parse(doc.advanceRecovered || 0);
  const stockMoves = [];

  if (doc.docType === 'SUBCONTRACT') {
    gross = M.parse(doc.grossAmount);
    if (gross <= 0n) throw badRequest('Enter the value certified.');
    retention = M.percent(gross, String(doc.retentionPct ?? 0));
    lines.push({ account: doc.costAccount || '5200', debit: gross, projectId: doc.projectId,
                 costCodeId: doc.costCodeId || null, memo: 'Subcontract works certified' });
  } else if (doc.docType === 'STOCK') {
    const rows = doc.lines || [];
    if (!rows.length) throw badRequest('Add at least one line.');
    const byAccount = new Map();
    for (const r of rows) {
      if (!r.itemId) throw badRequest('Every stock line needs an item.');
      const { rows: it } = await client.query('SELECT inventory_account FROM item WHERE id=$1', [r.itemId]);
      if (!it[0]) throw notFound(`Item ${r.itemId} does not exist.`);
      const value = M.extend(r.quantity ?? 1, r.unitCost ?? 0);
      r._total = value;
      gross += value;
      byAccount.set(it[0].inventory_account, (byAccount.get(it[0].inventory_account) || 0n) + value);
      stockMoves.push({ itemId: r.itemId, qty: String(r.quantity ?? 1), unitCost: String(r.unitCost ?? 0), value });
    }
    for (const [acct, v] of byAccount) lines.push({ account: acct, debit: v, memo: 'Goods received into store' });
  } else {
    const rows = doc.lines || [];
    if (!rows.length) throw badRequest('Add at least one line.');
    for (const r of rows) {
      if (!r.expenseAccount) throw badRequest('Every cost line needs an account.');
      const v = M.parse(r.amount || 0);
      r._total = v;
      gross += v;
      lines.push({ account: r.expenseAccount, debit: v, projectId: doc.projectId,
                   costCodeId: r.costCodeId || doc.costCodeId || null, memo: r.description || null });
    }
  }
  if (gross <= 0n) throw badRequest('The invoice value is zero.');

  if (advance > 0n) {
    const held = await advanceOutstanding(client, 'SUPPLIER', doc.partyId, doc.projectId);
    if (advance > held) {
      throw badRequest(
        `You are setting off ${M.format(advance)} of advance but only ${M.format(held)} is outstanding with ${p.name} on this contract.`);
    }
  }
  if (retention + advance > gross) throw badRequest('Retention plus advance recovery cannot exceed the gross value.');

  // A subcontract certificate cannot quietly exceed the order it is
  // drawn against; that is the whole point of ordering the work.
  if (doc.subcontractId) {
    const { rows: pkg } = await client.query(
      `SELECT ref, title, order_value, certified_to_date
         FROM v_subcontract_package WHERE id=$1`, [doc.subcontractId]);
    if (!pkg[0]) throw notFound('That subcontract package does not exist.');
    const order = M.parse(pkg[0].order_value);
    const already = M.parse(pkg[0].certified_to_date);
    if (already + gross > order) {
      throw badRequest(
        `That would certify ${M.format(already + gross)} against package ${pkg[0].ref}, ` +
        `which was ordered at ${M.format(order)}. Raise a variation to the package first.`);
    }
  }

  const payable = gross - retention - advance;
  lines.push({ account: AP, credit: payable, partyId: p.id, projectId: doc.projectId, memo: 'Supplier invoice' });
  if (retention > 0n) {
    lines.push({ account: await L.control(client, 'retention_pay'), credit: retention,
                 partyId: p.id, projectId: doc.projectId, memo: 'Retention withheld' });
  }
  if (advance > 0n) {
    lines.push({ account: await L.control(client, 'supp_adv'), credit: advance,
                 partyId: p.id, projectId: doc.projectId, memo: 'Advance recovered' });
  }

  const docNo = await L.nextDocNo(client, 'PI', date);
  const { rows: ins } = await client.query(
    `INSERT INTO purchase_invoice
       (doc_type, status, invoice_date, due_date, party_id, project_id, supplier_ref,
        gross_amount, retention_amount, advance_recovered, net_payable, narration, created_by)
     VALUES ($1,'DRAFT',$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
    [doc.docType, date, dueDate, p.id, doc.projectId || null, doc.supplierRef || null,
     M.format(gross), M.format(retention), M.format(advance), M.format(payable),
     doc.narration || null, user.id]);
  const invoiceId = ins[0].id;

  for (const [i, r] of (doc.lines || []).entries()) {
    await client.query(
      `INSERT INTO purchase_invoice_line
         (invoice_id, line_no, item_id, expense_account, description, quantity, unit_cost, line_total)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [invoiceId, i + 1, r.itemId || null, r.expenseAccount || null, r.description || null,
       String(r.quantity ?? 1), String(r.unitCost ?? 0), M.format(r._total || 0n)]);
  }

  const entry = await L.post(client, user, {
    date, entryNo: docNo,
    memo: doc.narration || `${doc.docType} — ${p.name}`,
    source: 'Purchase Invoice', sourceTable: 'purchase_invoice', sourceId: invoiceId,
    projectId: doc.projectId, lines
  });
  await client.query(
    `UPDATE purchase_invoice
        SET status='POSTED', doc_no=$1, entry_id=$2, posted_at=now(),
            subcontract_id=$4, cost_code_id=$5
      WHERE id=$3`,
    [docNo, entry.id, invoiceId, doc.subcontractId || null, doc.costCodeId || null]);

  for (const m of stockMoves) await moveStock(client, m.itemId, m.qty, m.unitCost, docNo, date, null, entry.id);

  return { id: invoiceId, docNo, entryId: entry.id, gross: M.format(gross),
           retention: M.format(retention), netPayable: M.format(payable) };
}

/* ==================== CASH ==================== */
/**
 * purpose: SETTLEMENT (against invoices) | ADVANCE | DIRECT | TRANSFER
 * direction: IN | OUT
 */
async function postCashDocument(client, user, doc) {
  const amount = M.parse(doc.amount);
  if (amount <= 0n) throw badRequest('Enter an amount greater than zero.');
  const date = doc.docDate || today();
  const dir = doc.direction;
  if (!['IN', 'OUT'].includes(dir)) throw badRequest('Direction must be IN or OUT.');

  // Maker/checker: payments at or above the limit need a second person.
  const { rows: co } = await client.query('SELECT payment_approval_limit FROM company WHERE id=1');
  const limit = M.parse(co[0]?.payment_approval_limit || 0);
  const needsApproval = dir === 'OUT' && limit > 0n && amount >= limit;

  const { rows: ins } = await client.query(
    `INSERT INTO cash_document
       (direction, status, doc_date, party_id, employee_id, project_id, cash_account,
        contra_account, purpose, method, reference, amount, narration, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING id`,
    [dir, needsApproval ? 'PENDING_APPROVAL' : 'DRAFT', date, doc.partyId || null,
     doc.employeeId || null, doc.projectId || null, doc.cashAccount, doc.contraAccount || null,
     doc.purpose, doc.method || null, doc.reference || null, M.format(amount),
     doc.narration || null, user.id]);
  const id = ins[0].id;

  for (const a of doc.allocations || []) {
    if (!a.salesInvoiceId && !a.purchaseInvoiceId) {
      throw badRequest('Each allocation must name the invoice it settles.');
    }
    if (a.salesInvoiceId && a.purchaseInvoiceId) {
      throw badRequest('An allocation settles one invoice, not both a sales and a purchase invoice.');
    }
    await client.query(
      `INSERT INTO cash_allocation (cash_document_id, sales_invoice_id, purchase_invoice_id, amount)
       VALUES ($1,$2,$3,$4)`,
      [id, a.salesInvoiceId || null, a.purchaseInvoiceId || null, M.format(M.parse(a.amount))]);
  }

  if (needsApproval) {
    await L.audit(client, user, 'SUBMIT_FOR_APPROVAL', 'cash_document', id,
      { amount: M.format(amount), limit: M.format(limit) });
    return { id, status: 'PENDING_APPROVAL', amount: M.format(amount),
             message: `Payments of ${M.format(limit)} or more need a second approval before they post.` };
  }
  return postApprovedCashDocument(client, user, id);
}

/** Approve a pending payment. The database refuses maker === checker. */
async function approveCashDocument(client, user, id) {
  if (!user.can_approve) throw forbidden('Your role cannot approve payments.');
  const { rowCount } = await client.query(
    `UPDATE cash_document SET approved_by=$1, approved_at=now()
      WHERE id=$2 AND status='PENDING_APPROVAL'`, [user.id, id]);
  if (!rowCount) throw badRequest('That payment is not awaiting approval.');
  await L.audit(client, user, 'APPROVE', 'cash_document', id, null);
  return postApprovedCashDocument(client, user, id);
}

async function postApprovedCashDocument(client, user, id) {
  const { rows } = await client.query('SELECT * FROM cash_document WHERE id=$1', [id]);
  const d = rows[0];
  if (!d) throw notFound('That document does not exist.');
  if (d.status === 'POSTED') throw badRequest('That document has already been posted.');

  const amount = M.parse(d.amount);
  const cash = d.cash_account;
  let contra = d.contra_account;

  if (d.purpose === 'SETTLEMENT') {
    contra = await L.control(client, d.direction === 'IN' ? 'ar' : 'ap');
  } else if (d.purpose === 'ADVANCE') {
    contra = await L.control(client, d.direction === 'IN' ? 'cust_adv' : 'supp_adv');
  }
  if (!contra) throw badRequest('This document needs a contra account.');

  const lines = d.direction === 'IN'
    ? [{ account: cash, debit: amount, partyId: d.party_id, projectId: d.project_id, memo: d.method || 'Received' },
       { account: contra, credit: amount, partyId: d.party_id, projectId: d.project_id, employeeId: d.employee_id, memo: d.narration || null }]
    : [{ account: contra, debit: amount, partyId: d.party_id, projectId: d.project_id, employeeId: d.employee_id, memo: d.narration || null },
       { account: cash, credit: amount, partyId: d.party_id, projectId: d.project_id, memo: d.method || 'Paid' }];

  const prefix = d.direction === 'IN' ? 'RV' : 'PV';
  const docNo = d.doc_no || await L.nextDocNo(client, prefix, d.doc_date);

  const entry = await L.post(client, user, {
    date: d.doc_date, entryNo: docNo,
    memo: d.narration || `${d.direction === 'IN' ? 'Receipt' : 'Payment'} ${d.reference || ''}`.trim(),
    source: d.direction === 'IN' ? 'Receipt' : 'Payment',
    sourceTable: 'cash_document', sourceId: d.id, projectId: d.project_id, lines
  });

  await client.query(
    `UPDATE cash_document SET status='POSTED', doc_no=$1, entry_id=$2, posted_at=now() WHERE id=$3`,
    [docNo, entry.id, d.id]);

  // An allocation may not exceed what is still open on the invoice.
  await assertAllocationsValid(client, d.id);

  return { id: d.id, docNo, entryId: entry.id, status: 'POSTED', amount: M.format(amount) };
}

async function assertAllocationsValid(client, cashDocId) {
  const { rows } = await client.query(
    `SELECT a.sales_invoice_id, a.purchase_invoice_id, a.amount,
            si.doc_no  AS si_no, si.net_receivable,
            pi.doc_no  AS pi_no, pi.net_payable,
            (SELECT COALESCE(SUM(x.amount),0) FROM cash_allocation x
               JOIN cash_document c ON c.id = x.cash_document_id AND c.status='POSTED'
              WHERE x.sales_invoice_id = a.sales_invoice_id) AS si_paid,
            (SELECT COALESCE(SUM(x.amount),0) FROM cash_allocation x
               JOIN cash_document c ON c.id = x.cash_document_id AND c.status='POSTED'
              WHERE x.purchase_invoice_id = a.purchase_invoice_id) AS pi_paid
       FROM cash_allocation a
       LEFT JOIN sales_invoice si ON si.id = a.sales_invoice_id
       LEFT JOIN purchase_invoice pi ON pi.id = a.purchase_invoice_id
      WHERE a.cash_document_id = $1`, [cashDocId]);
  for (const r of rows) {
    if (r.sales_invoice_id && M.parse(r.si_paid) > M.parse(r.net_receivable)) {
      throw badRequest(`That would overpay invoice ${r.si_no}: ${M.format(M.parse(r.si_paid))} allocated against ${r.net_receivable} receivable.`);
    }
    if (r.purchase_invoice_id && M.parse(r.pi_paid) > M.parse(r.net_payable)) {
      throw badRequest(`That would overpay invoice ${r.pi_no}: ${M.format(M.parse(r.pi_paid))} allocated against ${r.net_payable} payable.`);
    }
  }
}

/* ==================== INVENTORY ==================== */
/**
 * Weighted-average cost. The value moved is rounded exactly as the
 * journal rounds it, so the stock ledger and the inventory control
 * accounts cannot drift apart.
 */
async function moveStock(client, itemId, qty, unitCost, reference, date, projectId, entryId) {
  const { rows } = await client.query(
    `SELECT balance_qty, balance_value, wac FROM stock_move
      WHERE item_id = $1 ORDER BY moved_on DESC, id DESC LIMIT 1`, [itemId]);
  const prevQty = M.parse(rows[0]?.balance_qty || 0, 3);
  const prevVal = M.parse(rows[0]?.balance_value || 0);
  const prevWac = rows[0]?.wac || '0';

  const q = M.parse(qty, 3);
  if (q === 0n) return null;

  const unit = q > 0n ? String(unitCost) : prevWac;
  const value = M.mul(M.abs(q), 3, M.parse(unit, 6), 6, M.SCALE);

  const newQty = prevQty + q;
  const newVal = q > 0n ? prevVal + value : prevVal - value;
  // value is scale 2, qty is scale 3, wac is scale 6:
  //   (value/10^2) / (qty/10^3) * 10^6  ==  value * 10^7 / qty
  const newWac = newQty > 0n
    ? M.formatAt(newVal * 10n ** 7n / newQty, 6)
    : prevWac;

  const { rows: ins } = await client.query(
    `INSERT INTO stock_move
       (item_id, moved_on, qty, unit_cost, value, balance_qty, balance_value, wac,
        reference, entry_id, project_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id, balance_qty, balance_value`,
    [itemId, date, M.formatAt(q, 3), M.formatAt(M.parse(unit, 6), 6), M.format(value),
     M.formatAt(newQty, 3), M.format(newVal), newWac,
     reference || null, entryId || null, projectId || null]);
  return ins[0];
}

module.exports = {
  postSalesInvoice, postPurchaseInvoice,
  postCashDocument, approveCashDocument, postApprovedCashDocument,
  moveStock, advanceOutstanding, today, addDays
};
