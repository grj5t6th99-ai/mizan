'use strict';
const M = require('../money');
const L = require('../ledger');
const { badRequest, notFound, conflict } = require('../db');
const { today, addDays } = require('./documents');

/* ============================================================
   The contracting flow.

   Estimate -> Quotation -> Won -> Project with a budget made of
   cost codes -> costs tagged to those codes -> budget vs actual.

   Awarding is the moment that matters. It is the only place the
   estimate crosses into the ledger's world, and once it has, the
   estimate is frozen: a budget you can still edit is not a budget.
   ============================================================ */

const CATEGORIES = ['material', 'labour', 'plant', 'subcontract', 'other'];

/* ---------- estimating ---------- */

async function createEstimate(client, user, input) {
  if (!input.title || !String(input.title).trim()) throw badRequest('Give the estimate a title.');
  const date = input.estimateDate || today();
  const ref = await L.nextDocNo(client, 'EST', date);

  const { rows } = await client.query(
    `INSERT INTO estimate
       (ref, title, title_ar, client_id, estimate_date, valid_until,
        overhead_pct, profit_pct, contingency_pct, duration_days,
        retention_pct, advance_pct, scope, notes, supersedes_id, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
     RETURNING id, ref`,
    [ref, input.title, input.titleAr || null, input.clientId || null, date,
     input.validUntil || addDays(date, 30),
     input.overheadPct ?? 8, input.profitPct ?? 12, input.contingencyPct ?? 0,
     input.durationDays || null, input.retentionPct ?? 10, input.advancePct ?? 0,
     input.scope || null, input.notes || null, input.supersedesId || null, user.id]);
  const estimate = rows[0];

  if (input.supersedesId) {
    await client.query(`UPDATE estimate SET status='SUPERSEDED' WHERE id=$1 AND status='DRAFT'`,
      [input.supersedesId]);
  }
  await replaceLines(client, estimate.id, input.lines || []);
  await L.audit(client, user, 'CREATE', 'estimate', estimate.id, { ref, title: input.title });
  return read(client, estimate.id);
}

async function updateEstimate(client, user, id, input) {
  const e = await mustBeDraft(client, id, 'edited');
  const fields = {
    title: input.title, title_ar: input.titleAr, client_id: input.clientId,
    estimate_date: input.estimateDate, valid_until: input.validUntil,
    overhead_pct: input.overheadPct, profit_pct: input.profitPct,
    contingency_pct: input.contingencyPct, duration_days: input.durationDays,
    retention_pct: input.retentionPct, advance_pct: input.advancePct,
    scope: input.scope, notes: input.notes
  };
  const keys = Object.keys(fields).filter(k => fields[k] !== undefined);
  if (keys.length) {
    await client.query(
      `UPDATE estimate SET ${keys.map((k, i) => `${k}=$${i + 2}`).join(',')} WHERE id=$1`,
      [id, ...keys.map(k => fields[k])]);
  }
  if (input.lines) await replaceLines(client, id, input.lines);
  await L.audit(client, user, 'UPDATE', 'estimate', id, { ref: e.ref });
  return read(client, id);
}

async function replaceLines(client, estimateId, lines) {
  await client.query('DELETE FROM estimate_line WHERE estimate_id=$1', [estimateId]);
  let n = 0;
  const seen = new Set();
  for (const l of lines) {
    n += 1;                       // the line number always advances; an
    if (!l.description || !String(l.description).trim()) {   // earlier version
      throw badRequest(`Line ${n} has no description.`);     // only advanced it
    }                                                        // when a line had
    const code = (l.code || '').trim() || autoCode(n);       // no code of its own
    if (seen.has(code)) throw badRequest(`Two lines share the code "${code}". Cost codes must be unique.`);
    seen.add(code);
    await client.query(
      `INSERT INTO estimate_line
         (estimate_id, line_no, section, code, description, description_ar, unit, quantity,
          material_rate, labour_rate, plant_rate, subcontract_rate, other_rate, note)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
      [estimateId, n, l.section || null, code, l.description, l.descriptionAr || null,
       l.unit || 'NOS', String(l.quantity ?? 1),
       String(l.materialRate ?? 0), String(l.labourRate ?? 0), String(l.plantRate ?? 0),
       String(l.subcontractRate ?? 0), String(l.otherRate ?? 0), l.note || null]);
  }
}
const autoCode = n => String(n * 10).padStart(4, '0');

async function read(client, id) {
  const { rows } = await client.query('SELECT * FROM v_estimate WHERE id=$1', [id]);
  if (!rows[0]) throw notFound('That estimate does not exist.');
  const { rows: lines } = await client.query(
    'SELECT * FROM v_estimate_line WHERE estimate_id=$1 ORDER BY line_no', [id]);
  return { ...rows[0], lines };
}

async function mustBeDraft(client, id, verb) {
  const { rows } = await client.query('SELECT * FROM estimate WHERE id=$1', [id]);
  const e = rows[0];
  if (!e) throw notFound('That estimate does not exist.');
  if (e.status !== 'DRAFT') {
    throw conflict(`Estimate ${e.ref} is ${e.status.toLowerCase()} and can no longer be ${verb}. ` +
      `Create a revision instead, which keeps this one on record.`);
  }
  return e;
}

async function submitEstimate(client, user, id, { submittedOn } = {}) {
  const e = await mustBeDraft(client, id, 'submitted');
  const full = await read(client, id);
  if (!full.line_count) throw badRequest('An estimate needs at least one line before it is submitted.');
  if (!e.client_id) throw badRequest('Name the client before submitting.');
  await client.query(
    `UPDATE estimate SET status='SUBMITTED', submitted_on=$2 WHERE id=$1`,
    [id, submittedOn || today()]);
  await L.audit(client, user, 'SUBMIT', 'estimate', id,
    { ref: e.ref, value: full.sell_total });
  return read(client, id);
}

/** A revision copies the lines so the original stays on record. */
async function reviseEstimate(client, user, id, input = {}) {
  const src = await read(client, id);
  const copy = await createEstimate(client, user, {
    title: input.title || src.title,
    titleAr: src.title_ar, clientId: src.client_id,
    estimateDate: input.estimateDate || today(),
    overheadPct: input.overheadPct ?? src.overhead_pct,
    profitPct: input.profitPct ?? src.profit_pct,
    contingencyPct: input.contingencyPct ?? src.contingency_pct,
    durationDays: src.duration_days, retentionPct: src.retention_pct,
    advancePct: src.advance_pct, scope: src.scope, notes: input.notes || src.notes,
    supersedesId: id,
    lines: src.lines.map(l => ({
      section: l.section, code: l.code, description: l.description,
      descriptionAr: l.description_ar, unit: l.unit, quantity: l.quantity,
      materialRate: l.material_rate, labourRate: l.labour_rate, plantRate: l.plant_rate,
      subcontractRate: l.subcontract_rate, otherRate: l.other_rate, note: l.note
    }))
  });
  await client.query(`UPDATE estimate SET status='SUPERSEDED' WHERE id=$1`, [id]);
  await L.audit(client, user, 'REVISE', 'estimate', id, { into: copy.ref });
  return copy;
}

async function markLost(client, user, id, { reason, decidedOn } = {}) {
  const { rows } = await client.query('SELECT * FROM estimate WHERE id=$1', [id]);
  const e = rows[0];
  if (!e) throw notFound('That estimate does not exist.');
  if (e.status === 'WON') throw conflict('That estimate was won; it cannot be marked lost.');
  await client.query(
    `UPDATE estimate SET status='LOST', decided_on=$2, outcome_note=$3 WHERE id=$1`,
    [id, decidedOn || today(), reason || null]);
  await L.audit(client, user, 'LOST', 'estimate', id, { ref: e.ref, reason: reason || null });
  return read(client, id);
}

/* ---------- the award: estimate becomes a job with a budget ---------- */

/**
 * Turn a won estimate into a project. Every estimate line becomes a
 * cost code carrying its budget, so from this moment every riyal
 * spent can be compared with the riyal that was priced.
 */
async function awardEstimate(client, user, id, input = {}) {
  const { rows } = await client.query('SELECT * FROM estimate WHERE id=$1', [id]);
  const e = rows[0];
  if (!e) throw notFound('That estimate does not exist.');
  if (e.status === 'WON') throw conflict(`Estimate ${e.ref} has already been awarded.`);
  if (!['DRAFT', 'SUBMITTED'].includes(e.status)) {
    throw conflict(`Estimate ${e.ref} is ${e.status.toLowerCase()} and cannot be awarded.`);
  }
  const full = await read(client, id);
  if (!full.line_count) throw badRequest('An estimate with no lines cannot become a project.');
  if (!e.client_id) throw badRequest('Name the client before awarding.');

  const startsOn = input.startsOn || today();
  const endsOn = input.endsOn ||
    addDays(startsOn, e.duration_days || 180);
  const contractValue = input.contractValue != null
    ? M.format(M.parse(input.contractValue))
    : full.sell_total;

  const code = input.projectCode || await nextProjectCode(client);
  const { rows: pr } = await client.query(
    `INSERT INTO project
       (code, name, name_ar, client_id, starts_on, baseline_end_on, end_on,
        contract_value, retention_pct, advance_pct, manager, location, scope, status)
     VALUES ($1,$2,$3,$4,$5,$6,$6,$7,$8,$9,$10,$11,$12,'IN_PROGRESS')
     RETURNING *`,
    [code, input.name || e.title, e.title_ar, e.client_id, startsOn, endsOn,
     contractValue, e.retention_pct, e.advance_pct,
     input.manager || null, input.location || null, e.scope]);
  const project = pr[0];

  // every priced line becomes a budget line
  for (const l of full.lines) {
    await client.query(
      `INSERT INTO cost_code
         (project_id, code, section, description, description_ar, unit, budget_quantity,
          budget_material, budget_labour, budget_plant, budget_subcontract, budget_other,
          sell_amount, source_line_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
      [project.id, l.code, l.section, l.description, l.description_ar, l.unit, l.quantity,
       l.material_amount, l.labour_amount, l.plant_amount, l.subcontract_amount, l.other_amount,
       l.sell_amount, l.id]);
  }

  await client.query(
    `UPDATE estimate SET status='WON', decided_on=$2, project_id=$3, outcome_note=$4 WHERE id=$1`,
    [id, input.decidedOn || today(), project.id, input.note || null]);

  await L.audit(client, user, 'AWARD', 'estimate', id,
    { ref: e.ref, project: project.code, contract_value: contractValue,
      cost_codes: full.lines.length });

  return {
    projectId: project.id, projectCode: project.code, estimateRef: e.ref,
    contractValue, budgetCost: full.cost_total, costCodes: full.lines.length,
    marginAsPriced: M.format(M.parse(contractValue) - M.parse(full.cost_total))
  };
}

async function nextProjectCode(client) {
  const { rows } = await client.query(
    `SELECT COALESCE(MAX(NULLIF(regexp_replace(code, '\\D', '', 'g'), '')::int), 0) + 1 AS n
       FROM project WHERE code ~ '^PRJ-'`);
  return 'PRJ-' + String(rows[0].n).padStart(4, '0');
}

/* ---------- variations ---------- */

async function createVariation(client, user, input) {
  if (!input.projectId) throw badRequest('A variation belongs to a project.');
  if (!input.title) throw badRequest('Give the variation a title.');
  const ref = await L.nextDocNo(client, 'VO', input.submittedOn || today());
  const { rows } = await client.query(
    `INSERT INTO variation_order
       (project_id, ref, title, description, sell_value, cost_value, days_claimed,
        submitted_on, status, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [input.projectId, ref, input.title, input.description || null,
     M.format(M.parse(input.sellValue || 0)), M.format(M.parse(input.costValue || 0)),
     input.daysClaimed || 0, input.submittedOn || today(),
     input.submit ? 'SUBMITTED' : 'DRAFT', user.id]);
  await L.audit(client, user, 'CREATE', 'variation_order', rows[0].id, { ref });
  return rows[0];
}

/**
 * Approving a variation moves the contract value AND the budget. A
 * variation that raises the price without raising the budget quietly
 * flatters the forecast, which is the opposite of the point.
 */
async function approveVariation(client, user, id, input = {}) {
  const { rows } = await client.query('SELECT * FROM variation_order WHERE id=$1', [id]);
  const v = rows[0];
  if (!v) throw notFound('That variation does not exist.');
  if (v.status === 'APPROVED') throw conflict(`Variation ${v.ref} is already approved.`);
  if (v.status === 'REJECTED') throw conflict(`Variation ${v.ref} was rejected.`);

  await client.query(
    `UPDATE variation_order SET status='APPROVED', decided_on=$2, outcome_note=$3 WHERE id=$1`,
    [id, input.decidedOn || today(), input.note || null]);

  // the added cost needs somewhere to be budgeted and charged
  const codeRef = `VO-${v.ref.split('-').pop()}`;
  const { rows: cc } = await client.query(
    `INSERT INTO cost_code
       (project_id, code, section, description, unit, budget_quantity,
        budget_other, sell_amount, variation_id)
     VALUES ($1,$2,'Variations',$3,'SUM',1,$4,$5,$6)
     ON CONFLICT (project_id, code) DO UPDATE
        SET budget_other = cost_code.budget_other + EXCLUDED.budget_other,
            sell_amount  = cost_code.sell_amount  + EXCLUDED.sell_amount
     RETURNING *`,
    [v.project_id, codeRef, v.title, v.cost_value, v.sell_value, v.id]);

  if (v.days_claimed > 0) {
    const { rows: p } = await client.query('SELECT end_on FROM project WHERE id=$1', [v.project_id]);
    const from = String(p[0].end_on).slice(0, 10);
    const to = addDays(from, v.days_claimed);
    await client.query(
      `INSERT INTO project_revision
         (project_id, logged_on, from_end_on, to_end_on, reason, approved_by, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [v.project_id, input.decidedOn || today(), from, to,
       `Variation ${v.ref} approved — ${v.title}`, input.approvedBy || user.name, user.id]);
    await client.query('UPDATE project SET end_on=$1 WHERE id=$2', [to, v.project_id]);
  }

  await L.audit(client, user, 'APPROVE', 'variation_order', id,
    { ref: v.ref, sell: v.sell_value, cost: v.cost_value, days: v.days_claimed });

  const { rows: cvr } = await client.query('SELECT * FROM v_project_cvr WHERE id=$1', [v.project_id]);
  return { variation: v.ref, costCode: cc[0].code, project: cvr[0] };
}

/* ---------- subcontract packages ---------- */

async function createPackage(client, user, input) {
  if (!input.projectId || !input.partyId) throw badRequest('A package needs a project and a subcontractor.');
  if (!input.title) throw badRequest('Give the package a title.');
  const ref = await L.nextDocNo(client, 'SC', input.awardedOn || today());
  const award = input.award !== false;
  const { rows } = await client.query(
    `INSERT INTO subcontract_package
       (project_id, party_id, ref, title, scope, status, order_value, retention_pct,
        advance_pct, starts_on, ends_on, awarded_on, cost_code_id, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
    [input.projectId, input.partyId, ref, input.title, input.scope || null,
     award ? 'AWARDED' : 'DRAFT', M.format(M.parse(input.orderValue || 0)),
     input.retentionPct ?? 10, input.advancePct ?? 0,
     input.startsOn || null, input.endsOn || null,
     award ? (input.awardedOn || today()) : null,
     input.costCodeId || null, user.id]);
  await L.audit(client, user, 'CREATE', 'subcontract_package', rows[0].id,
    { ref, value: rows[0].order_value });
  const { rows: full } = await client.query('SELECT * FROM v_subcontract_package WHERE id=$1', [rows[0].id]);
  return full[0];
}

/* ---------- reading the position ---------- */

const costCodes = (db, projectId) =>
  db.query(`SELECT * FROM v_cost_code_position WHERE project_id=$1 ORDER BY section, code`,
    [projectId]).then(r => r.rows);

const cvr = (db, projectId) =>
  db.query(projectId
    ? 'SELECT * FROM v_project_cvr WHERE id=$1'
    : `SELECT * FROM v_project_cvr ORDER BY forecast_overrun DESC`,
    projectId ? [projectId] : []).then(r => projectId ? r.rows[0] : r.rows);

const pipeline = db =>
  db.query('SELECT * FROM v_estimate_pipeline').then(r => {
    const by = Object.fromEntries(r.rows.map(x => [x.status, x]));
    const won = Number(by.WON?.count || 0);
    const lost = Number(by.LOST?.count || 0);
    const decided = won + lost;
    return {
      byStatus: r.rows,
      winRateByCount: decided ? Math.round((won / decided) * 1000) / 10 : null,
      wonValue: by.WON?.value || '0.00',
      lostValue: by.LOST?.value || '0.00',
      liveValue: by.SUBMITTED?.value || '0.00'
    };
  });

module.exports = {
  createEstimate, updateEstimate, submitEstimate, reviseEstimate, markLost,
  awardEstimate, createVariation, approveVariation, createPackage,
  readEstimate: read, costCodes, cvr, pipeline, CATEGORIES
};
