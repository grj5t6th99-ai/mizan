'use strict';
const M = require('../money');
const L = require('../ledger');
const { badRequest, notFound, forbidden } = require('../db');
const { today } = require('./documents');

const asDate = v => (v instanceof Date ? v.toISOString().slice(0, 10) : String(v).slice(0, 10));
const monthEnd = v => {
  const d = new Date(asDate(v) + 'T00:00:00Z');
  if (isNaN(d)) throw new TypeError(`Not a date: ${v}`);
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).toISOString().slice(0, 10);
};
const monthsBetween = (a, b) => {
  const x = new Date(asDate(a) + 'T00:00:00Z'), y = new Date(asDate(b) + 'T00:00:00Z');
  return (y.getUTCFullYear() - x.getUTCFullYear()) * 12 + (y.getUTCMonth() - x.getUTCMonth());
};

/* ==================== PAYROLL ==================== */
/** Salaries for staff assigned to a project are charged to direct
 *  labour, so project cost is real rather than an allocation. */
async function runPayroll(client, user, { periodEnd, recoverAdvances = true }) {
  const end = monthEnd(periodEnd || today());
  const { rows: staff } = await client.query(
    `SELECT e.*, COALESCE((
       SELECT SUM(l.debit - l.credit) FROM journal_line l
        WHERE l.employee_id = e.id AND l.account_code = control('staff_adv')),0) AS advance_due
       FROM employee e
      WHERE e.is_active AND e.joined_on <= $1 AND (e.left_on IS NULL OR e.left_on >= $1)
      ORDER BY e.code`, [end]);
  if (!staff.length) throw badRequest('There are no active employees for that month.');

  const { rows: run } = await client.query(
    `INSERT INTO payroll_run (period_end, status, created_by) VALUES ($1,'DRAFT',$2) RETURNING id`,
    [end, user.id]);
  const runId = run[0].id;

  const byCharge = new Map();          // "account|projectId" -> amount
  let grossTotal = 0n, advTotal = 0n;
  const advLines = [];

  const salaryExp = await L.control(client, 'salary_exp');
  const directLabour = await L.control(client, 'direct_labour');
  const staffAdv = await L.control(client, 'staff_adv');
  const payable = await L.control(client, 'payroll_pay');

  for (const e of staff) {
    const basic = M.parse(e.basic_salary);
    const allow = M.parse(e.allowances);
    const gross = basic + allow;
    const due = M.parse(e.advance_due);
    const recover = recoverAdvances && due > 0n ? (due > gross ? gross : due) : 0n;
    const net = gross - recover;

    const acct = e.project_id ? directLabour : salaryExp;
    const key = `${acct}|${e.project_id || ''}|${e.cost_code_id || ''}`;
    byCharge.set(key, (byCharge.get(key) || 0n) + gross);
    grossTotal += gross; advTotal += recover;

    if (recover > 0n) {
      advLines.push({ account: staffAdv, credit: recover, employeeId: e.id,
                      memo: `Advance recovered — ${e.name}` });
    }
    await client.query(
      `INSERT INTO payroll_line (run_id, employee_id, project_id, basic, allowances, advance_recovered, net_pay)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [runId, e.id, e.project_id || null, M.format(basic), M.format(allow),
       M.format(recover), M.format(net)]);
  }

  const lines = [];
  for (const [key, amount] of byCharge) {
    const [account, projectId, costCodeId] = key.split('|');
    lines.push({ account, debit: amount, projectId: projectId || null,
                 costCodeId: costCodeId || null, memo: `Payroll to ${end}` });
  }
  lines.push(...advLines);
  lines.push({ account: payable, credit: grossTotal - advTotal, memo: 'Net salaries payable' });

  const entry = await L.post(client, user, {
    date: end, memo: `Payroll for the month ending ${end}`,
    source: 'Payroll', sourceTable: 'payroll_run', sourceId: runId, lines
  });
  await client.query(
    `UPDATE payroll_run SET status='POSTED', entry_id=$1, gross_total=$2, deductions=$3, net_total=$4, posted_at=now()
      WHERE id=$5`,
    [entry.id, M.format(grossTotal), M.format(advTotal), M.format(grossTotal - advTotal), runId]);

  return { runId, entryId: entry.id, periodEnd: end, employees: staff.length,
           gross: M.format(grossTotal), advancesRecovered: M.format(advTotal),
           netPayable: M.format(grossTotal - advTotal) };
}

/** End-of-service gratuity: Qatar Labour Law entitlement of N days
 *  of basic pay per year of service, accrued monthly per employee. */
async function accrueGratuity(client, user, { periodEnd }) {
  const end = monthEnd(periodEnd || today());
  const { rows: co } = await client.query('SELECT gratuity_days_year FROM company WHERE id=1');
  const days = co[0]?.gratuity_days_year || 21;

  const { rows: staff } = await client.query(
    `SELECT * FROM employee WHERE is_active AND joined_on <= $1
        AND (left_on IS NULL OR left_on >= $1) ORDER BY code`, [end]);
  if (!staff.length) throw badRequest('There are no active employees for that month.');

  const expense = await L.control(client, 'gratuity_exp');
  const provision = await L.control(client, 'gratuity');

  const lines = [];
  let total = 0n;
  for (const e of staff) {
    // annual entitlement = basic / 30 * days ; monthly = /12
    const annual = M.rescale(M.parse(e.basic_salary) * BigInt(days) * 100n / 30n, M.SCALE + 2, M.SCALE);
    const monthly = M.rescale(annual * 100n / 12n, M.SCALE + 2, M.SCALE);
    if (monthly <= 0n) continue;
    total += monthly;
    lines.push({ account: provision, credit: monthly, employeeId: e.id, memo: e.name });
  }
  if (total === 0n) throw badRequest('Nothing to accrue.');
  lines.unshift({ account: expense, debit: total, memo: `Gratuity for the month ending ${end}` });

  const entry = await L.post(client, user, {
    date: end, memo: `End-of-service provision for the month ending ${end}`,
    source: 'Gratuity', lines
  });
  return { entryId: entry.id, periodEnd: end, employees: lines.length - 1, amount: M.format(total) };
}

/* ==================== DEPRECIATION ==================== */
/** Straight line, monthly, per asset, capped at cost less residual. */
async function runDepreciation(client, user, { runTo }) {
  const to = monthEnd(runTo || today());
  const { rows: assets } = await client.query(
    `SELECT a.*, COALESCE((
       SELECT SUM(l.credit - l.debit) FROM journal_line l
        WHERE l.asset_id = a.id AND l.account_code = a.accdep_account),0) AS accum
       FROM fixed_asset a
      WHERE a.status = 'IN_USE' AND a.in_service_on <= $1
      ORDER BY a.tag`, [to]);

  const { rows: run } = await client.query(
    `INSERT INTO depreciation_run (run_to, status, created_by) VALUES ($1,'DRAFT',$2) RETURNING id`,
    [to, user.id]);
  const runId = run[0].id;

  const expense = await L.control(client, 'depr_exp');
  const lines = [];
  let total = 0n;

  for (const a of assets) {
    const from = a.depreciated_to ? monthEnd(a.depreciated_to) : null;
    const months = from ? monthsBetween(from, to) : monthsBetween(monthEnd(a.in_service_on), to) + 1;
    if (months <= 0) continue;

    const depreciable = M.parse(a.cost) - M.parse(a.residual_value);
    const monthly = M.rescale(depreciable * 100n / BigInt(a.life_months), M.SCALE + 2, M.SCALE);
    let charge = monthly * BigInt(months);
    const remaining = depreciable - M.parse(a.accum);
    if (charge > remaining) charge = remaining;       // never depreciate below residual
    if (charge <= 0n) continue;

    total += charge;
    lines.push({ account: a.accdep_account, credit: charge, assetId: a.id, memo: `${a.tag} ${a.name}` });
    await client.query(
      `INSERT INTO depreciation_line (run_id, asset_id, months, amount) VALUES ($1,$2,$3,$4)`,
      [runId, a.id, months, M.format(charge)]);
  }

  if (total === 0n) {
    await client.query('DELETE FROM depreciation_run WHERE id=$1', [runId]);
    throw badRequest('Every asset is already depreciated up to that date.');
  }
  lines.unshift({ account: expense, debit: total, memo: `Depreciation to ${to}` });

  const entry = await L.post(client, user, {
    date: to, memo: `Depreciation charge to ${to}`,
    source: 'Depreciation', sourceTable: 'depreciation_run', sourceId: runId, lines
  });
  await client.query(
    `UPDATE depreciation_run SET status='POSTED', entry_id=$1, total=$2 WHERE id=$3`,
    [entry.id, M.format(total), runId]);
  await client.query(
    `UPDATE fixed_asset SET depreciated_to=$1
      WHERE id IN (SELECT asset_id FROM depreciation_line WHERE run_id=$2)`, [to, runId]);

  return { runId, entryId: entry.id, runTo: to, assets: lines.length - 1, amount: M.format(total) };
}

/* ==================== PROJECTS ==================== */
/** Moving a contract end date is an event with a reason and an
 *  approver. The database refuses the update without this row. */
async function reviseProjectEndDate(client, user, projectId, { toEndOn, reason, approvedBy, loggedOn }) {
  if (!reason || !String(reason).trim()) throw badRequest('Give a reason for the revision.');
  if (!approvedBy || !String(approvedBy).trim()) throw badRequest('Name who approved the revision.');

  const { rows } = await client.query('SELECT * FROM project WHERE id=$1', [projectId]);
  const p = rows[0];
  if (!p) throw notFound('That project does not exist.');
  const from = asDate(p.end_on);
  if (from === toEndOn) throw badRequest('That is already the contract end date.');

  await client.query(
    `INSERT INTO project_revision (project_id, logged_on, from_end_on, to_end_on, reason, approved_by, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [projectId, loggedOn || today(), from, toEndOn, reason, approvedBy, user.id]);
  await client.query('UPDATE project SET end_on=$1 WHERE id=$2', [toEndOn, projectId]);
  await L.audit(client, user, 'REVISE_SCHEDULE', 'project', projectId,
    { from, to: toEndOn, reason, approved_by: approvedBy });

  const { rows: after } = await client.query('SELECT * FROM v_project_schedule WHERE id=$1', [projectId]);
  return after[0];
}

/* ==================== PERIOD CLOSE ==================== */
async function lockPeriod(client, user, periodId, status = 'LOCKED') {
  if (!user.can_close_period) throw forbidden('Your role cannot lock or close periods.');
  if (!['OPEN', 'LOCKED', 'CLOSED'].includes(status)) throw badRequest('Unknown period status.');

  if (status !== 'OPEN') {
    const { rows } = await client.query(
      `SELECT COUNT(*) AS n FROM cash_document c
        JOIN fiscal_period p ON c.doc_date BETWEEN p.starts_on AND p.ends_on
       WHERE p.id = $1 AND c.status IN ('DRAFT','PENDING_APPROVAL')`, [periodId]);
    if (Number(rows[0].n) > 0) {
      throw badRequest(`${rows[0].n} document(s) in that period are still unposted. Post or void them before locking.`);
    }
  }
  await client.query(
    `UPDATE fiscal_period
        SET status    = $1::period_status,
            locked_at = CASE WHEN $1::text = 'OPEN' THEN NULL ELSE now() END,
            locked_by = CASE WHEN $1::text = 'OPEN' THEN NULL ELSE $2::bigint END
      WHERE id = $3::int`, [status, user.id, periodId]);
  await L.audit(client, user, `PERIOD_${status}`, 'fiscal_period', periodId, null);
  const { rows } = await client.query('SELECT * FROM fiscal_period WHERE id=$1', [periodId]);
  return rows[0];
}

/**
 * Year-end close: roll the year's profit into retained earnings and
 * close the year. Revenue, cost and expense accounts start the next
 * year at zero because their balances are transferred out, not
 * because anything is deleted.
 */
async function closeYear(client, user, fiscalYearId) {
  if (!user.can_close_period) throw forbidden('Your role cannot close a financial year.');
  const { rows: fy } = await client.query('SELECT * FROM fiscal_year WHERE id=$1', [fiscalYearId]);
  const year = fy[0];
  if (!year) throw notFound('That financial year does not exist.');
  if (year.status !== 'OPEN') throw badRequest(`That year is already ${year.status}.`);

  const from = asDate(year.starts_on), to = asDate(year.ends_on);
  const { rows } = await client.query(
    `SELECT a.code, a.type, COALESCE(SUM(l.debit - l.credit),0) AS bal
       FROM account a
       JOIN journal_line l ON l.account_code = a.code
       JOIN journal_entry e ON e.id = l.entry_id
      WHERE a.type IN ('REVENUE','COS','EXPENSE') AND e.entry_date BETWEEN $1 AND $2
      GROUP BY a.code, a.type HAVING COALESCE(SUM(l.debit - l.credit),0) <> 0`, [from, to]);
  if (!rows.length) throw badRequest('There is nothing to close for that year.');

  const retained = await L.control(client, 'retained');
  const lines = [];
  let net = 0n;
  for (const r of rows) {
    const bal = M.parse(r.bal);
    net += bal;
    // reverse each nominal balance out to zero
    if (bal > 0n) lines.push({ account: r.code, credit: bal, memo: 'Year-end close' });
    else lines.push({ account: r.code, debit: -bal, memo: 'Year-end close' });
  }
  // net > 0 means debits exceed credits, i.e. a loss
  if (net > 0n) lines.push({ account: retained, debit: net, memo: 'Loss for the year' });
  else lines.push({ account: retained, credit: -net, memo: 'Profit for the year' });

  const entry = await L.post(client, user, {
    date: to, memo: `Year-end closing entry for ${year.code}`,
    source: 'Year End Close', sourceTable: 'fiscal_year', sourceId: year.id, lines
  });

  await client.query(`UPDATE fiscal_period SET status='CLOSED', locked_at=now(), locked_by=$1
                       WHERE fiscal_year_id=$2`, [user.id, year.id]);
  await client.query(`UPDATE fiscal_year SET status='CLOSED', closed_at=now(), closed_by=$1 WHERE id=$2`,
    [user.id, year.id]);
  await L.audit(client, user, 'YEAR_CLOSE', 'fiscal_year', year.id,
    { entry_no: entry.entry_no, profit: M.format(-net) });

  return { entryId: entry.id, entryNo: entry.entry_no, year: year.code,
           profit: M.format(-net), accountsClosed: rows.length };
}

module.exports = {
  runPayroll, accrueGratuity, runDepreciation,
  reviseProjectEndDate, lockPeriod, closeYear, monthEnd
};
