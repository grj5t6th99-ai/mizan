'use strict';
const M = require('../money');

/* ============================================================
   Reports. Nothing here reads a stored balance, because none
   exists. Every figure is computed from journal_line, which is why
   a report cannot disagree with the ledger.
   ============================================================ */

const range = (from, to) => [from || '1900-01-01', to || '2999-12-31'];

async function trialBalance(db, { from, to } = {}) {
  const [f, t] = range(from, to);
  const { rows } = await db.query(
    `SELECT a.code, a.name, a.name_ar, a.type,
            COALESCE(SUM(l.debit),0)  AS total_debit,
            COALESCE(SUM(l.credit),0) AS total_credit,
            COALESCE(SUM(l.debit - l.credit),0) AS balance
       FROM account a
       LEFT JOIN journal_line l  ON l.account_code = a.code
       LEFT JOIN journal_entry e ON e.id = l.entry_id AND e.entry_date BETWEEN $1 AND $2
      WHERE NOT a.is_group AND e.id IS NOT NULL
      GROUP BY a.code, a.name, a.name_ar, a.type
      ORDER BY a.code`, [f, t]);

  const debit = M.sum(rows.filter(r => M.parse(r.balance) > 0n).map(r => M.parse(r.balance)));
  const credit = M.sum(rows.filter(r => M.parse(r.balance) < 0n).map(r => -M.parse(r.balance)));
  return {
    from: f, to: t, rows,
    totals: { debit: M.format(debit), credit: M.format(credit), difference: M.format(debit - credit) },
    balanced: debit === credit
  };
}

async function profitAndLoss(db, { from, to, projectId } = {}) {
  const [f, t] = range(from, to);
  const { rows } = await db.query(
    `SELECT a.code, a.name, a.name_ar, a.type,
            COALESCE(SUM(l.debit - l.credit),0) * account_sign(a.type) AS amount
       FROM account a
       JOIN journal_line l  ON l.account_code = a.code
       JOIN journal_entry e ON e.id = l.entry_id
      WHERE a.type IN ('REVENUE','COS','EXPENSE')
        AND e.entry_date BETWEEN $1 AND $2
        AND ($3::bigint IS NULL OR l.project_id = $3)
      GROUP BY a.code, a.name, a.name_ar, a.type
      HAVING COALESCE(SUM(l.debit - l.credit),0) <> 0
      ORDER BY a.code`, [f, t, projectId || null]);

  const pick = type => rows.filter(r => r.type === type);
  const total = list => M.sum(list.map(r => M.parse(r.amount)));
  const revenue = pick('REVENUE'), cos = pick('COS'), expense = pick('EXPENSE');
  const tRev = total(revenue), tCos = total(cos), tExp = total(expense);
  const gross = tRev - tCos, net = gross - tExp;

  return {
    from: f, to: t, projectId: projectId || null,
    revenue, costOfSales: cos, expenses: expense,
    totals: {
      revenue: M.format(tRev), costOfSales: M.format(tCos),
      grossProfit: M.format(gross), expenses: M.format(tExp), netProfit: M.format(net),
      grossMarginPct: tRev === 0n ? null : Number((gross * 10000n) / tRev) / 100,
      netMarginPct: tRev === 0n ? null : Number((net * 10000n) / tRev) / 100
    }
  };
}

async function balanceSheet(db, { asAt } = {}) {
  const t = asAt || '2999-12-31';
  const { rows } = await db.query(
    `SELECT a.code, a.name, a.name_ar, a.type,
            COALESCE(SUM(l.debit - l.credit),0) * account_sign(a.type) AS amount
       FROM account a
       JOIN journal_line l  ON l.account_code = a.code
       JOIN journal_entry e ON e.id = l.entry_id
      WHERE a.type IN ('ASSET','LIABILITY','EQUITY') AND e.entry_date <= $1
      GROUP BY a.code, a.name, a.name_ar, a.type
      HAVING COALESCE(SUM(l.debit - l.credit),0) <> 0
      ORDER BY a.code`, [t]);

  const { totals } = await profitAndLoss(db, { to: t });
  const profit = M.parse(totals.netProfit);

  const split = (type, pred) => rows.filter(r => r.type === type && pred(r.code));
  const sum = list => M.sum(list.map(r => M.parse(r.amount)));

  const currentAssets = split('ASSET', c => c < '1200');
  const nonCurrentAssets = split('ASSET', c => c >= '1200');
  const currentLiabilities = split('LIABILITY', c => c < '2200');
  const nonCurrentLiabilities = split('LIABILITY', c => c >= '2200');
  const equity = rows.filter(r => r.type === 'EQUITY');

  const tA = sum(currentAssets) + sum(nonCurrentAssets);
  const tL = sum(currentLiabilities) + sum(nonCurrentLiabilities);
  const tE = sum(equity) + profit;

  return {
    asAt: t,
    currentAssets, nonCurrentAssets, currentLiabilities, nonCurrentLiabilities, equity,
    profitForPeriod: M.format(profit),
    totals: {
      assets: M.format(tA), liabilities: M.format(tL), equity: M.format(tE),
      liabilitiesAndEquity: M.format(tL + tE), difference: M.format(tA - (tL + tE))
    },
    balanced: tA === tL + tE
  };
}

async function ageing(db, side) {
  const view = side === 'AR' ? 'v_open_sales_invoice' : 'v_open_purchase_invoice';
  const amount = side === 'AR' ? 'net_receivable' : 'net_payable';
  const { rows } = await db.query(
    `SELECT party_id, party_name, party_name_ar,
       SUM(CASE WHEN days_overdue = 0                       THEN outstanding ELSE 0 END) AS not_due,
       SUM(CASE WHEN days_overdue BETWEEN 1  AND 30         THEN outstanding ELSE 0 END) AS d1_30,
       SUM(CASE WHEN days_overdue BETWEEN 31 AND 60         THEN outstanding ELSE 0 END) AS d31_60,
       SUM(CASE WHEN days_overdue BETWEEN 61 AND 90         THEN outstanding ELSE 0 END) AS d61_90,
       SUM(CASE WHEN days_overdue > 90                      THEN outstanding ELSE 0 END) AS d90_plus,
       SUM(outstanding) AS total
     FROM ${view} WHERE outstanding > 0
     GROUP BY party_id, party_name, party_name_ar
     HAVING SUM(outstanding) > 0
     ORDER BY SUM(outstanding) DESC`, []);
  void amount;
  const col = k => M.format(M.sum(rows.map(r => M.parse(r[k]))));
  return {
    side, rows,
    totals: { not_due: col('not_due'), d1_30: col('d1_30'), d31_60: col('d31_60'),
              d61_90: col('d61_90'), d90_plus: col('d90_plus'), total: col('total') }
  };
}

async function projectProfitability(db) {
  const { rows } = await db.query(
    `SELECT p.id, p.code, p.name, p.name_ar, p.contract_value, p.status,
            p.starts_on, p.baseline_end_on, p.end_on,
            (CURRENT_DATE - p.end_on) AS days_over,
            (p.end_on - p.baseline_end_on) AS slip_days,
            (SELECT COUNT(*) FROM project_revision r WHERE r.project_id = p.id) AS revisions,
            (p.status NOT IN ('COMPLETED','CLOSED') AND (CURRENT_DATE - p.end_on) > 1) AS is_overdue,
            c.name AS client_name,
            COALESCE((SELECT SUM(l.credit - l.debit) FROM journal_line l
                        JOIN account a ON a.code=l.account_code AND a.type='REVENUE'
                       WHERE l.project_id = p.id),0) AS certified,
            COALESCE((SELECT SUM(l.debit - l.credit) FROM journal_line l
                        JOIN account a ON a.code=l.account_code AND a.type IN ('COS','EXPENSE')
                       WHERE l.project_id = p.id),0) AS cost
       FROM project p LEFT JOIN party c ON c.id = p.client_id
      ORDER BY (p.status NOT IN ('COMPLETED','CLOSED') AND (CURRENT_DATE - p.end_on) > 1) DESC,
               (CURRENT_DATE - p.end_on) DESC`, []);
  return rows.map(r => {
    const cert = M.parse(r.certified), cost = M.parse(r.cost);
    return { ...r, margin: M.format(cert - cost),
             margin_pct: cert === 0n ? null : Number(((cert - cost) * 10000n) / cert) / 100 };
  });
}

/** The number to watch. If any of these is non-zero, stop. */
async function health(db) {
  const { rows } = await db.query('SELECT * FROM v_ledger_health');
  const h = rows[0];
  const stock = await db.query(
    `SELECT COALESCE(SUM(s.stock_value),0) AS ledger,
            COALESCE((SELECT SUM(l.debit - l.credit) FROM journal_line l
                        JOIN account a ON a.code = l.account_code
                       WHERE a.class_tag = 'inventory'),0) AS gl
       FROM v_stock_on_hand s`);
  const bs = await balanceSheet(db, {});
  return {
    trialBalanceNet: h.trial_balance_net,
    unbalancedEntries: Number(h.unbalanced_entries),
    singleLineEntries: Number(h.single_line_entries),
    stockLedgerVsGl: M.format(M.parse(stock.rows[0].ledger) - M.parse(stock.rows[0].gl)),
    balanceSheetDifference: bs.totals.difference,
    ok: M.parse(h.trial_balance_net) === 0n &&
        Number(h.unbalanced_entries) === 0 &&
        Number(h.single_line_entries) === 0 &&
        M.parse(stock.rows[0].ledger) === M.parse(stock.rows[0].gl) &&
        bs.balanced
  };
}

module.exports = { trialBalance, profitAndLoss, balanceSheet, ageing, projectProfitability, health };
