'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const db = require('./db');
const { unauthorized, forbidden, badRequest } = db;

const scrypt = promisify(crypto.scrypt);
const N = 16384, r = 8, p = 1, KEYLEN = 64;
const SESSION_HOURS = Number(process.env.SESSION_HOURS || 12);
const MAX_FAILED = 8;
const LOCK_MINUTES = 15;

/* scrypt from node:crypto rather than bcrypt: no native build step,
   which matters when the whole thing has to rebuild on a small VPS. */
async function hashPassword(plain) {
  if (!plain || plain.length < 10) {
    throw badRequest('Use a password of at least 10 characters.');
  }
  const salt = crypto.randomBytes(16);
  const key = await scrypt(plain, salt, KEYLEN, { N, r, p });
  return `scrypt$${N}$${r}$${p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

async function verifyPassword(plain, stored) {
  if (!stored || !stored.startsWith('scrypt$')) return false;
  const [, n, rr, pp, salt, key] = stored.split('$');
  const derived = await scrypt(plain, Buffer.from(salt, 'base64'), KEYLEN,
    { N: Number(n), r: Number(rr), p: Number(pp) });
  const expected = Buffer.from(key, 'base64');
  // timingSafeEqual throws on length mismatch, so guard first
  return derived.length === expected.length && crypto.timingSafeEqual(derived, expected);
}

async function login(email, password, meta = {}) {
  const user = await db.one(
    `SELECT u.*, r.can_post, r.can_approve, r.can_close_period, r.can_admin, r.approval_limit
       FROM app_user u JOIN role r ON r.code = u.role_code
      WHERE lower(u.email) = lower($1)`, [email]);

  // Same message and similar timing whether the user exists or not.
  const fail = async () => {
    if (user) {
      const failed = user.failed_logins + 1;
      await db.query(
        `UPDATE app_user SET failed_logins = $1::int,
           locked_until = CASE WHEN $1::int >= $2::int
                               THEN now() + make_interval(mins => $3::int)
                               ELSE locked_until END
          WHERE id = $4::bigint`, [failed, MAX_FAILED, LOCK_MINUTES, user.id]);
    } else {
      await scrypt('dummy', 'dummy', KEYLEN, { N, r, p });
    }
    throw unauthorized('That email address and password do not match.');
  };

  if (!user || !user.is_active) return fail();
  if (user.locked_until && new Date(user.locked_until) > new Date()) {
    throw unauthorized(`Too many failed attempts. Try again after ${LOCK_MINUTES} minutes.`);
  }
  if (!await verifyPassword(password, user.password_hash)) return fail();

  const id = crypto.randomBytes(32).toString('base64url');
  const expires = new Date(Date.now() + SESSION_HOURS * 3600_000);
  await db.query(
    `INSERT INTO session (id, user_id, expires_at, ip, user_agent) VALUES ($1,$2,$3,$4,$5)`,
    [id, user.id, expires, meta.ip || null, (meta.userAgent || '').slice(0, 300)]);
  await db.query(
    `UPDATE app_user SET failed_logins=0, locked_until=NULL, last_login_at=now() WHERE id=$1`, [user.id]);
  await db.query(
    `INSERT INTO audit_log (user_id, user_name, action, entity, entity_id, ip)
     VALUES ($1,$2,'LOGIN','app_user',$3,$4)`, [user.id, user.name, String(user.id), meta.ip || null]);

  return { sessionId: id, expires, user: publicUser(user) };
}

async function logout(sessionId, user) {
  if (!sessionId) return;
  await db.query('DELETE FROM session WHERE id=$1', [sessionId]);
  if (user) {
    await db.query(
      `INSERT INTO audit_log (user_id, user_name, action, entity, entity_id)
       VALUES ($1,$2,'LOGOUT','app_user',$3)`, [user.id, user.name, String(user.id)]);
  }
}

async function resolveSession(sessionId) {
  if (!sessionId) return null;
  const row = await db.one(
    `SELECT s.id AS session_id, s.expires_at, u.*, r.can_post, r.can_approve,
            r.can_close_period, r.can_admin, r.approval_limit
       FROM session s
       JOIN app_user u ON u.id = s.user_id
       JOIN role r ON r.code = u.role_code
      WHERE s.id = $1 AND s.expires_at > now() AND u.is_active`, [sessionId]);
  if (!row) return null;
  // sliding expiry, written at most once a minute
  await db.query(
    `UPDATE session SET last_seen_at = now(),
            expires_at = now() + make_interval(hours => $2::int)
      WHERE id = $1 AND last_seen_at < now() - interval '1 minute'`,
    [sessionId, SESSION_HOURS]);
  return { ...publicUser(row), sessionId };
}

const publicUser = u => ({
  id: u.id, email: u.email, name: u.name, name_ar: u.name_ar, locale: u.locale,
  role: u.role_code, can_post: u.can_post, can_approve: u.can_approve,
  can_close_period: u.can_close_period, can_admin: u.can_admin,
  approval_limit: u.approval_limit, must_change_password: u.must_change_password
});

/* ---------- express middleware ---------- */
const COOKIE = 'mizan_session';

function cookieOptions() {
  return {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_HOURS * 3600_000
  };
}

async function attachUser(req, _res, next) {
  try {
    const sid = req.cookies?.[COOKIE];
    req.user = await resolveSession(sid);
    if (req.user) req.user.ip = req.ip;
    next();
  } catch (e) { next(e); }
}

const requireUser = (req, _res, next) =>
  req.user ? next() : next(unauthorized());

const requirePost = (req, _res, next) =>
  req.user?.can_post ? next() : next(forbidden('Your role cannot post to the ledger.'));

const requireAdmin = (req, _res, next) =>
  req.user?.can_admin ? next() : next(forbidden('That needs an administrator.'));

const requireApprove = (req, _res, next) =>
  req.user?.can_approve ? next() : next(forbidden('That needs an approver.'));

/** Delete expired sessions. Call hourly. */
const sweepSessions = () => db.query('DELETE FROM session WHERE expires_at < now()');

module.exports = {
  hashPassword, verifyPassword, login, logout, resolveSession,
  attachUser, requireUser, requirePost, requireAdmin, requireApprove,
  cookieOptions, sweepSessions, COOKIE, publicUser
};
