'use strict';
/* ============================================================
   Money arithmetic.

   JavaScript numbers cannot represent 0.1 exactly, and
   Math.round(2.675 * 100) is 267, not 268. In an accounting system
   that is not a rounding quirk, it is a wrong invoice. Every amount
   here is a BigInt of minor units (fils), parsed from and rendered
   to decimal strings, and every value handed to Postgres is a
   string so the driver never turns it into a float.
   ============================================================ */

const SCALE = 2;                 // QAR has 100 dirhams
const POW = n => 10n ** BigInt(n);

/** Parse a decimal string/number into BigInt at `scale`, half-up. */
function parse(value, scale = SCALE) {
  if (typeof value === 'bigint') return value;
  let s = String(value == null || value === '' ? '0' : value).trim();
  if (!/^[-+]?\d*(\.\d*)?$/.test(s)) throw new TypeError(`Not a number: ${value}`);
  const neg = s.startsWith('-');
  s = s.replace(/^[-+]/, '');
  let [int = '0', frac = ''] = s.split('.');
  int = int || '0';
  // keep one extra digit to decide the rounding, then round half-up
  const keep = frac.slice(0, scale).padEnd(scale, '0');
  const next = frac.charCodeAt(scale);                  // NaN when absent
  let v = BigInt(int) * POW(scale) + BigInt(keep || '0');
  if (next >= 53) v += 1n;                              // '5'..'9' -> round up
  return neg ? -v : v;
}

/** Render money (2dp) as a plain decimal string.
 *  Deliberately takes ONE argument: `list.map(format)` passes the
 *  array index as the second argument, so a `scale` parameter here
 *  would silently format element 1 at 1dp. Use formatAt() when you
 *  really need another scale. */
const format = v => formatAt(v, SCALE);

function formatAt(v, scale = SCALE) {
  const neg = v < 0n;
  const abs = neg ? -v : v;
  const p = POW(scale);
  const int = abs / p;
  const frac = (abs % p).toString().padStart(scale, '0');
  return `${neg ? '-' : ''}${int}${scale ? '.' + frac : ''}`;
}

/** Multiply two scaled BigInts, rounding half-up to `outScale`. */
function mul(a, aScale, b, bScale, outScale = SCALE) {
  const raw = a * b;                                    // scale = aScale + bScale
  return rescale(raw, aScale + bScale, outScale);
}

function rescale(v, fromScale, toScale) {
  if (fromScale === toScale) return v;
  if (fromScale < toScale) return v * POW(toScale - fromScale);
  const p = POW(fromScale - toScale);
  const neg = v < 0n, abs = neg ? -v : v;
  const q = abs / p, r = abs % p;
  const rounded = (r * 2n >= p) ? q + 1n : q;           // half-up
  return neg ? -rounded : rounded;
}

/** amount x percent, rounded to money scale. pct is a decimal string.
 *  Dividing by 100 adds two to the effective scale, hence SCALE+3+2. */
function percent(amount, pct) {
  return rescale(amount * parse(pct, 3), SCALE + 3 + 2, SCALE);
}

/** qty (3dp) x unit cost (6dp) -> money (2dp). */
function extend(qtyStr, unitCostStr) {
  return mul(parse(qtyStr, 3), 3, parse(unitCostStr, 6), 6, SCALE);
}

const sum = list => list.reduce((a, b) => a + b, 0n);
const isZero = v => v === 0n;
const abs = v => (v < 0n ? -v : v);

/** Spread a total across weights so the parts add back to the total
 *  exactly. Rounding differences land on the largest part, which is
 *  where an auditor expects to find them. */
function allocate(total, weights) {
  const w = weights.map(x => parse(x, 6));
  const totalW = sum(w);
  if (totalW === 0n) return weights.map(() => 0n);
  const raw = w.map(x => (total * x) / totalW);
  let allocated = sum(raw);
  const diff = total - allocated;
  if (diff !== 0n) {
    let big = 0;
    for (let i = 1; i < raw.length; i++) if (abs(raw[i]) > abs(raw[big])) big = i;
    raw[big] += diff;
  }
  return raw;
}

module.exports = { SCALE, parse, format, formatAt, mul, rescale, percent, extend, sum, isZero, abs, allocate };
