'use strict';
const M = require('./money');
const { badRequest, notFound } = require('./db');

/* ============================================================
   The ledger.

   This is the ONLY module that inserts into journal_entry and
   journal_line. Every document service builds a list of lines and
   hands it here. The database enforces the accounting invariants;
   this layer exists to give a person a readable error before the
   database has to, and to keep the audit trail complete.
   ============================================================ */

/** Resolve a control account by role, never by hardcoded code. */
async function control(client, tag) {
  const { rows } = await client.query('SELECT control($1) AS code', [tag]);
  return rows[0].code;
}

/** Allocate the next gapless document number. */
async function nextDocNo(client, prefix, date) {
  const { rows } = await client.query('SELECT next_doc_no($1,$2) AS no', [prefix, date]);
  return rows[0].no;
}

/**
 * Post a journal entry.
 *
 * @param client  a client inside an open transaction
 * @param user    { id, name, can_post }
 * @param entry   { date, memo, source, sourceTable, sourceId, projectId,
 *                  prefix = 'JV', entryNo, reversalOf,
 *                  lines: [{ account, debit, credit, partyId, projectId,
 *                            employeeId, assetId, itemId, memo }] }
 * Amounts may be strings, numbers or BigInt minor units.
 */
async function post(client, user, entry) {
  if (!user || !user.can_post) {
    throw badRequest('Your role cannot post to the ledger. Ask a finance manager to approve this.');
  }
  if (!entry.memo || !String(entry.memo).trim()) {
    throw badRequest('Every entry needs a narration.');
  }

  const lines = normalise(entry.lines);
  if (lines.length < 2) throw badRequest('A journal entry needs at least two lines.');

  const dr = M.sum(lines.map(l => l.debit));
  const cr = M.sum(lines.map(l => l.credit));
  if (dr !== cr) {
    throw badRequest(
      `This entry does not balance. Debits ${M.format(dr)} against credits ${M.format(cr)}, ` +
      `out by ${M.format(M.abs(dr - cr))}.`);
  }
  if (dr === 0n) throw badRequest('This entry has no value.');

  const entryNo = entry.entryNo || await nextDocNo(client, entry.prefix || 'JV', entry.date);

  const { rows } = await client.query(
    `INSERT INTO journal_entry
       (entry_no, entry_date, memo, source, source_table, source_id,
        project_id, reversal_of_id, posted_by, posted_by_name, period_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,0)
     RETURNING id, entry_no, entry_date, period_id`,
    [entryNo, entry.date, entry.memo, entry.source || 'Journal',
     entry.sourceTable || null, entry.sourceId || null,
     entry.projectId || null, entry.reversalOf || null, user.id, user.name]);
  const head = rows[0];

  let n = 0;
  for (const l of lines) {
    await client.query(
      `INSERT INTO journal_line
         (entry_id, line_no, account_code, debit, credit,
          party_id, project_id, employee_id, asset_id, item_id, cost_code_id, memo)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
      [head.id, ++n, l.account, M.format(l.debit), M.format(l.credit),
       l.partyId || null, l.projectId || entry.projectId || null,
       l.employeeId || null, l.assetId || null, l.itemId || null,
       l.costCodeId || entry.costCodeId || null, l.memo || null]);
  }

  await audit(client, user, 'POST', 'journal_entry', head.id, {
    entry_no: head.entry_no, source: entry.source, amount: M.format(dr)
  });

  return {
    ...head, amount: M.format(dr), lineCount: lines.length,
    lines: lines.map((l, i) => ({
      line_no: i + 1, account_code: l.account,
      debit: M.format(l.debit), credit: M.format(l.credit),
      party_id: l.partyId || null, project_id: l.projectId || entry.projectId || null,
      cost_code_id: l.costCodeId || entry.costCodeId || null,
      employee_id: l.employeeId || null, asset_id: l.assetId || null, memo: l.memo || null
    }))
  };
}

function normalise(lines) {
  if (!Array.isArray(lines) || !lines.length) throw badRequest('No journal lines were supplied.');
  return lines.map((l, i) => {
    if (!l.account) throw badRequest(`Line ${i + 1} has no account.`);
    const debit = M.parse(l.debit || 0);
    const credit = M.parse(l.credit || 0);
    if (debit < 0n || credit < 0n) throw badRequest(`Line ${i + 1} has a negative amount. Put it on the other side instead.`);
    if (debit !== 0n && credit !== 0n) throw badRequest(`Line ${i + 1} has both a debit and a credit.`);
    return { ...l, debit, credit };
  }).filter(l => l.debit !== 0n || l.credit !== 0n);
}

/**
 * Reverse an entry by posting its mirror image. Nothing is edited or
 * deleted; the correction is itself a posting, which is what an
 * auditor expects to see.
 */
async function reverse(client, user, entryId, { date, reason } = {}) {
  const { rows } = await client.query(
    `SELECT e.*, (SELECT id FROM journal_entry r WHERE r.reversal_of_id = e.id) AS reversed_by
       FROM journal_entry e WHERE e.id = $1`, [entryId]);
  const orig = rows[0];
  if (!orig) throw notFound('That journal entry does not exist.');
  if (orig.reversed_by) throw badRequest(`Entry ${orig.entry_no} has already been reversed.`);

  const { rows: ls } = await client.query(
    `SELECT * FROM journal_line WHERE entry_id = $1 ORDER BY line_no`, [entryId]);

  const posted = await post(client, user, {
    date: date || new Date().toISOString().slice(0, 10),
    memo: `Reversal of ${orig.entry_no}` + (reason ? ` — ${reason}` : ''),
    source: 'Reversal',
    sourceTable: orig.source_table,
    sourceId: orig.source_id,
    projectId: orig.project_id,
    reversalOf: orig.id,
    lines: ls.map(l => ({
      account: l.account_code,
      debit: l.credit, credit: l.debit,          // mirrored
      partyId: l.party_id, projectId: l.project_id,
      employeeId: l.employee_id, assetId: l.asset_id, itemId: l.item_id,
      memo: l.memo
    }))
  });

  await audit(client, user, 'REVERSE', 'journal_entry', orig.id,
    { reversed_by: posted.entry_no, reason: reason || null });
  return posted;
}

/** Append to the audit trail. Never updated, never deleted. */
async function audit(client, user, action, entity, entityId, detail) {
  await client.query(
    `INSERT INTO audit_log (user_id, user_name, action, entity, entity_id, detail, ip)
     VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [user?.id || null, user?.name || 'system', action, entity,
     entityId == null ? null : String(entityId), detail ? JSON.stringify(detail) : null,
     user?.ip || null]);
}

/* ---------- reading the ledger ---------- */

const balance = async (client, code, { from, to, partyId, projectId } = {}) => {
  const { rows } = await client.query(
    `SELECT COALESCE(SUM(l.debit - l.credit),0) AS bal
       FROM journal_line l JOIN journal_entry e ON e.id = l.entry_id
      WHERE l.account_code = $1
        AND ($2::date IS NULL OR e.entry_date >= $2)
        AND ($3::date IS NULL OR e.entry_date <= $3)
        AND ($4::bigint IS NULL OR l.party_id = $4)
        AND ($5::bigint IS NULL OR l.project_id = $5)`,
    [code, from || null, to || null, partyId || null, projectId || null]);
  return rows[0].bal;
};

const ledgerRows = async (client, code, { from, to, partyId, projectId } = {}) => {
  const { rows } = await client.query(
    `SELECT * FROM v_ledger
      WHERE account_code = $1
        AND ($2::date IS NULL OR entry_date >= $2)
        AND ($3::date IS NULL OR entry_date <= $3)
        AND ($4::bigint IS NULL OR party_id = $4)
        AND ($5::bigint IS NULL OR project_id = $5)
      ORDER BY entry_date, entry_id, line_no`,
    [code, from || null, to || null, partyId || null, projectId || null]);
  let run = 0n;
  return rows.map(r => {
    run += M.parse(r.debit) - M.parse(r.credit);
    return { ...r, running_balance: M.format(run) };
  });
};

module.exports = { post, reverse, audit, control, nextDocNo, balance, ledgerRows };
