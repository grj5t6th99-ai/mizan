'use strict';
const { Pool, types } = require('pg');

/* NUMERIC arrives as a string by default in node-postgres, which is
   what we want — never let the driver turn money into a float.
   Make that explicit so nobody "helpfully" adds a parser later. */
types.setTypeParser(1700, v => v);          // numeric
types.setTypeParser(20, v => v);            // int8/bigint
/* DATE as a plain 'YYYY-MM-DD' string. Left as a JS Date it picks up
   the server's timezone, so a date near midnight can come back a day
   out, and any string maths on it silently produces Invalid Date. */
types.setTypeParser(1082, v => v);          // date

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 10),
  idleTimeoutMillis: 30_000,
  statement_timeout: 30_000
});

pool.on('error', err => console.error('[db] idle client error', err));

/** Run fn inside a transaction, rolling back on any throw.
 *  Every posting path goes through this: an entry lands whole or
 *  not at all. */
async function tx(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await fn(client);
    await client.query('COMMIT');
    return out;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw translate(err);
  } finally {
    client.release();
  }
}

/** Run fn in a transaction that is ALWAYS rolled back.
 *  This is how the posting preview works: it executes the very same
 *  code that posts, so what the user is shown can never drift from
 *  what would actually hit the ledger. */
async function dryRun(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await fn(client);
    await client.query('ROLLBACK');
    return out;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw translate(err);
  } finally {
    client.release();
  }
}

const query = (text, params) => pool.query(text, params);
const one = async (text, params) => (await pool.query(text, params)).rows[0] || null;
const many = async (text, params) => (await pool.query(text, params)).rows;

/* ---------- errors ---------- */
class AppError extends Error {
  constructor(message, status = 400, code = 'bad_request', detail) {
    super(message);
    this.status = status; this.code = code; this.detail = detail;
  }
}
const badRequest = (m, d) => new AppError(m, 400, 'bad_request', d);
const unauthorized = m => new AppError(m || 'Sign in to continue.', 401, 'unauthorized');
const forbidden = m => new AppError(m || 'Your role does not allow that.', 403, 'forbidden');
const notFound = m => new AppError(m || 'Not found.', 404, 'not_found');
const conflict = m => new AppError(m, 409, 'conflict');

/** Turn a Postgres error into something a person can act on.
 *  The ledger's own RAISE messages are already written for humans,
 *  so they pass through unchanged. */
function translate(err) {
  if (err instanceof AppError) return err;
  const c = err.code;
  if (c === '23505') return conflict(friendlyUnique(err));
  if (c === '23503') return badRequest('That refers to a record that does not exist.');
  if (c === '23514' || c === '23P01') return badRequest(err.message);
  // check_violation raised by our own triggers: the message is the point
  if (c === 'P0001' || c === '23514') return badRequest(err.message);
  if (c === '2F004' || c === '38004') return badRequest(err.message);
  if (err.severity === 'ERROR' && /append-only|does not balance|is LOCKED|is CLOSED|heading|control account|fiscal period|baseline|project_revision|approved by the person/i.test(err.message || '')) {
    return badRequest(err.message.split('\n')[0]);
  }
  return err;
}

function friendlyUnique(err) {
  const m = {
    journal_entry_entry_no_key: 'That voucher number already exists.',
    journal_entry_one_reversal: 'That entry has already been reversed.',
    account_pkey: 'That account code already exists.',
    party_code_key: 'That customer or supplier code already exists.',
    project_code_key: 'That project code already exists.',
    item_code_key: 'That item code already exists.',
    fixed_asset_tag_key: 'That asset tag already exists.',
    payroll_run_period_end_key: 'Payroll for that month has already been created.',
    depreciation_run_run_to_key: 'Depreciation has already been run to that date.',
    app_user_email_key: 'That email address is already registered.'
  }[err.constraint];
  return m || 'That record already exists.';
}

module.exports = {
  pool, tx, dryRun, query, one, many, AppError,
  badRequest, unauthorized, forbidden, notFound, conflict, translate
};
