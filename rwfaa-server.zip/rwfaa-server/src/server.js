'use strict';
const { buildApp } = require('./app');
const auth = require('./auth');
const db = require('./db');

const port = Number(process.env.PORT || 3000);
const server = buildApp().listen(port, () =>
  console.log(`[mizan] listening on ${port} (${process.env.NODE_ENV || 'development'})`));

setInterval(() => auth.sweepSessions().catch(e => console.error('[session sweep]', e)), 3600_000).unref();

for (const sig of ['SIGTERM', 'SIGINT']) {
  process.on(sig, () => {
    console.log(`[mizan] ${sig}, shutting down`);
    server.close(async () => { await db.pool.end(); process.exit(0); });
    setTimeout(() => process.exit(1), 10_000).unref();
  });
}
